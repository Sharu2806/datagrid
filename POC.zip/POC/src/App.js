import React,{Component} from 'react';
import SearchDataGrid from './SearchDataGrid.js'
import ReactDataGrid from 'react-data-grid';
import { Pagination } from 'react-bootstrap';
import './index.css'
import * as addons from 'react-data-grid-addons'
import ColumnFormatter from './ColumnFormatter.js'

class App extends Component{

  constructor(props){
    super(props);
    this.state ={
      _columns :[
        {
          key: 'eForm',
          name: 'eForm'
        },
        {
          key: 'status', name: 'Status',
          filterable: true,
          filterRenderer: addons.Filters.SingleSelectFilter,
          resizable : true,
          sortable : true,
          formatter : ColumnFormatter
        },
        {
          key: 'Assigned', name: 'Assigned to/Locked By/Held by',
          filterable: true,
          cellClass :'no-overflow'
        },
        {
        key: 'Priority',
        name: 'Priority',
        filterable: true,
        filterRenderer: addons.Filters.AutoCompleteFilter
      },
      {
        key : 'ProcessingSite',
        name: 'Processing Site',
        filterable: true,
        filterRenderer: addons.Filters.AutoCompleteFilter
      },
      {
        key : 'CustomerName',
        name: 'Customer Name',
        filterable: true
      }
    ],
      rows  : 0,
      total_rows : 0,
      filters :{},
      selectedIndexes : [],
      currentPage  : 1,
      itemsPerPage : 10
    }

    this.onRowSelection     = this.onRowSelection.bind(this);
    this.onRowsDeselected   = this.onRowsDeselected.bind(this);
    this.handleFilterChange     = this.handleFilterChange.bind(this);
    this.getValidFilterValues     = this.getValidFilterValues.bind(this);
    this.rowGetter            = this.rowGetter.bind(this);
    this.rowsCount            = this.rowsCount.bind(this);
    this.handleFilterChange          = this.handleFilterChange.bind(this);
    this.handleOnClearFilters     = this.handleOnClearFilters.bind(this);
    this.handleGridSort           = this.handleGridSort.bind(this);

  }

  componentWillMount(){
    this.createRows();
  }

  rowGetter(index) {
    debugger;
   return addons.Data.Selectors.getRows(this.state)[index];
  }

  rowsCount() {
    return addons.Data.Selectors.getRows(this.state).length;
  }

  createRows() {
      let rows = [];
      let names =['CUSTOMER4265', 'Six Ltd', 'Mwpuva Qqteso Rosfdy']
      for (let i = 1; i < 50; i++) {

        rows.push({
          eForm  : <a href='https://github.com/adazzle/react-data-grid/issues/792'>View</a>,
          status  : ['Normal', 'Held', 'Pendding', 'Locked'][Math.floor((Math.random() * 3) + 1)],
          Assigned : ['','43878882 (Abhishek)', '44074012 (Prasad)', '44074014 (Nisha)'][Math.floor((Math.random() * 3) + 1)],
          Priority : ['v2','v1', '24', '75'][Math.floor((Math.random() * 3) + 1)],
          ProcessingSite : ['','','GZH','SZN'][Math.floor((Math.random()* 3) + 1)],
          CustomerName : ['','CUSTOMER4265', 'Six Ltd', 'Mwpuva Qqteso Rosfdy'][Math.floor((Math.random()* 3) + 1)],
        });
      }
      this.setState({total_rows : rows});
    }

    handlePagination(){
      var indexOfLastItem = this.state.currentPage * this.state.itemsPerPage;
      var indexOfFirstItem = indexOfLastItem - this.state.itemsPerPage;
      var currentTableData = this.state.total_rows.slice(indexOfFirstItem, indexOfLastItem);
      console.log(currentTableData);
      this.setState({rows :currentTableData})
    }

    handleFilterChange(filter) {
         let newFilters = Object.assign({}, this.state.filters);
         if (filter.filterTerm) {
           newFilters[filter.column.key] = filter;
         } else {
           delete newFilters[filter.column.key];
         }
         this.setState({ filters: newFilters });
    }

    handleOnClearFilters() {
        this.setState({ filters: {} });
    }

    getValidFilterValues(columnId) {
      let values = this.state.rows.map(r => r[columnId]);
      let rowdata = values.filter((item, i, a) => { return i === a.indexOf(item); });
      return rowdata;
    }

    onRowSelection(rowIdx){
        let index = this.state.selectedIndexes;
        let data = this.state.selectedindxData;
        rowIdx.map((id)=>{
          index.push(id.rowIdx);
        });
        this.setState({selectedIndexes : index});
    }

    onRowsDeselected(rowIdx){

        let index = this.state.selectedIndexes;
        let rowIndexes = rowIdx.map(r => r.rowIdx);
        this.setState({selectedIndexes: index.filter(i => rowIndexes.indexOf(i) === -1 )});

    }

    handleGridSort(sortColumn, sortDirection) {
     const comparer = (a, b) => {
       if (sortDirection === 'ASC') {
         return (a[sortColumn] > b[sortColumn]) ? 1 : -1;
       } else if (sortDirection === 'DESC') {
         return (a[sortColumn] < b[sortColumn]) ? 1 : -1;
       }
     };

     const rows = sortDirection === 'NONE' ? this.state.originalRows.slice(0) : this.state.rows.sort(comparer);

     this.setState({ rows });
   }


    render(){
      console.log(addons.Toolbar);
      debugger;
      this.handlePagination();
      //const rowGetter1 = rowNumber => currentTableData[rowNumber];
      return(
        <div className="container" style={{'margin-top': '20px'}}>
            <div className="col-lg-12 col-md-12">
                    <ReactDataGrid
                      onGridSort = {this.handleGridSort}
                      enableCellSelect={true}
                      onGridSort={this.handleGridSort}
                      columns={this.state._columns}
                      rowGetter={this.rowGetter}
                      rowsCount={this.rowsCount()}
                      minHeight ={500}
                      rowHeight ={50}
                      getValidFilterValues={this.getValidFilterValues}
                      onAddFilter = {this.handleFilterChange}
                      onClearFilters ={this.handleOnClearFilters}
                      toolbar = {<addons.Toolbar enableFilter={true}/>}

                      rowSelection = {{
                         showCheckbox : true,
                         selectBy : {
                           indexes : this.state.selectedIndexes
                         },
                     onRowsSelected : this.onRowSelection ,
                     onRowsDeselected : this.onRowsDeselected,
                     enableShiftSelect : true
                      }}

                     />
                </div>
                <div className="pull-right">
                <span style={{ marginRight: '40px', color: 'black' }}>Showing {1} of {50} Records</span>
                <Pagination
                    className={Math.ceil(this.state.total_rows.length / this.state.itemsPerPage) === 1 ? 'hidden' : 'shown'}
                    prev={'Previous'}
                    next={'Next'}
                    items={Math.ceil(this.state.total_rows.length / this.state.itemsPerPage)}
                    maxButtons={3}
                    boundaryLinks
                    activePage={1}
                    onSelect={this.handlePageChange}>
                </Pagination>
            </div>
            </div>
        );
    }
}

export default App;
