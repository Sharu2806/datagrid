import React,{Component,propTypes} from 'react';
import './index.css'
import ReactDataGrid from 'react-data-grid';
import {Row, Cell} from 'react-data-grid';

export default class RowRenderer extends Component{

  propTypes: {
    idx: React.PropTypes.string.isRequired
  }

  getRowStyle() {
    return {
      color: this.getRowBackground()
    };
  }

  getRowBackground() {
    console.log(this.props.row.status);
    //return this.props.idx % 2 ?  'green' : 'blue';
    if(this.props.row.status === 'Held'){
      return 'green'
    }else if(this.props.row.status === 'Pendding'){
      return 'red'
    }else if(this.props.row.status === 'Locked'){
      return 'blue'
    }
  }

  render(){
    console.log(Row);
    console.log(Cell);
    return(
        <div style={this.getRowStyle()}><ReactDataGrid.Row ref="row" {...this.props}/></div>
    );
  }
}
