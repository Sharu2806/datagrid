import React,{Component,propTypes} from 'react';
import './index.css'


export default class ColumnFormatter extends Component{

  propTypes: {
    value: React.PropTypes.string.isRequired
  }

  getCellStyle() {
    if(this.props.value === 'Held'){
      return 'held'
    }else if(this.props.value=== 'Pendding'){
      return 'locked'
    }else if(this.props.value === 'Locked'){
      return 'pending'
    }
  }



  render(){
  
    return(
        <div className={this.getCellStyle()}><span className="status-span">{this.props.value}</span></div>
    );
  }
}
