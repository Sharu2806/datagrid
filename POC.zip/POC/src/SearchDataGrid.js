import React, { Component,PropTypes } from 'react';
import ReactDataGrid from 'react-data-grid';

export default class SearchDataGrid extends Component{

  render() {
    return  (
      <ReactDataGrid
        ref={ node => this.grid = node}
        enableCellSelect={this.props.enableCellSelect}
        columns={this.props.columns}
        rowGetter={this.props.rowGetter}
        rowsCount={this.props.rowlength}
        minHeight={this.props.minheight}
        rowSelection={this.props.rowSelection}
        onRowsSelected={this.props.onRowsSelected}
        onRowsDeselected={this.props.onRowsDeselected}
        enableShiftSelect={this.props.enableShiftSelect}
        onGridSort={this.props.onGridSort}
        rowHeight ={this.props.rowheight}
        onAddFilter = {this.props.onAddFilter}
        onClearFilters ={this.props.onClearFilters}
        toolbar = {this.props.toolbar}

        getValidFilterValues={this.props.getValidFilterValues}
        />);
    }
}
