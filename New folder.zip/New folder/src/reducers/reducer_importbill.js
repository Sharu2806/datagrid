export default function(){
  return {
    id:1,
    name:"sharayu",
    job:"developer"
  };
};
