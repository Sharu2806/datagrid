import {combineReducers} from 'redux';
import billimport from './reducer_importbill.js'

const allReducers = combineReducers({
    bills : billimport
});

export default allReducers;
