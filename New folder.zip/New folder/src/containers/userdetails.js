import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux'

class UserDetails extends Component {

  showdata(){
      
  }
  render(){
    return(
      <div>
        <ul>
            {this.showdata()}
        </ul>
      </div>
    )
  }
}

function mapStateToProps(state){
  return{
    data : state.bills
  }
}

export default connect(mapStateToProps)(UserDetails);
