import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import UserDetailsfrom from '../containers/userdetails.js'

export default class App extends Component {
  render(){
    return(
      <div>
        <h1>User List</h1>
        <hr />
        <UserDetailsfrom />
      </div>
    )
  }
}
