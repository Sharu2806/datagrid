'use strict';
var webpack = require('webpack');
var config = {

    plugins: [
        new webpack.ProvidePlugin({
            jQuery: 'jquery',
            $: 'jquery',
            jquery: 'jquery'
        })
    ],
    entry: {
        SFE: './src/index.js'

    },
    output: {
        publicPath: 'http://localhost:8080/',
        filename: 'build/bundle.js'
    },
    // generate source map
    devtool: 'source-map',
    resolve: {
        extensions: ['.js', '.jsx', '.json']
    },
    module: {
        loaders: [{
            test: /\.jsx?$/,
            include: /src/,
            exclude: /node_modules/,
            loader: 'babel-loader',
            query: {
                presets: ['es2015', 'react', 'stage-0', 'stage-2']
            }
        },
            { test: /bootstrap\/dist\/js\/umd\//, loader: 'imports?jQuery=jquery' },

            { test: /\.(png|woff|woff2|eot|ttf|svg)$/, loader: 'url-loader?limit=100000' },


            // load CSS
            // the order is important here
            // style loader takes CSS and actually inserts it into the page
            //     so that the styles are active on the page
            // css loader takes a CSS file and returns the CSS with
            //     imports and url(...) resolved via webpack's require functionality
            //     it doesn't actually do anything with the returned CSS
            // sass loader converst sass to css files
            {
                test: /\.scss$/,
                include: /src/,
                loaders: [
                    'style',
                    'css',
                    'sass'
                ]
            },
            {
                test: /\.css$/i,
                loader: 'css-loader?-minimize',

            },
            // load images
            // url loader works like the file loader, but can return a Data Url
            //     if the file is smaller than a limit.
            // img loader minifis PNG, JPEG, GIF and SVG images with imagemin
            {
                test: /\.(jpe?g|png|gif|svg)$/i,
                loaders: [
                    'url-loader',
                    'img-loader'
                ]
            }
        ]
    }
};

module.exports = config;