import React, { Component } from 'react';
import Layout from './Layout/Layout';

export default class App extends Component {
  render(){
    return(
      <Layout> </Layout>

    )
  }
}
