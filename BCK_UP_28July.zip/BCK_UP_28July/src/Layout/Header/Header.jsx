import { connect } from "react-redux";
import React, { Component } from 'react';
import './Header.css';

class Header extends Component {

    constructor() {
        super();
        this.toggleClass = this.toggleClass.bind(this);
    }

    // This will toggle the classes on header as well as on left menu bar and content on right
    toggleClass(value) {
        // calling parent toggle class
        // left menu and content on right are in sync with header
        this.props.parentToggleClass();
    }


    componentWillMount() {
        this.GMT=this.getTimeZone()
    }

    getTimeZone() {
        let timeZOneInMinutes = new Date().getTimezoneOffset();
        let hours;
        let minutes;
        if (timeZOneInMinutes >= 0) {
            hours = -(Math.floor(timeZOneInMinutes / 60));
            minutes = timeZOneInMinutes % 60;
        }
        else {
            timeZOneInMinutes = -timeZOneInMinutes;
            hours = (Math.floor(timeZOneInMinutes / 60));
            minutes = timeZOneInMinutes % 60;
        }
        if (hours >= 0) {
            if (hours < 10) {
                hours = '0' + hours
            }
            return '+' + hours + ':' + minutes;
        }
        else {
            return hours + ':' + minutes;
        }
    }

    render() {
        return (
            <div className="row" >
                <div className={this.props.leftSideClass + ' text-center'}>
                    <img
                        src={this.props.collapseFlag ? 'img/HSBCSmallLogo.png' : 'img/HSBCBigLogo.png'}
                        alt="Cinque Terre"
                        className="img-responsive center-block"
                        height="50"
                    />
                </div>
                <div className={this.props.rightSideClass + ' header-style'}>

                    <span style={{ position: 'relative', top: '12px' }} onClick={() => this.toggleClass()} className="hamburger-background">
                        <img className="hamburger-icon" src={this.props.collapseFlag ? "icons/show-menu.svg" : "icons/hide-menu.svg"} alt="" />
                    </span>
                    {this.props.recordingFlag ?
                        <span style={{ fontSize: '20px', position: 'relative', top: '12px' }}>&nbsp;Recording > GTE Generic > Guarantee Issuance</span>
                        :
                        <span style={{ fontSize: '20px', position: 'relative', top: '12px' }}>&nbsp;Trade Services > Maintenance > Serial Number</span>
                    }
                    <span className='pull-right' style={{ position: 'relative', top: '12px' }}> <span style={{ fontSize: '12px', float: 'right' }}>Time Zone</span> <br />GMT {this.GMT}</span>
                </div>
            </div>
        );
    }
}

function mapStateToProps(store) {
    if (store.recordingDCReducer) {
        return {
            recordingFlag: store.recordingDCReducer.recordingFlag
        }
    } else {
        return {
            recordingFlag: false
        }
    }
}

export default connect(mapStateToProps)(Header);
