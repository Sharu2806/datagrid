import React, { Component } from 'react';
import ToolTip from 'react-portal-tooltip';

import { Link } from 'react-router-dom';
import $ from 'jquery';
import './LeftMenuBar.css';

class LeftMenuBar extends Component {

    constructor() {
        super();
        this.state = {
            isTooltipActive: false,
            isTooltipActiveForDashboard: false,
            isTooltipActiveForWorkQueue: false,
            isTooltipActiveForWorkItem: false,
            isTooltipActiveForCsAdminPage: false,
            isTooltipActiveForCrossSearch: false,
            open: false
        }
        this.toggleArrowDirection = this.toggleArrowDirection.bind(this);
    }

    handleRequestClose = () => {
        this.setState({
            open: false,
        });
    };

    showTooltipForDashboard() {
        this.setState({ isTooltipActiveForDashboard: true })
    }

    hideTooltipForDashboard() {
        this.setState({ isTooltipActiveForDashboard: false })
    }

    showTooltipForWorkQueue() {
        this.setState({ isTooltipActiveForWorkQueue: true })
    }

    hideTooltipForWorkQueue() {
        this.setState({ isTooltipActiveForWorkQueue: false })
    }

    showTooltipForWorkItem() {
        this.setState({ isTooltipActiveForWorkItem: true })
    }

    hideTooltipForWorkItem() {
        this.setState({ isTooltipActiveForWorkItem: false })
    }

    showTooltipForCSAdminPage() {
        this.setState({ isTooltipActiveForCsAdminPage: true })
    }

    hideTooltipForCSAdminPage() {
        this.setState({ isTooltipActiveForCsAdminPage: false })
    }

    showTooltipForCrossSeach() {
        this.setState({ isTooltipActiveForCrossSearch: true })
    }

    hideTooltipForCrossSeach() {
        this.setState({ isTooltipActiveForCrossSearch: false })
    }

    showTooltip() {
        this.setState({ isTooltipActive: true })
    }

    hideTooltip() {
        this.setState({ isTooltipActive: false })
    }

    toggleArrowDirection(value) {
        $('#' + value + 'Ref').toggleClass('fa-angle-down fa-angle-right');
    }

    render() {
        return (
            <div className="row" style={{marginBottom:'40px'}}>
                <div className={this.props.collapseFlag ? "text-center" : "col-md-3 text-center"}>
                    <img
                        src="img/user.png"
                        className="img-circle center-block"
                        alt="Cinque Terre"
                        height="42px"
                        width="42px"
                    />
                </div>
                {!this.props.collapseFlag &&
                    <div className="col-md-9">
                        <p style={{ fontSize: '18px', color: '#000000' }}>Jane Doe</p>
                        <a style={{ position: 'relative', top: '-10px', fontSize: '15px', color: '#007ca9' }}>Logout</a>
                    </div>
                }
                <table className="table left-menu-table">
                    <tbody>
                        <tr>
                            <td
                                className={this.props.collapseFlag ? 'text-center' : ''}
                                style={{ backgroundColor: '#01afd2', color: 'white' }}
                            >
                                <embed  className={this.props.collapseFlag ?"left-menu-icon no-left-margin" :"left-menu-icon"} src="icons/dashboard.svg" alt="" title="dashboard"
                                    onMouseEnter={this.showTooltipForDashboard.bind(this)} onMouseLeave={this.hideTooltipForDashboard.bind(this)} id="dashboardId">
                                </embed>
                                <span className={this.props.collapseFlag ? 'hide left-menu-text' : 'left-menu-text'}>Dashboard</span>
                                {this.props.collapseFlag ?
                                    <ToolTip active={this.state.isTooltipActiveForDashboard} position="right" arrow="center" parent="#dashboardId">
                                        Dashboard
                                    </ToolTip> : ''
                                }
                            </td>
                        </tr>
                    </tbody>
                    <tbody>
                        <tr>
                            <td
                                className={this.props.collapseFlag ? 'text-center' : ''}
                                type="button"
                                data-toggle="collapse"
                                data-target="#workQueues"
                                onClick={() => this.toggleArrowDirection('workQueues')}
                            >
                                <embed className={this.props.collapseFlag ?"left-menu-icon no-left-margin" :"left-menu-icon"} src="icons/work-queue.svg" alt="" title="work q"
                                    onMouseEnter={this.showTooltipForWorkQueue.bind(this)} onMouseLeave={this.hideTooltipForWorkQueue.bind(this)} id="workQ">
                                </embed>
                                <span className={this.props.collapseFlag ? 'hide left-menu-text' : 'left-menu-text'}>My Work Queue
                                    <i
                                        id="workQueuesRef"
                                       className="fa fa-angle-right"
                                       style={{ fontSize: '20px', float: 'right', height: '15px', width: '8px' }}
                                    />
                                </span>
                                {this.props.collapseFlag ?
                                    <ToolTip active={this.state.isTooltipActiveForWorkQueue} position="right" arrow="center" parent="#workQ">
                                        Work Queue
                                    </ToolTip>
                                    :
                                    ''
                                }
                            </td>
                        </tr>
                    </tbody>
                    { !this.props.collapseFlag &&
                        <tbody id="workQueues" className="collapse show-hide">
                            <tr>
                                <td className="paddingLeft30" >Import DC Issuance<hr className="hr-left-menu"/></td>
                            </tr>
                            <tr>
                                <td className="paddingLeft30" >Guarantee</td>
                            </tr>
                            <tr>
                                <td className="paddingLeft30" ><Link to="/createSerialNo" >Serial Number</Link> </td>
                            </tr>
                        </tbody>
                    }
                    <tbody>
                        <tr>
                            <td
                                className={this.props.collapseFlag ? 'text-center' : ''}
                                type="button"
                                data-toggle="collapse"
                                data-target="#workItems"
                                onClick={() => this.toggleArrowDirection('workItems')}
                            >
                                <embed className={this.props.collapseFlag ?"left-menu-icon no-left-margin" :"left-menu-icon"} src="icons/work-items.svg" alt="" title="work q"
                                    onMouseEnter={this.showTooltipForWorkItem.bind(this)} onMouseLeave={this.hideTooltipForWorkItem.bind(this)} id="workItemId">
                                </embed>
                                <span className={this.props.collapseFlag ? 'hide left-menu-text' : 'left-menu-text'}>My Work Items
                                    <i
                                        id="workItemsRef"
                                       className="fa fa-angle-down"
                                       style={{ fontSize: '20px', float: 'right', height: '15px', width: '8px' }}
                                    />
                                </span>
                                {this.props.collapseFlag ?
                                    <ToolTip active={this.state.isTooltipActiveForWorkItem} position="right" arrow="center" parent="#workItemId">
                                        Work Items
                                    </ToolTip>
                                    :
                                    ''
                                }
                            </td>
                        </tr>
                    </tbody>
                    {
                        !this.props.collapseFlag &&
                        <tbody id="workItems" className="collapse in show-hide">
                            <tr>
                                <td className="paddingLeft30" >All <span className="label label-danger">17</span><hr className="hr-left-menu"/></td>
                            </tr>
                            <tr>
                                <td className="paddingLeft30" >Sent <span className="label label-danger">12</span><hr className="hr-left-menu"/></td>
                            </tr>
                            <tr>
                                <td className="paddingLeft30" >Assigned <span className="label label-danger">5</span></td>
                            </tr>
                        </tbody>
                    }
                    <tbody>
                        <tr>
                            <td className={this.props.collapseFlag ? 'text-center' : ''} >
                                <embed className={this.props.collapseFlag ?"left-menu-icon no-left-margin" :"left-menu-icon"} src="icons/cs-admin-page.svg" alt="" title="work q"
                                    onMouseEnter={this.showTooltipForCSAdminPage.bind(this)} onMouseLeave={this.hideTooltipForCSAdminPage.bind(this)} id="csAdminPageId">
                                </embed>
                                <span className={this.props.collapseFlag ? 'hide left-menu-text' : 'left-menu-text'}>CS Admin page</span>
                                {this.props.collapseFlag ?
                                    <ToolTip active={this.state.isTooltipActiveForCsAdminPage} position="right" arrow="center" parent="#csAdminPageId">
                                        CS Admin Page
                                    </ToolTip>
                                    :
                                    ''
                                }
                            </td>
                        </tr>
                    </tbody>
                    <tbody>
                        <tr>
                            <td className={this.props.collapseFlag ? 'text-center' : ''} >
                                <embed className={this.props.collapseFlag ?"left-menu-icon no-left-margin" :"left-menu-icon"} src="icons/cross-search.svg" alt="" title="work q"
                                    onMouseEnter={this.showTooltipForCrossSeach.bind(this)} onMouseLeave={this.hideTooltipForCrossSeach.bind(this)} id="crossSearchId">
                                </embed>
                                <span className={this.props.collapseFlag ? 'hide left-menu-text' : 'left-menu-text'}>Cross Search</span>
                                {this.props.collapseFlag ?
                                    <ToolTip active={this.state.isTooltipActiveForCrossSearch} position="right" arrow="center" parent="#crossSearchId">
                                        Cross Search
                                    </ToolTip>
                                    :
                                    ''
                                }
                            </td>
                        </tr>
                    </tbody>
                    <tbody>
                        <tr>
                            <td className={this.props.collapseFlag ? 'text-center' : ''} >
                                <embed className={this.props.collapseFlag ?"left-menu-icon no-left-margin" :"left-menu-icon"} src="icons/create-work-item.svg" alt="" title="work q"
                                    onMouseEnter={this.showTooltip.bind(this)} onMouseLeave={this.hideTooltip.bind(this)} id="createWorkItemId">
                                </embed>
                                <span className={this.props.collapseFlag ? 'hide left-menu-text' : 'left-menu-text'}>Create Work Item</span>
                                {this.props.collapseFlag ?
                                    <ToolTip active={this.state.isTooltipActive} position="right" arrow="center" parent="#createWorkItemId">
                                        Create Work Item
                                    </ToolTip>
                                    :
                                    ''
                                }
                            </td>
                        </tr>
                    </tbody>

                      <tbody>
                          <tr>
                              <td
                                  className={this.props.collapseFlag ? 'text-center' : ''}
                                  type="button"
                                  data-toggle="collapse"
                                  data-target="#MaintenanceSubmenu"
                                  onClick={() => this.toggleArrowDirection('MaintenanceSubmenu')}
                              >
                                  <embed className={this.props.collapseFlag ?"left-menu-icon no-left-margin" :"left-menu-icon"} src="icons/work-items.svg" alt="" title="work q"
                                      onMouseEnter={this.showTooltipForWorkItem.bind(this)} onMouseLeave={this.hideTooltipForWorkItem.bind(this)} id="MaintenanceSubmenuId">
                                  </embed>
                                  <span className={this.props.collapseFlag ? 'hide left-menu-text' : 'left-menu-text'}>Maintenance
                                      <i
                                          id="MaintenanceSubmenuRef"
                                         className="fa fa-angle-down"
                                         style={{ fontSize: '20px', float: 'right', height: '15px', width: '8px' }}
                                      />
                                  </span>
                                  {this.props.collapseFlag ?
                                      <ToolTip active={this.state.isTooltipActiveForWorkItem} position="right" arrow="center" parent="#MaintenanceSubmenuId">
                                          Maintenance
                                      </ToolTip>
                                      :
                                      ''
                                  }
                              </td>
                          </tr>
                      </tbody>
                      {
                          !this.props.collapseFlag &&
                          <tbody id="MaintenanceSubmenu" className="collapse in show-hide">
                              <tr>
                                  <td className="paddingLeft30" >Applicant/Beneficiary Name & Address Maintenance <hr className="hr-left-menu"/></td>
                              </tr>
                              <tr>
                                  <td className="paddingLeft30" >Export Bill Checking Authorised Limit  <hr className="hr-left-menu"/></td>
                              </tr>
                              <tr>
                                  <td className="paddingLeft30" >Import Authorised Signing Officer <hr className="hr-left-menu"/></td>
                              </tr>
                              <tr>
                                  <td className="paddingLeft30" >Reimbursement Bank Maintenance <hr className="hr-left-menu"/></td>
                              </tr>
                              <tr>
                                  <td className="paddingLeft30" >Serial Number Control Maintenance <hr className="hr-left-menu"/></td>
                              </tr>
                              <tr>
                                  <td className="paddingLeft30" >Special Instruction Maintenance <hr className="hr-left-menu"/></td>
                              </tr>
                              <tr>
                                  <td className="paddingLeft30" >Standard Clause Maintenance<hr className="hr-left-menu"/></td>
                              </tr>
                          </tbody>
                      }
                </table>
            </div>
        );
    }
}

export default LeftMenuBar;
