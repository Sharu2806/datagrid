import React from 'react';
import {
  BrowserRouter as Router
} from 'react-router-dom';

import LeftMenuBar from './LeftMenuBar/LeftMenuBar';
import Content from './Content';

class ContentArea extends React.Component {
  render() {
    return (
      <Router>
        <div className="row">
          {/* getting classes from parent as they have to be in sync with header*/}
          <div className={this.props.leftSideClass}>
            <LeftMenuBar collapseFlag={this.props.collapseFlag} />
          </div>
          {/* getting classes from parent as they have to be in sync with header*/}
          <div className={this.props.rightSideClass} style={{ backgroundColor:'#f7f7f7'}}>
            <Content rightSideClass={this.props.rightSideClass} />
          </div>
        </div>
      </Router>
    );
  }
}

export default ContentArea;
