import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
            <div className="navbar-fixed-bottom" style={{ backgroundColor: '#333333',height:"40px", overflow:'hidden'}}>
                     <div className="pull-right">
                        <button className="btn" style={{ backgroundColor: '#333333', color: '#ffffff', border: 'none',fontSize:"14px" }}>WDM</button>
                        <button className="btn" style={{ backgroundColor: '#333333', color: '#ffffff', border: 'none',fontSize:"14px" }}>Application1</button>
                        <button className="btn" style={{ backgroundColor: '#333333', color: '#ffffff', border: 'none',fontSize:"14px" }}>Application2</button>
                    </div>
            </div>
        );
    }
}

export default Footer;