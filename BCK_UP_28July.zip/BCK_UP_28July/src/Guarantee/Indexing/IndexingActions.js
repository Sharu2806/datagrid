import * as ACTION_TYPES from '../GuaranteeActionTypes';

export function fetchIndexingData() {
    // console.log('fetch indexing data action');
    return dispatch => {
        //fetch('/WDM/fetch/1')
        fetch('http://10.191.131.145:8090/WDM/fetch/1')
            .then(result => result.json())
            .then(body =>
                dispatch({
                    type: ACTION_TYPES.GTE_INDEXING_FETCH_INDEXING_DATA,
                    payload: body
                })
            );
    }
}

export function saveBasicInformationData(obj) {
    // console.log('save BASIC data action');
    return {
        type: ACTION_TYPES.GTE_INDEXING_SAVE_BASIC_INFORMATION_DATA,
        payload: obj
    };
}

export function saveCommonInformationData(obj) {
    // console.log('save COMMON data action');
    return {
        type: ACTION_TYPES.GTE_INDEXING_SAVE_COMMON_INFORMATION_DATA,
        payload: obj
    };
}

export function saveIndexingInformationData(obj) {
    // console.log('save INDEXING data action');
    return {
        type: ACTION_TYPES.GTE_INDEXING_SAVE_INDEXING_INFORMATION_DATA,
        payload: obj
    };
}

export function sendData(obj) {
    return dispatch => {
        var data = JSON.stringify(obj);
        // console.log('Sending Data to WDM', data);

        //fetch('http://10.191.131.54:8090/WDM/save', {
        fetch('/WDM/save', {
            method: 'post',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: data
        }).then(result => result.json())
            .then(body => successCall(body))
            .catch(error => errorCall(error))
    }
}

function successCall(body) {
    // console.log("body :: ", JSON.stringify(body));
    alert("WORK ITEM " + body.basicInformation.gwisId + " sent successfully for Recording");
}
function errorCall(error) {
    console.log("error :: ", error);
    alert(error);
}

export function getCustomerName(acntNum) {
    // console.log('getCustomerName action');
    return dispatch => {
        fetch('http://10.191.131.225:8090/WDM/customer/' + acntNum).then(result => result.text()).then(body =>
            dispatch({
                type: ACTION_TYPES.GTE_INDEXING_GET_CUST_NAME,
                payload: body
            })
        );
    }
}