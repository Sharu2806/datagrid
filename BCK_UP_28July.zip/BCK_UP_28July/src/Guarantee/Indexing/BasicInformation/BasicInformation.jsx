import React, { Component } from 'react';
import * as Utils from '../../../common.js';

class BasicInformation extends Component {

    constructor(props) {
        super(props);
        this.state = {
            gwisId: '',
            status: '',
            createdUser: '',
            lastModifiedUser: '',
            lastModifiedTime: '',
            createdTime: '',
            workStep: '',
            nextWorkStep: ''
        }
        this.handleChange = this.handleChange.bind(this);
        this.saveData = this.saveData.bind(this);
    }

    componentWillMount() {
        this.setState({
            ...this.props.inputData
        });
    }

    componentDidMount() {
        this.props.onRef(this);
    }

    componentWillReceiveProps(nextProps) {

    }

    componentWillUnmount() {
        this.props.onRef(undefined)
    }

    handleChange(event) {
        Utils.handleChange(event);
    }

    saveData() {
        this.props.saveBasicInformationData(this.state);
    }

    render() {
        return (
            <form>
                <div className="row ">
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">GWIS ID</span><br />
                        <input type="text" className="form-control" disabled value={this.state.gwisId} onChange={this.handleChange} name="gwisId" id="gwisId" />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Status</span><br />
                        <input type="text" className="form-control" disabled value={this.state.status} onChange={this.handleChange} name="status" id="status" />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Created User</span><br />
                        <input type="text" className="form-control" disabled value={this.state.createdUser} onChange={this.handleChange} name="createdUser" id="createdUser" />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Created Time</span><br />
                        <input type="text" className="form-control" disabled value={this.state.createdTime} onChange={this.handleChange} name="createdTime" id="createdTime" />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Last Modified User</span><br />
                        <input type="text" className="form-control" disabled value={this.state.lastModifiedUser} onChange={this.handleChange} name="lastModifiedUser" id="lastModifiedUser" />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Last Modified Time</span><br />
                        <input type="text" className="form-control" disabled value={this.state.lastModifiedTime} onChange={this.handleChange} name="lastModifiedTime" id="lastModifiedTime" />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Current Work Step</span><br />
                        <input type="text" className="form-control" disabled value={this.state.workStep} onChange={this.handleChange} name="workStep" id="workStep" />
                    </div>

                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Next Work Step</span><br />
                        <select className="form-control selectCss" value={this.state.nextWorkStep} onChange={this.handleChange} name="nextWorkStep" id="nextWorkStep">
                            <option value=''>Please Select</option>
                            <option value='Document Attach'>Document Attach</option>
                            <option value='Recording'>Recording</option>
                            <option value='Document Management Pre Work'>Document Management Pre Work</option>
                            <option value='Auto Indexing'>Auto Indexing</option>
                        </select>
                    </div>
                </div>
            </form >
        );
    }
}

export default BasicInformation;
