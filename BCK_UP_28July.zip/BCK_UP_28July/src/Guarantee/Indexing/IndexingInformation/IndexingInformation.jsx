import React from 'react';
import { DateField, DatePicker } from 'react-date-picker';
import moment from 'moment';
import CustomDiv from '../../../SharedComponents/CustomDiv.jsx';
import ErrorDisplay from '../../../SharedComponents/ErrorDisplay';
import * as Utils from '../../../common.js';

var indexInfoValidate = {
    "customerAccountNumber": { mandatory: true },
    "customerName": { mandatory: true },
    "transactionCurrency": { mandatory: true },
    "transactionAmount": { mandatory: true }
}

class IndexingInformation extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            customerAccountNumber: '',
            applicationDateTime: '',
            customerName: '',
            applicationReference: '',
            transactionCurrency: '',
            transactionAmount: 0,
            captureUnderProduct: '',
            sgNumber: '',
            otherBankReference: '',
            gteExpiryDate: '',
            customerGHOClass: '',
            errors: []
        };

        this.handleInputChange = this.handleInputChange.bind(this);
        this.saveData = this.saveData.bind(this);

        this.addError = this.addError.bind(this);
        this.removeError = this.removeError.bind(this);
        this.getCustomerName = this.getCustomerName.bind(this);
    }

    saveData() {
        if (Utils.validateErrors(this)) {
            this.props.saveIndexingInformationData(this.state);
        }
    }
    componentDidMount() {
        this.props.onRef(this);

        fetch('json/IndexError.json', {
            method: 'GET'
        }).then(result => result.json())
            .then(body => this.saveError(body));
    }
    componentWillReceiveProps(nextProps) {

    }
    componentWillUnmount() {
        this.props.onRef(undefined)
    }

    componentWillMount() {
        this.setState({
            ...this.props.inputData
        });
    }

    //storing error json in a local variable
    saveError(value) {
        this.errorFromJson = value;
    }

    handleInputChange(event) {
        Utils.handleChange(event, this);
    }
    addError(event) {
        Utils.addError(event, this);
    }
    removeError(event) {
        Utils.removeError(event, this);
    }

    getCustomerName(event) {
        this.addError(event);
        if (this.state.customerAccountNumber === "002-936771-095") {
            this.setState({ customerName: "Dennis" });
        } else if (this.state.customerAccountNumber === "002-1-123456") {
            this.setState({ customerName: "Adrian" });
        }
    }

    render() {
        return (
            <form>
                <CustomDiv className="row ">
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3" >
                        <span className="label-margin-below">Customer Search Name</span><br />
                        <input type="text" className="form-control" value={this.state.name} onChange={this.handleInputChange} name="name" id="name" />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Customer GHO Class</span><br />
                        <input type="text" className="form-control" value={this.state.customerGHOClass} onChange={this.handleInputChange} name="customerGHOClass" id="customerGHOClass" />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Customer Account Number</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                        <input type="text" className="form-control" pattern="^[0-9]{1,3}-[0-9]{1,6}-[0-9]{1,6}$" value={this.state.customerAccountNumber} onChange={this.handleInputChange} required={indexInfoValidate ? indexInfoValidate.customerAccountNumber.mandatory : false} onBlur={this.addError} onFocus={this.removeError} name="customerAccountNumber" id="customerAccountNumber" />
                        <ErrorDisplay errors={this.state.errors} fieldName='customerAccountNumber' className='errorClass' />
                    </div>
                    <div className="clearfix visible-md visible-sm"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Customer Name</span><br />
                        <input type="text" className="form-control" value={this.state.customerName} onChange={this.handleInputChange} name="customerName" id="customerName" />
                    </div>
                    <div className="clearfix visible-lg"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Application Received Date Time</span><br />
                        <DateField className="form-control" dateFormat="YYYY-MM-DD HH:mm:ss" forceValidDate={true} defaultValue={moment()} >
                            <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} highlightToday={true} weekNumbers={true} weekStartDay={0} />
                        </DateField>
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Application Reference</span><br />
                        <input type="text" className="form-control" value={this.state.applicationReference} onChange={this.handleInputChange} name="applicationReference" id="applicationReference" value={this.props.gwisId} />
                    </div>
                    <div className="clearfix visible-md visible-sm"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Transaction Currency</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                        <select className="form-control selectCss" onFocus={this.removeError} onBlur={this.addError} required={indexInfoValidate ? indexInfoValidate.transactionCurrency.mandatory : false} value={this.state.transactionCurrency} onChange={this.handleInputChange} name="transactionCurrency" id="transactionCurrency">
                            <option value="">Please Select</option>
                            <option value="INR">INR</option>
                            <option value="HKD">HKD</option>
                            <option value="USD">USD</option>
                        </select>
                        <ErrorDisplay errors={this.state.errors} fieldName='transactionCurrency' className='errorClass' />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Transaction Amount</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                        <input type="number" placeholder="0" className="form-control" value={this.state.transactionAmount} onChange={this.handleInputChange} required={indexInfoValidate ? indexInfoValidate.transactionAmount.mandatory : false} onBlur={this.addError} onFocus={this.removeError} name="transactionAmount" id="transactionAmount" />
                        <ErrorDisplay errors={this.state.errors} fieldName='transactionAmount' className='errorClass' />
                    </div>
                    <div className="clearfix visible-lg"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Capture Under Product</span><br />
                        <select className="form-control selectCss" value={this.state.captureUnderProduct} onChange={this.handleInputChange} name="captureUnderProduct" id="captureUnderProduct">
                            <option value="">Please Select</option>
                            <option value="FNG">FNG</option>
                            <option value="APG">APG</option>
                            <option value="BBG">BBG</option>
                            <option value="PMG">PMG</option>
                        </select>
                    </div>
                    <div className="clearfix visible-md visible-sm"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">GTE Number</span><br />
                        <input type="text" className="form-control" value={this.state.sgNumber} onChange={this.handleInputChange} name="sgNumber" id="sgNumber" />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Expiry Date</span><br />
                        <DateField className="form-control" dateFormat="YYYY-MM-DD HH:mm:ss" forceValidDate={true} defaultValue={moment()} >
                            <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} highlightToday={true} weekNumbers={true} weekStartDay={0} />
                        </DateField>
                    </div>
                </CustomDiv>
            </form>
        );
    }
}

export default IndexingInformation;
