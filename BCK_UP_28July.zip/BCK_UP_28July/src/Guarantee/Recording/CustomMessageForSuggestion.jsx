import React from "react";
import ToolTip from 'react-portal-tooltip';

export default class Message extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isTooltipActive: false,
            open: false
        }
    }

    handleRequestClose = () => {
        this.setState({
            open: false,
        });
    };

    showTooltip() {
        this.setState({ isTooltipActive: true })
    }

    hideTooltip() {
        this.setState({ isTooltipActive: false })
    }

    render() {
        const {data, row, listViewData, toolTipViewData, searchTextLength, searchText, listMultipleData} = this.props;

        var style = {
            style: {
                padding: "20px",
                zIndex: "10000",
                boxShadow: "5px 5px 3px grey",
                fill: "#e2e2e2",
                width: "200px",
                outlineColor: "#cecece",
                borderTop: "solid 1px grey",
                borderBottom: "solid 1px grey",
                borderRight: "solid 1px grey",
                borderLeft: "solid 1px grey"
            },
            arrowStyle: {
            }
        };

        var parent = "#" + this.props.index;
        var searchTextIndex = data[row].toLowerCase().indexOf(searchText.toLowerCase());

        var newListData = listMultipleData.concat([]);
        var removeIndex = listMultipleData.indexOf(row);

        if (removeIndex > -1)
            newListData.splice(removeIndex, 1);

        return <div>
            <pre
                id={this.props.index}
                style={{ background: "none", border: "none", overflow: "hidden", maxWidth: "256px", height: "auto", whiteSpace: "pre-wrap" }}
                onMouseEnter={this.showTooltip.bind(this)}
                onMouseLeave={this.hideTooltip.bind(this)}
            >
                <span
                    style={{ fontFamily: "Muli", fontSize: "14px" }}
                >
                    {
                        searchTextIndex !== 0 ?
                            <span>
                                <span>
                                    {data[row].substring(0, searchTextIndex)}
                                </span>
                                <span style={{ fontWeight: "bolder" }}>
                                    {data[row].substring(searchTextIndex, searchTextIndex + searchTextLength)}
                                </span>
                            </span>
                            : <span style={{ fontWeight: "bolder" }}>
                                {data[row].substring(0, searchTextIndex + searchTextLength)}
                            </span>
                    }
                    {data[row].substring(searchTextIndex + searchTextLength, )}
                </span>
                <br />

                {
                    newListData.map(function (items, index) {
                        
                        return <span key={index}>
                            <span
                                style={{ fontFamily: "Muli", fontSize: "14px" }}
                            >
                                {data[items]}
                            </span>
                            <br />
                        </span>
                    })
                }

                {
                    listViewData.map(function (items, index) {
                        return <span key={index}>
                            <span
                                style={{ fontFamily: "Muli", fontSize: "14px" }}
                            >
                                {data[items]}
                            </span>
                            <br />
                        </span>
                    })
                }

            </pre >
            {this.props.toolTipVisible ?
            <ToolTip
                active={this.state.isTooltipActive}
                position="right"
                arrow="center"
                parent={parent}
                style={style}
            >
                {
                    toolTipViewData.map(function (items, index) {
                        
                        if(items.values.indexOf(row)==-1){
                            return <span key={index}>
                                <span
                                    style={{ fontFamily: "Muli", fontSize: "14px", fontWeight: "bolder" }}
                                >
                                    {items.label}
                                </span>
                                <br />
                                {
                                    items.values.map(function (itemsChild, index) {
                                        if (index + 1 === items.values.length)
                                            return <span key={index + items.values.length}>{data[itemsChild]}</span>
                                        else
                                            return <span key={index + items.values.length}><span>{data[itemsChild] + ","}</span><br /></span>
                                    })
                                }
                                <br />
                            </span>
                        }
                    })
                }
            </ToolTip > :""}
        </div>
    }
}

/* list view data
{
                row == "bankName" ?
                    <span>
                        <span
                            style={{ fontFamily: "Muli", fontSize: "14px" }}
                        >
                            {data["bankName"]}
                        </span>
                        <br />
                        <span
                            style={{ fontFamily: "Muli", fontSize: "14px" }}
                        >
                            {data["bankCode"]}
                        </span>
                        <br />
                        <span
                            style={{ fontFamily: "Muli", fontSize: "14px" }}
                        >
                            {
                                data["swiftAddress"] == "" ?
                                    <label>Non Swift</label>
                                    : data["swiftAddress"]
                            }
                        </span>
                        <br />
                    </span>
                    : null
            }
            {
                row == "bankCode" ?
                    <span>
                        <span
                            style={{ fontFamily: "Muli", fontSize: "14px", fontWeight: "bolder" }}
                        >
                            {data["bankCode"]}
                        </span>
                        <br />
                        <span
                            style={{ fontFamily: "Muli", fontSize: "14px" }}
                        >
                            {data["bankName"]}
                        </span>
                        <br />
                    </span>
                    : null
            }
            {
                row == "swiftAddress" ?
                    <span>
                        <span
                            style={{ fontFamily: "Muli", fontSize: "14px", fontWeight: "bolder" }}
                        >
                            {data["swiftAddress"]}
                        </span>
                        <br />
                        <span
                            style={{ fontFamily: "Muli", fontSize: "14px" }}
                        >
                            {data["bankName"]}
                        </span>
                        <br />
                    </span>
                    : null
            }
            <span
                style={{ fontFamily: "Muli", fontSize: "14px", color: "#4f4f4f" }}
            >
                {data["address1"]}
                ,&nbsp;
                    </span>
            <span
                style={{ fontFamily: "Muli", fontSize: "14px", color: "#4f4f4f" }}
            >
                {data["address2"]}
            </span>

            tooltip view data
                {
                row != "swiftAddress" ?
                    <span>
                        <span
                            style={{ fontFamily: "Muli", fontSize: "16px", fontWeight: "bolder" }}
                        >
                            Swift Adress :
                             </span>
                        <br />
                        {data["swiftAddress"]}
                        <br />
                    </span>
                    : null
            }
            <span
                style={{ fontFamily: "Muli", fontSize: "14px", fontWeight: "bolder" }}
            >
                Clearing Code :
                      </span>
            <br />
            {data["clearingCode"]}
            <br />
            <span
                style={{ fontFamily: "Muli", fontSize: "14px", fontWeight: "bolder" }}
            >
                Address :
                     </span>
            <br />
            <span
                style={{ fontFamily: "Muli", fontSize: "14px", color: "#4f4f4f" }}
            >
                {data["address3"]},
                    &nbsp;
                    </span>
            <span
                style={{ fontFamily: "Muli", fontSize: "14px", color: "#4f4f4f" }}
            >
                {data["address4"]}
            </span>
            */