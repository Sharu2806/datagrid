import * as ACTION_TYPES from '../GuaranteeActionTypes';

export function fetchRecordingDCData() {
    // console.log('fetch indexing data action');
    return dispatch => {
        fetch('json/manual.json').then(result => result.json()).then(body =>
            dispatch({
                type: ACTION_TYPES.GTE_RECORDINGDC_FETCH_RECORDINGDC_DATA,
                payload: body
            })
        );
    }
}

export function saveDefinitionCriteriaData(obj) {
    // console.log('save BASIC data action');
    return {
        type: ACTION_TYPES.GTE_RECORDINGDC_SAVE_DEFINITION_CRITERIA_DATA,
        payload: obj
    };
}

export function generateDCNumber(obj) {

    //console.log('save generateDCNumber action :: ', obj);

    var accountNumber = obj.accountNumber;

    var productType = 'FNG';
    var transactionNumber2 = obj.transactionNumber2;
    var transactionNumber = obj.transactionNumber;
    var processType = 'a';
    var transaction = 'a';
    var url = "http://10.191.131.54:8081/hie/recording?accountNo=" + accountNumber + "&productType=" + productType + "&processType=" + processType + "&transaction=" + transaction + "&transactionNumber=" + transactionNumber + "&transactionNumber2=" + transactionNumber2;
    // console.log("SI URL is :: ", url);
    return dispatch => {
        fetch(url)
            .then(result => result.json())
            .then(body =>
                dispatch({
                    type: ACTION_TYPES.GTE_RECORDINGDC_GENERATE_RECORDING_DC_NUMBER,
                    payload: body[0]
                })
            ).catch(error => errorCall(error));
        fetch("json/recording.json")
            .then(result => result.json()).then(body =>
                dispatch({
                    type: ACTION_TYPES.GTE_RECORDINGDC_FETCH_WDM_DATA,
                    payload: body
                })
            ).catch(error => errorCall(error));
    }
}

function errorCall(error) {
    alert(error)
}
