import React, { Component } from 'react';
import { DateField } from 'react-date-picker';
import { connect } from "react-redux";

import DatePicker from 'react-datepicker';
import moment from 'moment';

import * as Utils from '../../common.js';

import ErrorDisplay from '../../SharedComponents/ErrorDisplay';

var basicInfoValidate = {
    "applicantName": { mandatory: true },
    "dateofIssue": { mandatory: true },
    "gteCurrency": { mandatory: true },
    "gteAmount": { mandatory: true },
    "applicantAddress": { mandatory: true },
    "address": { mandatory: true }
};

export class BasicInformation extends Component {

    constructor(props) {
        super(props);
        this.state = {
            applicantName: '',
            applicantAddress: '',
            applicantAddress1: '',
            applicantAddress2: '',
            beneficiaryNameSearch: '',
            address: '',
            address1: '',
            address2: '',
            country: '',
            customerReference: '',
            expiryDate: '',
            dateofIssue: '',
            dateofApplication: '',
            gteCurrency: '',
            gteAmount: '',
            errors: []
        };

        this.addError = this.addError.bind(this);
        this.removeError = this.removeError.bind(this);

        this.handleChange = this.handleChange.bind(this);
        let errorFromJson = [];
    }

    componentWillMount() {
        this.setState({
            ...this.props.inputData
        });
    }

    componentDidMount() {
        this.props.onRef(this);
        this.setState({
            ...this.props.inputData
        });
        fetch('json/basicInfoRecord.json', {
            method: 'GET'
        })
            .then(result => result.json())
            .then(body => this.saveError(body));
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            ...nextProps.inputData
        });
        if (nextProps.outputData && nextProps.outputData.status === "success") {
            this.props.history.push('/recording');
        }
    }

    componentWillUnmount() {
        this.props.onRef(undefined)
    }

    addError(event) {
        Utils.addError(event, this);
    }

    handleChange(event) {
        Utils.handleChange(event, this);
    }

    // removes error when the input field gets focussed with obj:{fieldName:abc, error:xyz}
    removeError(event) {
        Utils.removeError(event, this);
    }

    saveData() {
        if (Utils.validateErrors(this)) {
            this.props.saveBasicInfoData(this.state)
        }
    }

    saveError(body) {
        this.errorFromJson = body
    }

    render() {

        var countryList = [];
        var guaranteeCurrencyList = [];
        var dropDownObj = this.props.recordingDropDownData;
        if (dropDownObj) {
            var recordingObj = dropDownObj.GTE_Recording;
            var obj = null;
            var optionObj = null;
            if (recordingObj.Country) {
                for (var i = 0; i < recordingObj.Country.length; i++) {
                    obj = recordingObj.Country[i]
                    optionObj = <option value={obj.code} key={i}>{obj.DropDownValue}</option>
                    countryList.push(optionObj)
                }
            }
            if (recordingObj.GuaranteeCurrency) {
                for (i = 0; i < recordingObj.GuaranteeCurrency.length; i++) {
                    obj = recordingObj.GuaranteeCurrency[i]
                    optionObj = <option value={obj.code} key={i}>{obj.DropDownValue}</option>
                    guaranteeCurrencyList.push(optionObj)
                }
            }
        }

        return (
            <div>
                <form style={{ paddingTop: "20px" }}>
                    {/*Basic Information*/}
                    <div className="row" >
                        <div className="col-md-12 col-lg-12">
                            <span className="Muli-Bold" style={{ fontSize: '16px' }}>Basic Information</span>
                            <hr style={{ borderColor: '#919191', marginTop: '1px' }} />
                        </div>
                    </div>
                    {/*Applicant Name*/}
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Applicant Name</span>
                            &nbsp;<span style={{ color: 'red' }}>*</span>
                            <input type="text" className="form-control" required={basicInfoValidate ? basicInfoValidate.applicantName.mandatory : false} onBlur={this.addError} onFocus={this.removeError} value={this.state.applicantName} onChange={this.handleChange} name="applicantName" id="applicantName" />
                            <ErrorDisplay errors={this.state.errors} fieldName='applicantName' className='errorClass' />
                            <div className="label-margin-below row-margin" style={{ fontSize: "14px", color: "#000000" }}>Applicant Address<span style={{ color: 'red' }}> &nbsp;*</span></div>
                            <input type="text" className="form-control" value={this.state.applicantAddress} required={basicInfoValidate ? basicInfoValidate.applicantAddress.mandatory : false} onBlur={this.addError} onFocus={this.removeError} onChange={this.handleChange} name="applicantAddress" id="applicantAddress" />
                            <ErrorDisplay errors={this.state.errors} fieldName='applicantAddress' className='errorClass' />
                            <input type="text" className="form-control" value={this.state.applicantAddress1} onChange={this.handleChange} name="applicantAddress1" id="applicantAddress1" />
                            <input type="text" className="form-control" value={this.state.applicantAddress2} onChange={this.handleChange} name="applicantAddress2" id="applicantAddress2" />
                        </div>
                        <div className="col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below row-margin" style={{ fontSize: "14px", color: "#000000" }}>Beneficiary Name</span>
                            <input type="text" className="form-control" value={this.state.beneficiaryNameSearch} onChange={this.handleChange} name="beneficiaryNameSearch" id="beneficiaryNameSearch" />
                            <div className="label-margin-below row-margin" style={{ fontSize: "14px", color: "#000000" }}>Address<span style={{ color: 'red' }}> &nbsp;*</span></div>
                            <input type="text" className="form-control" value={this.state.address} required={basicInfoValidate ? basicInfoValidate.address.mandatory : false} onBlur={this.addError} onFocus={this.removeError} onChange={this.handleChange} name="address" id="address" />
                            <ErrorDisplay errors={this.state.errors} fieldName='address' className='errorClass' />
                            <input type="text" className="form-control" value={this.state.address1} onChange={this.handleChange} name="address1" id="address1" />
                            <input type="text" className="form-control" value={this.state.address2} onChange={this.handleChange} name="address2" id="address2" />
                            <div className="label-margin-below row-margin" style={{ fontSize: "14px", color: "#000000" }}>Country</div>
                            <select className="form-control selectCss" name="country" id="country">
                                {countryList}
                            </select>
                        </div>
                    </div>
                    {/* Customer Reference*/}
                    <br /><hr style={{ borderColor: '#919191', marginTop: '1px' }} />
                    <div className="row">
                        <div className="row-margin col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Customer Reference</span>
                            <input type="text" className="form-control" value={this.state.customerReference} onChange={this.handleChange} name="customerReference" id="customerReference" />
                        </div>
                        <div className="row-margin col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Expiry Date</span>&nbsp;<span style={{ color: 'red' }}>*</span>   <br />
                            <DateField className="form-control" dateFormat="YYYY-MM-DD" forceValidDate={true} defaultValue={moment('2017-07-06')} minDate={moment()} name="expiryDate" id="expiryDate">
                                <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} highlightToday={true} weekNumbers={true} weekStartDay={0} />
                            </DateField>
                        </div>
                        <div className="row-margin col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Date Of Issue</span> &nbsp;<span style={{ color: 'red' }}>*</span>  <br />
                            <DateField className="form-control" dateFormat="YYYY-MM-DD" forceValidDate={true} defaultValue={moment('2017-07-05')} maxDate={moment()} name="dateofIssue" id="dateofIssue">
                                <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} weekNumbers={true} weekStartDay={0} />
                            </DateField>
                            <ErrorDisplay errors={this.state.errors} fieldName='dateofIssue' className='errorClass' />
                        </div>
                        <div className="clearfix visible-md"></div>
                        {/*Date of Application*/}
                        <div className="row-margin col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Date of Application</span> &nbsp;<span style={{ color: 'red' }}>*</span>  <br />
                            <DateField className="form-control" dateFormat="YYYY-MM-DD" forceValidDate={true} defaultValue={moment('2017-07-07')} maxDate={moment()} name="dateofApplication" id="dateofApplication">
                                <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} weekNumbers={true} weekStartDay={0} />
                            </DateField>
                        </div>
                        <div className="clearfix visible-lg"></div>
                        <div className="row-margin col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Guarantee Currency</span>&nbsp;<span style={{ color: 'red' }}>*</span>   <br />
                            <select className="form-control selectCss" name="gteCurrency" required={basicInfoValidate ? basicInfoValidate.gteCurrency.mandatory : false} onBlur={this.addError} onFocus={this.removeError} value={this.state.gteCurrency} onChange={this.handleChange} id="gteCurrency">
                                {guaranteeCurrencyList}
                            </select>
                            <ErrorDisplay errors={this.state.errors} fieldName='gteCurrency' className='errorClass' />
                        </div>
                        {/*Guarantee Amount */}
                        <div className="row-margin col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Guarantee Amount</span>&nbsp;<span style={{ color: 'red' }}>*</span>
                            <input type="text" className="form-control" required={basicInfoValidate ? basicInfoValidate.gteAmount.mandatory : false} onBlur={this.addError} onFocus={this.removeError} value={this.state.gteAmount} onChange={this.handleChange} name="gteAmount" id="gteAmount" />
                            <ErrorDisplay errors={this.state.errors} fieldName='gteAmount' className='errorClass' />
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}

function mapStateToProps(store) {
    return {
        recordingDropDownData: store.recordingReducer.recordingDropDownData
    }
}

export default connect(mapStateToProps)(BasicInformation);
