import React from "react";
import CustomAutoComplete from "./CustomAutoComplete.jsx";
import IconButton from "material-ui/IconButton";
import Clear from "material-ui/svg-icons/content/clear";
import { connect } from "react-redux";
import * as Actions from "./Actions/bankInputAction.js";

class CustomSuperSelect extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            dataSourceConfig: [],
            dataSource: [],
            inputValue: '',
            searchText: this.props.searchText
        }
        this.clearBankName = this.clearBankName.bind(this);
        this.onNewRequest = this.onNewRequest.bind(this);
        this.onUpdateInput = this.onUpdateInput.bind(this);
    }

    clearBankName() {
        this.setState({ searchText: "" });
        this.props.dispatch(Actions.clearSearch());
        this.props.showData({
            "address1":"",
            "address2":"",
            "address3":""
        });
    }


    componentWillMount() {
    }

    componentDidMount() {
        var nonSwiftData = [];
        var swiftData = [];
        this.props.listData.forEach((item, index) => {
            if (item.swiftAddress === "")
                nonSwiftData.push(item);
            else
                swiftData.push(item);
        })

        var alphaSortData = this.sortAlphabatically(swiftData,this.props.sortDataBy);
        var alphaSortData2 = this.sortAlphabatically(nonSwiftData,this.props.sortDataBy);
        var combinedAlphaSortData = alphaSortData.concat(alphaSortData2);
        
        this.props.dispatch(Actions.setSource(combinedAlphaSortData));
        this.setState({ dataSource: combinedAlphaSortData });
    }

    sortAlphabatically(alphaSortData,sortBy) {
        alphaSortData.sort(function (firstChild, secondChild) {
            var first = firstChild[sortBy].toLowerCase();
            var second = secondChild[sortBy].toLowerCase();
            return first < second ? -1 : first > second ? 1 : 0;
        });
        return alphaSortData;
    }

    onNewRequest(value) {
		this.props.showData(value);
        this.props.dispatch(Actions.setDetailsAccToBankName(value));
    }

    onUpdateInput(inputValue) {
        if (inputValue === "") {
            this.setState({ dataSource: [] });
        }
        else {
        
            if (this.state.dataSource.length === 0) {
                this.setState({ dataSource: this.props.dataSource, searchText: inputValue });
            }
            else {
                this.setState({ searchText: inputValue });
            }
        }
    }

    render() {

        
        var dataConfig = {
            text: this.props.type,
        }
        var alphaSortData = this.state.dataSource;
        var sortValue = this.props.storeCountryCode;
    
        var countryCodeSortData = [];
        var hintText = "Enter ";

        if(this.props.dropDownVisibleFor!=undefined){
        if (this.props.type === this.props.dropDownVisibleFor) {
            if (sortValue === "All") {
                countryCodeSortData = this.state.dataSource;
            }
            else if (sortValue !== "") {
                alphaSortData.forEach((item) => {
                    if (item.countryCode === sortValue) {
                        countryCodeSortData.push(item);
                    }
                });
            }
            else {

                countryCodeSortData = this.state.dataSource;
            }
        } else {
            countryCodeSortData = this.state.dataSource;
        }
        }

        var myPropType = this.props.type.split(/(?=[A-Z])/);

        // if(propType!=null)
         hintText += myPropType[0].substring(0,1).toUpperCase()+myPropType[0].substring(1,)+" "+myPropType[1]

        /*if (this.props.type === "bankCode")
            hintText += "Bank Code"
        else if (this.props.type === "bankName")
            hintText += "Bank Name"
        else
            hintText += "Swift Address"*/

        return <div className="row">
            <div className="col-md-4">
            <CustomAutoComplete
                { ...this.props}
                style={{ float: "left" }}
                dataSource={countryCodeSortData}
                searchText={this.state.searchText}
                dataSourceConfig={dataConfig}
                searchByNumberOfAlphabets={this.props.searchByChars}
                totalData = {countryCodeSortData}
                disableFocusRipple={true}
                customSearch={this.props.type}
                hintText={hintText}
                onUpdateInput={this.onUpdateInput}
                onNewRequest={this.onNewRequest}
                filter={CustomAutoComplete.caseInsensitiveFilter}
                customOpen={this.props.customOpen}
            />
            <IconButton style={{marginLeft:"-40px",marginTop:"5px"}} onClick={this.clearBankName}><Clear /></IconButton>
            </div>
        </div>
    }
}

function mapStateToProps(store) {
    return {
        dataSource: store.bankReducer.inputData.source,
        storeCountryCode: store.bankReducer.inputData.countryCode,
        customOpen: store.bankReducer.inputData.customOpen,
        searchText :  store.bankReducer.inputData.searchText
    }
}

export default connect(mapStateToProps)(CustomSuperSelect);