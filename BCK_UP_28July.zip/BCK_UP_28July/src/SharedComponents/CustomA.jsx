import React from 'react';
import PropTypes from 'prop-types';

const CustomA = (props) => (
<span>
  {
    !props['data-suppressfield']  &&
      <a {...props}>
        {props.children}
      </a>
  }
</span>
);

CustomA.propTypes = {
  'data-suppressfield': PropTypes.bool
};

export default CustomA;
