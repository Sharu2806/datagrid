import React, { Component } from 'react';

export class DynamicSelect extends Component {
  render() {
    var props = this.props;
    var optionsData = props['data-childOptions'];
    var optionsList = [];
    var defaultOption = <option value="" >Please Select</option>
    optionsList.push(defaultOption);
    if (optionsData) {
      for (var i = 0; i < optionsData.length; i++) {
        var obj = optionsData[i]
        var optionObj = <option value={obj.code} key={i}>{obj.DropDownValue}</option>
        optionsList.push(optionObj);
      }
    }
    return (
      <span>
        <select {...props}>
          {optionsList}
        </select>
      </span>
    )
  }
}
export default DynamicSelect;
