import React, { Component } from 'react';

class RecordingInformationAfterDC extends Component {
    render() {
        var data = this.props.wdmData;
        var siData = this.props.workItemData;
        return (
            <div className="well" style={{ backgroundColor: 'white', border: '1px solid #e3e3e3', borderRadius: '5px', minHeight: '138px', color: 'black' }}>
                <div className="row">
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 Muli-SemiBold">
                        <embed src="icons/work-item.svg" alt="" height="36px" width="36px" />
                        <span style={{ fontSize: '24px', position: 'relative', top: '-10px' }}>
                            GTE Reference No. - {siData.gtReferenceNo}
                        </span>
                    </div>
                </div>
                <br />
                <div className="row" style={{ fontSize: '14px' }}>
                    <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">Work Item</span> - {data.workItemRef}
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">Version</span> - {siData.version}
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">Target Time</span> - {data.targetTime}
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">A/C No.</span> - {siData.accountNo}
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">Applicant</span> - {data.applicant}
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">Deal No.</span> - {siData.dealNumber}
                    </div>
                </div>
            </div>
        );
    }
}

export default RecordingInformationAfterDC;