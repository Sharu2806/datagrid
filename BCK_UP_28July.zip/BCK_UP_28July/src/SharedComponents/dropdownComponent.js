import React, { Component } from 'react';

export default class InputDropdownComponent extends Component {
  constructor(props){
    super(props);
    this.state = {
      listOptions:props.payload,
      selectedValue:''
  };
  this.onChange = this.onChange.bind(this);
  }

  AddOptions(options, keyVal){

    return(
      <option className="idDropdown" key={keyVal}  value={options.value}>{options.value}</option>
    );
  }


  itemClickHandler(event,item){

   this.props.validateDropdown(event.target.innerHTML,item)
  }
    onChange(event){

      if(event.target.value===""){
        this.setState({selectedValue:""});
      }else{
        this.setState({selectedValue:event.target.value});
      }
      this.itemClickHandler(event, this.state.listOptions[event.target.selectedIndex]);
    }
    render() {
      if(!this.props.payload){
        return(
        <div>Loading.....</div>
      )
      }
      else{
        return (

            <div>
            <select onChange={this.onChange} style={{width: '200px' ,height: '30px'}}> {this.state.listOptions.map(this.AddOptions)}</select>
           </div>
        );
      }
    }
}
