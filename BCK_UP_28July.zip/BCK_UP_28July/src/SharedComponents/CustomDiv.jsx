import React from 'react';
import PropTypes from 'prop-types';

const CustomDiv = (props) => (
<span>
  {
    !props['data-suppressfield']  &&
      <div {...props}>
        {props.children}
      </div>
  }
</span>
);

CustomDiv.propTypes = {
  'data-suppressfield': PropTypes.bool
};

export default CustomDiv;
