import React from 'react';
import PropTypes from 'prop-types';
import ErrorDisplay from './ErrorDisplay';

const CustomSelect = (props) => (
  <span>
    {
      !props['data-suppressfield'] &&
      <span className={props['data-controlclass']}>
        {props.title && props['data-labelclass'] ?
          <span className={props['data-labelclass']} htmlFor={props.name}>
            {props.title}{props.required ? <span style={{color:"red"}}>*</span> : ''}
          </span>
          :
          <span style={props['data-labelStyle']}>
            {props.title}{props.required ? <span style={{color:"red"}}>*</span> : ''}
          </span>
        }
        <select {...props}>
          {props.children}
        </select>
        <span><ErrorDisplay className="errorClass" errors={props['error-msg']} fieldName={props.name} /></span>
      </span>
    }
  </span>
);

CustomSelect.propTypes = {
  'data-suppressfield': PropTypes.bool,
  'data-controlclass': PropTypes.string,
  'data-labelclass': PropTypes.string,
  'error-msg':PropTypes.array
};

export default CustomSelect;
