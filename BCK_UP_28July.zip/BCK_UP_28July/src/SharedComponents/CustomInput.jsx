import React from 'react';
import PropTypes from 'prop-types';
import ErrorDisplay from './ErrorDisplay';

const CustomInput = (props) => (
  <span>
    {
      !props['data-suppressfield'] &&
      <span className={props['data-controlclass']}>
        {props.title && props['data-labelclass'] ?
          <span className={props['data-labelclass']} htmlFor={props.name}>
            {props.title}{props.required ? '*' : ''}
          </span>
          :
          <span style={props['data-labelStyle']}>
            {props.title}{props.required ? '*' : ''}
          </span>
        }
        <input  {...props} />
        <span><ErrorDisplay className="errorClass" errors={props['error-msg']} fieldName={props.name} /></span>
      </span>
    }
  </span>
);

CustomInput.propTypes = {
  'data-suppressfield': PropTypes.bool,
  'data-controlclass': PropTypes.string,
  'data-labelclass': PropTypes.string,
  'error-msg': PropTypes.array
};

export default CustomInput;
