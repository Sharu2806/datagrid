
export function formatDate(dateString) {
    //var dateString = '2017-06-29 15:00:29';
    if (dateString) {
        var dateTimeParts = dateString.split(' ');
        var timeParts = dateTimeParts[1].split(':');
        var dateParts = dateTimeParts[0].split('-');
        var date = new Date(dateParts[0], parseInt(dateParts[1], 10) - 1, dateParts[2], timeParts[0], timeParts[1], timeParts[2]);

        //console.log("Data :: ", date.getTime()); //1379426880000
        return date.getTime();
    }
}