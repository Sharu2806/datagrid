import React, { Component } from 'react';
import { connect } from 'react-redux';

import RecordInformation from '../../SharedComponents/RecordInformation';
import DefintionCriteria from './DefinitionCriteria';

import {
    fetchRecordingData,
    saveDefinitionCriteriaData,
    generateDCNumber
} from './RecordingImportBillActions';

class RecordingImportBill extends Component {

    componentDidMount() {
        this.props.fetchRecordingData();
    }

    render() {
        return (
            <div className="row">
                <div className="panel panel-holding-tabs">
                    {
                        this.props.allRecordingData &&
                        <RecordInformation
                            gwisId="TTHKHBAP15123-000946P27"
                        />
                    }
                    <ul id="indexingTabs" className="nav nav-tabs" onClick={this.handleTabClick} style={{ overflow: 'hidden', position: 'relative', top: '1px' }}>
                        <li className="active"><a data-toggle="tab" href="#definitionCriteria">Definition Criteria</a></li>
                    </ul>
                </div>
                <div style={{ marginLeft: '30px', marginRight: '30px' }}>
                    {
                        this.props.allRecordingData &&
                        <DefintionCriteria
                            history={this.props.history}
                            inputData={this.props.allRecordingData.definitionCriteria}
                            generateDCNumber={this.props.generateDCNumber}
                            saveDefinitionCriteriaData = {this.props.saveDefinitionCriteriaData}
                            outputData={this.props.allRecordingData.outputData}
                        />
                    }
                </div>
            </div>
        );
    }
}

const mapsStateToProps = (state) => {
    return {
        allRecordingData: state.recordingImportBillReducers
    };
};

const mapsDispatchToProps = (dispatch) => {
    return {
        fetchRecordingData: () => {
            dispatch(fetchRecordingData());
        },
        generateDCNumber: (obj) => {
            dispatch(generateDCNumber(obj));
        },
        saveDefinitionCriteriaData : (obj) => {
            dispatch(saveDefinitionCriteriaData(obj));
        }

    
    };
};

export default connect(mapsStateToProps, mapsDispatchToProps)(RecordingImportBill);
