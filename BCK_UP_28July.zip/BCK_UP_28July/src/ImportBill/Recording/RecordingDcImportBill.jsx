import React, { Component } from 'react';
import { connect } from 'react-redux';
import ImportBillRecordInformationAfterDC from '../../SharedComponents/ImportBillRecordInformationAfterDC';
import * as ACTIONS from './RecordingImportBillActions';
import SpecialInstructionRecording from './SpecialInstructionRecording';
import SpecialInstruction from '../../Guarantee/Recording/SpecialInstruction';
import ImportBillRecordBasicIn from './ImportBillRecordBasicIn';

class RecordingDcImportBill extends Component {

    constructor(props) {
        super(props);
        
        this.currentActiveTab = 'basicInfo';
        this.navigate = this.navigate.bind(this);
        this.handleTabClick = this.handleTabClick.bind(this);
        this.handleSaveClick = this.handleSaveClick.bind(this);
        this.handleSubmitClick = this.handleSubmitClick.bind(this);
    }

    componentDidMount() {
        window.scrollTo(0, 0);
        this.props.fetchRecordingDataDC();
        document.getElementById("specialInst").style.display = "block";
    }

    navigate() {
        this.props.history.push('/importbilldcrecording');
    }

    handleTabClick(event) {
    }

     handleSaveClick() {
    }

    handleSubmitClick() {
    }

    render() {
        var acc ="";
        {this.props.headerData.accountNumber_cn !== '' ?
         acc= this.props.headerData.accountNumber.substring(0,2) + " " + this.props.headerData.accountNumber.substring(2,6) 
                + " " + this.props.headerData.accountNumber.substring(6,9)  + - + this.props.headerData.accountNumber.substring(9,15) 
                 + - this.props.headerData.accountNumber.substring(15,19): ''}
      
        return (
            
            <div>
               {/* <SpecialInstructionRecording specialInstruction ={this.props.workItemData.specialInstruction}/>*/}

               <SpecialInstruction specialInstructionData ={this.props.workItemData} accountNumber={this.props.headerData.accountNumber}/>
                <div className="row" style={{ marginTop: "-25px" }}>   
                    <div className="panel panel-holding-tabs">
                         <ImportBillRecordInformationAfterDC
                            billNo={
                            this.props.headerData.transactionNumber !== '' ? this.props.headerData.productType + this.props.headerData.issuanceBranch + 
                            this.props.headerData.transactionNumber + this.props.headerData.transactionNumberUn : 'BR DAK 455096DAK'
                            }
                            acNo={this.props.headerData.accountNumber_cn !== '' ? acc : 'AB HSBC 123-123456-123'}
                            dcNo={this.props.headerData.dcNumber2  !== '' ? this.props.headerData.dcNumber : 'DPCDAK123456'}
                        />
                        <ul id="recordingTabs" className="nav nav-tabs" style={{ overflow: 'hidden', position: 'relative', top: '1px' }}>
                           <li className="active"><a data-toggle="tab" href="#basicInfo">Basic Info.</a></li>
                            <li><a data-toggle="tab" href="#bankInfo">Usance Discripencies</a></li>
                              <li><a data-toggle="tab" href="#bankInfo">Internal Info</a></li>
                                <li><a data-toggle="tab" href="#bankInfo">Bill Charges</a></li>
                                  <li><a data-toggle="tab" href="#bankInfo">Add. Fields for Wolf Compilation Scan</a></li>
                           
                        </ul>
                    </div>

                    <div className="tab-content" style={{ marginLeft: '30px', marginRight: '30px', marginBottom: '180px' }}>
                        <div id="basicInfo" className="tab-pane fade in active">
                           <ImportBillRecordBasicIn />
                    </div>
                     <div id="bankInfo" className="tab-pane fade">
                         
                            
                        </div>
                    </div>
                    </div>

                    <div
                        className={"col-xs-12 col-sm-9 col-md-10 col-lg-10 pull-right navbar-fixed-bottom bottom-buttons-layout"}>
                        <div className="btn-toolbar" style={{ marginLeft: '40px' }}>
                            <button className="btn btn-green" onClick={this.handleSaveClick} ><embed className="icon" src="icons/save.svg" alt="" /><span className="buttonLabel">Save</span></button>
                            <button className="btn btn-green" onClick={this.handleSubmitClick} ><embed className="icon" src="icons/send.svg" alt="" /><span className="buttonLabel">Send</span></button>
                            <button className="btn btn-grey"><embed className="icon" src="icons/send-assign.svg" alt="" /><span className="buttonLabel">Send &amp; Assign</span></button>
                            <button className="btn btn-grey"><embed className="icon" src="icons/hold.svg" alt="" /><span className="buttonLabel">Hold</span></button>
                            <button className="btn btn-grey"><embed className="icon" src="icons/open_image.svg" alt="" /><span className="buttonLabel">Show Image</span></button>
                            <button className="btn btn-grey"><embed className="icon" src="icons/cancel.svg" alt="" /><span className="buttonLabel">Cancel</span></button>
                            <button className="btn btn-grey"><embed className="icon" src="icons/assign.svg" alt="" /><span className="buttonLabel">Assign</span></button>
                            <button className="btn btn-grey"><embed className="icon" src="icons/copy.svg" alt="" /><span className="buttonLabel"> Copy</span></button>
                        </div>
                    </div>
                </div>
        );
    }
}
const mapsStateToProps = (state) => {
    console.log('state here ', JSON.stringify(state.recordingImportBillReducers.outputData[0]));
    if (state.recordingImportBillReducers)
        return {
            workItemData: state.recordingImportBillReducers.outputData[0],
            headerData: state.recordingImportBillReducers.definitionCriteria

        }
    else
        return {
            workItemData: null,
        }
};

const mapsDispatchToProps = (dispatch) => {
    return {
         fetchRecordingDataDC: () => {
            dispatch(ACTIONS.fetchRecordingDataDC());
        }
        
    };
};
export default connect(mapsStateToProps, mapsDispatchToProps)(RecordingDcImportBill);