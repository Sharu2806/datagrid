import React, { Component } from 'react';
import SerialNoTextFields from './createserialno.js';
import './style.css';
import { createSerialNo,serialNoToBeUpdated,displaySerialNumberData , sendData } from './Actions/action-serialnumber';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';



class ContainerForCreateSerialNo extends Component {

  constructor(props){
      super(props);
      this.state ={
        id : {},
        minval :{},
        maxval : {},
        allocno : {},
        isMinVal : {},
        isMaxVal : {},
        isAllocNo : {},
        isInBetween : {},
        tableData : []
      }
      this.onhandleChange = this.onhandleChange.bind(this);
      this.onSubmitCreateSerialNo = this.onSubmitCreateSerialNo.bind(this);
      this.onBlur = this.onBlur.bind(this);
        //  if(this.props.dataFromView.tableData.productList.length != 0){
        //      let min = {};
        //      let max= {};
        //      let alloc ={};
        //      let id={};
        //      this.props.dataFromView.tableData.productList.map((data,i) =>{
        //        id[i] =data.id;
        //        min[data.id] = data.minValue;
        //        max[data.id] = data.maxValue;
        //       alloc[data.id] = data.lastNoAllo;
        //        this.state.tableData[i] = [{
        //          productType : data.productType,
        //            id : data.id
         //
        //        }];
        //      });
         //
        //     this.state.minval = min;
        //      this.state.maxval = max;
        //      this.state.id = id;
        //      this.state.allocno = alloc;
        //      console.log( this.state.tableData);
         //
        //  }else{
          this.state.tableData =[
            [{productType: 'Import Documentary Credits' ,id:'1'}],
            [{productType: 'Import Bill', id:'2'}],
            [{productType: 'Import Shipping Guarantee',id:'3'}],
            [{productType: 'Import Loan',id:'4'}],
            [{productType: 'Import Marginal Deposit',id:'5'}],
            [{productType: 'Export Bill',id:'6'}],
            [{productType: 'Export Loan',id:'7'}],
            [{productType: 'Export Marginal Deposit',id:'8'}]

          ]
          this.state.txtid = [1,2,3,4,5,6,7,8];
      // }

  }

/* validation of all fields general */
  validateData(value){
    let isValid = false;
    if(value === '' || value === undefined || value === 'undefined'){
      isValid = false;
    }else{
      isValid = true;
    }
    return isValid;
  }

  validateMinVal(min,id){
    let flag = this.validateData(min);
    let setmin = this.state.isMinVal;
    setmin[id] = flag;
    this.setState({isMinVal:setmin});
  }

 /* validation of max val in splc case */
  validateMaxVal(max,id){
  let flag = false;
  let tempval = this.state.isMaxVal;
  //let tempalloc = this.state.isInBetween;
  //let tempmin = this.state.isMinVal;

    if(!this.validateData(max)){
      flag = false;
    }else{
      flag = true;
    }

    // Compare with minval
    if(this.state.minval[id] != undefined){
         if(parseInt(max) > parseInt(this.state.minval[id])  && parseInt(this.state.minval[id]) !== parseInt(max)){
           flag = true;
         }else{
         flag = false;
         }
     }
     else{
         flag = false;
     }


    if(flag){
        tempval[id] = flag;
        this.setState({isMaxVal:tempval});
    }else{
      tempval[id] = flag;
      this.setState({isMaxVal:tempval});
    }

}

  /* validation of alloc in splc case */
  validateAllocNo(value,id){
    let isEmpty = this.state.isAllocNo;
    let isValid = this.state.isInBetween;

    if(this.state.maxval[id] != undefined && this.state.minval[id] != undefined){
      if(parseInt(value) >= parseInt(this.state.minval[id]) && parseInt(value) <= parseInt(this.state.maxval[id])){
        isValid[id]= true;
      }else{
        isValid[id]= false;
      }
      isEmpty[id]= true;
    }else{
      isValid[id]= false;
    }

    this.setState({isAllocNo:isEmpty});
    this.setState({isInBetween:isValid});

  }

 /* On Change setting State */
  onhandleChange(event){
    let value = event.target.value;
    let name = event.target.name;
    let str = event.target.id;
    let substr = str.lastIndexOf('_');
  let id = str.substring(substr +1);
    if(value.length > 6){
      value = value.slice(0,6);
    }

    if(name === "min_val"){
      let obj  = this.state.minval;
      obj[id] = value;
      this.validateMinVal(value, id);
      console.log(obj);
      this.setState({minval : obj});
      console.log(this.state.minval);
    }else if(name === "max_val"){
        debugger;
        let obj  = this.state.maxval;
        this.validateMaxVal(value , id);
        obj[id] = value;
        this.setState({maxval : obj});
    }else if(name === "alloc_no"){
        let obj  = this.state.allocno;
        this.validateAllocNo(value , id);
        obj[id] = value;
        this.setState({allocno : obj});
    }
    if(this.state.minval[id] && this.state.maxval[id] && this.state.allocno[id]){
        if(!this.state.id.hasOwnProperty(id)){
          let obj  = this.state.id;
          obj[id] = id;
          this.setState({id : obj});
        }
    }


  }

 /* On End editing Logic- Prefixing 0000..  */
   onBlur(e) {
    let name = e.target.name;
    let str = e.target.id;
    let value = e.target.value;
    let substr = str.lastIndexOf('_');
    let id = str.substring(substr +1);

    if(value.length < 6 || value != '' && value != undefined){
      let s = "00000" + value;
      s = s.substr(s.length-6);
      if(name === "min_val"){
        let obj  = this.state.minval;
        obj[id] = s;
        this.setState({minval : obj});
      }else if(name === "max_val"){
        let obj  = this.state.maxval;
        obj[id] = s;
        this.setState({maxval : obj});
      }else if(name === "alloc_no"){
        let obj  = this.state.allocno;
        obj[id] = s;
        this.setState({allocno : obj});
      }
    }

  }
 /* On submit Validation */
  onSubmitCreateSerialNo(){


    debugger;
    let minobj = this.state.isMinVal;
    let maxobj = this.state.isMaxVal;
    let allocobj = this.state.isAllocNo;
    let alldataobj = {};
    this.state.txtid.map((id)=>{
        if(this.state.minval.hasOwnProperty(id)){
              this.validateMinVal(this.state.minval[id],id);
        }else{
          minobj[id] = false;
        }
        if(this.state.maxval.hasOwnProperty(+id)){
              this.validateMaxVal(this.state.maxval[id],id);
        }else{
          maxobj[id] = false;
        }
        if(this.state.allocno.hasOwnProperty(id)){
              this.validateAllocNo(this.state.allocno[id],id);
        }else{
          allocobj[id] = false;
        }
        });
        this.setState({isMinVal:minobj});
        this.setState({isMaxVal:maxobj});
        this.setState({isAllocNo:allocobj});


        let minflag = [];
        for(let key in this.state.isMinVal){
          if(this.state.isMinVal.hasOwnProperty(key) && this.state.isMinVal[key] !== false){
            minflag.push(true);
          }
        }


        let maxflag = [];
        for(let key in this.state.isMaxVal){
          if(this.state.isMaxVal.hasOwnProperty(key) && this.state.isMaxVal[key] !== false){
            maxflag.push(true);
          }
        }


        let allocflag = [];
        for(let key in this.state.isMaxVal){
          if(this.state.isAllocNo.hasOwnProperty(key) && this.state.isAllocNo[key] !== false){
            allocflag.push(true);
          }
        }

        if(minflag.length === 8 && maxflag.length ===8 &&  allocflag.length ===8){
            this.dataToPost(alldataobj);
        }
  }

  dataToPost(data){
    console.log(data);
    let dataObj = {};
    let productList = [];

    this.state.txtid.map((data ,i)=>{
      productList.push({
               id : this.state.id[i],
               minValue : this.state.minval[i],
               maxVal: this.state.maxval[i],
               allocNo: this.state.allocno[i]
        });
    });
    dataObj = {
      //   businessId : this.props.dataFromView.tableData.businessId,
         description : "default",
         productList :productList
    };
    this.props.sendData(dataObj);
    this.props.history.push('/serialnumber');

}



renderList(){

      let myData=null;

        myData = this.state.tableData.map((data, i) => {
               return (
                 <SerialNoTextFields
                   key={i}
                   rowTitle={data[0].productType}
                   uniqueId={data[0].id}
                   minValue ={this.state.minval[data[0].id]}
                   maxValue ={this.state.maxval[data[0].id]}
                   allocNo = {this.state.allocno[data[0].id]}
                   handleChange ={this.onhandleChange}
                   onBlur={this.onBlur}
                 />
               );
             });

      return myData;
}

showHideErrorMessages(){
  let obj ={};

    if(Object.keys(this.state.isMinVal).length !== 0){
      for(let id in this.state.isMinVal){
        //let str = key.lastIndexOf('_');
        //let id = key.substring(str +1);
        if(this.state.isMinVal[id]){
          document.getElementById('minval_'+id).innerText =  '' ;
          document.getElementById('minval_'+id).className = 'hideError';
        }else{
          document.getElementById('minval_'+id).innerText =  'Missing Min Value.';
          document.getElementById('minval_'+id).className = 'showError';

        }
      }
    }
    if(Object.keys(this.state.isMaxVal).length !== 0){
      for(let id in this.state.isMaxVal){
        //let str = key.lastIndexOf('_');
        //let id = key.substring(str +1);
        if(this.state.isMaxVal[id]){
          document.getElementById('maxval_'+id).innerText = '' ;
          document.getElementById('maxval_'+id).className =  'hideError';
        }else{
          document.getElementById('maxval_'+id).innerText = 'The Max value must be greater than the Min value.';
          document.getElementById('maxval_'+id).className =  'showError';
        }
      }
    }


    if(Object.keys(this.state.isAllocNo).length !== 0){
      for(let id in this.state.isAllocNo){
        //let str = key.lastIndexOf('_');
        //let id = key.substring(str +1);
        if(this.state.isAllocNo[id]){
          document.getElementById('allocno_'+id).innerText = '' ;
          document.getElementById('allocno_'+id).className =  'hideError';
        }else{
          document.getElementById('allocno_'+id).innerText = 'Missing Last No. Alloc.';
          document.getElementById('allocno_'+id).className =  'showError';
        }
      }
    }
   if(Object.keys(this.state.isInBetween).length !== 0){
     for(let id in this.state.isInBetween){

       if(this.state.isInBetween[id]){
         document.getElementById('allocno_'+id).innerText = '' ;
         document.getElementById('allocno_'+id).className =  'hideError';
       }else{
         document.getElementById('allocno_'+id).innerText = 'The last No alloc must be between min value and max value.';
         document.getElementById('allocno_'+id).className =  'showError';
       }
     }
   }




}

  render() {

    this.showHideErrorMessages();

    return (
      <div className="createTable">
      <div className="row">
          <div className="col col-lg-6"><label>Country Code </label>: JP</div>
          <div className="col col-lg-6"><label>Group Member</label> : HSBC</div>
      </div>
      <div className="row">
          <div className="col-lg-6">
               <label>Business unit Id</label>

           </div>

      </div>

      <div style={{position:'relative', top:'20px'}}>
        <table className=" table table-striped table-bordered" >
            <thead>
                <tr>
                  <th className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">Product Type</th>
                  <th className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">Min Value</th>
                  <th className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">Max Value</th>
                  <th className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">Last No. Alloc</th>
                </tr>
            </thead>
            <tbody >
              {this.renderList()}
            </tbody>
        </table>
      </div>

      <div
          className={"col-xs-12 col-sm-9 col-md-10 col-lg-10 pull-right navbar-fixed-bottom bottom-buttons-layout"}>
          <div className="btn-toolbar" style={{ marginLeft: '40px' }}>
              <button className="btn btn-green" onClick={this.onSubmitCreateSerialNo} ><embed className="icon" src="icons/save.svg" alt="" /><span className="buttonLabel">Submit</span></button>
              <Link to='/serialnumber' className="btn btn-green"><embed className="icon" src="icons/exit.svg" alt="" /><span className="buttonLabel">Exit</span></Link>
          </div>
      </div>

      </div>
    );
  }

}

function mapStateToProps(state){
  return {
    data:state.serialNumberData.serialnumberdata,
    dataFromView : state.displaySerialNumberActionReducer
  };
}

export default connect(mapStateToProps, {createSerialNo, serialNoToBeUpdated, sendData })(ContainerForCreateSerialNo);
