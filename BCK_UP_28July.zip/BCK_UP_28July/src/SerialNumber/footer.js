import React, { Component } from 'react'
import { Link } from 'react-router-dom';

export default class Footer extends Component{
  constructor(props){
    super(props);
    this.recordFound=false,
    this.defaultDataStatus=false,
    this.state={
      viewButtonClicked:false
    }
  }

  view(){
    this.setState({viewButtonClicked:true})
    if(this.props.fromSource==="serial_number" || this.props.fromSource==="serialNumberTable"){
     if(this.props.data.selectedId){
       this.defaultDataStatus=false
       this.validateBusinessId(this.props.data.selectedId);
     }else{
      this.defaultDataStatus=true;
      var dataObj={
        defaultDataStatus:this.defaultDataStatus
      }
      this.props.handleView(dataObj)
     }
    }
  }
  validateBusinessId(obj){
     if(obj.productList.length!=0){
     this.recordFound=true
     }else{
     this.recordFound=false
      }
   var dataObj={
      obj:obj,
      recordFoundStatus:this.recordFound,
      defaultDataStatus:this.defaultDataStatus
           }
      this.props.handleView(dataObj)
  }
  displayBtn(){
    if(this.props.fromSource==="serial_number"){
      if(this.state.viewButtonClicked){
        if(this.props.btnDisplayData){
          return true
        }else{
          if(!this.recordFound || this.defaultDataStatus ){
            return true;
          }else{
            return false
          }
        }
      }
      return true
     }else{
     return false
    }
  }
  render(){
    if(this.props.fromSource==="serialNumberTable"){
      this.targetPage="/serialNumber"
    }else{
      this.targetPage="/"
    }
    return(
    <div className="col-xs-12 col-sm-9 col-md-10 col-lg-10 pull-right navbar-fixed-bottom bottom-buttons-layout">
      <div className="btn-toolbar" style={{marginLeft: '25px', position: 'relative', top: '60%'}}>
        {this.displayBtn()?<button id='viewBtn' className="btn btn-green viewButton" onClick={()=>this.view()}><span className="buttonLabel">View</span></button>:null}
        {this.displayBtn()?<button className="btn btn-green" onClick={this.props.handleCreateNew}><span className="buttonLabel">Create New</span></button>:null}
        {(this.props.fromSource!="serial_number"&& this.props.fromSource!="serialNumberTable")?<button className="btn btn-primary control-margin">Print</button>:null}
        {this.displayBtn()?<button className="btn btn-green" onClick={this.props.handleUpdate}><span className="buttonLabel">Update</span></button>:null}
        <Link to={this.targetPage} className="btn btn-green"><span className="buttonLabel">Exit</span></Link>
      </div>
    </div>
  )}
}
