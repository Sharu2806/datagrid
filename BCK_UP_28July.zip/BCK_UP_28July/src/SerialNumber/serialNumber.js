import React, { Component,PropTypes } from 'react';
import { Link } from 'react-router-dom';
import InputDropdownComponent from '../SharedComponents/dropdownComponent';
import { connect } from 'react-redux';
import {bindActionCreators} from 'redux';
import Footer1 from './footer';
import {displaySerialNumberData, fetchSerialData} from './Actions/action-serialnumber';
import './style.css';
import Footer from '.././Layout/Footer/Footer';

class SerialNumber extends Component{


  constructor(props){
    super(props);
    this.state={
      groupMember:"HSBC",
      defaultProductsWithoutIds:{},
      displayMissingGrpMemberError:false,
      countryCode:"JP",
      displayDefaultLink:false,
      displayRecordNotFoundError:false,
      displayRecordExistingError : false,
      bUnitObj:{},
      isNew : false
    },
    this.selectedBusinessUnit=null,
    this.arrForDefault=[],
    this.arrForProductWithId=[],
    this.arrDefaultAll=[]

    this.handleCreateNewSerialNo = this.handleCreateNewSerialNo.bind(this);
    this.handleUpdateSerialNo = this.handleUpdateSerialNo.bind(this);
  }

  componentWillMount(){
     this.props.fetchSerialData();
     //console.log("In comp" +this.props.serialNumberData.payload);

  }

  componentWillReceiveProps(propsObj){

    //let obj = propsObj;
    //console.log("OBj" , propsObj.serialNumberData.serialnumberdata);
     if(propsObj.serialNumberData.serialnumberdata !== undefined ||propsObj.serialNumberData.serialnumberdata !== 'undefined'){
       if(propsObj.serialNumberData.serialnumberdata.length !== 0){
          let temp = propsObj.serialNumberData.serialnumberdata.productLists;
           temp.map((item,i)=>{
           item["value"]=item.businessId;
          if(item.value!=""){
          this.arrForProductWithId.push(item)
         }
           this.arrDefaultAll.push(item)
         });
           let obj={}
           obj["allUnitIds"]=this.arrForProductWithId
           this.setState({bUnitObj:obj})
     }
   }
  }




  handleInputChange(event){
    this.setState({groupMember:event.target.value})
  }
  //handles selection business unit ID from dropdown
  handleBusinessUnitSelection(eventVal,item){
    this.selectedBusinessUnit=item
    var businessUnitObj={
      allUnitIds:this.state.businessUnitIds,
      selectedId:this.selectedBusinessUnit
          }
          this.setState({bUnitObj:businessUnitObj})
   }
   //handles view button functionality
   handleViewButton(dataObj){
    if(this.state.groupMember===""){
       this.setState({displayMissingGrpMemberError:true})
     }else{
       this.setState({displayMissingGrpMemberError:false})
     }
     if(!dataObj.recordFoundStatus && !dataObj.defaultDataStatus){
       this.setState({displayRecordNotFoundError:true})
         }else{
          this.setState({displayRecordNotFoundError:false});
           var serialNumberObj={
              tableData:dataObj.obj,
              countryCode:this.state.countryCode,
              groupMember:this.state.groupMember
             }
         if(dataObj.recordFoundStatus && this.state.groupMember!=""){
           this.setState({displayDefaultLink:false})
           this.props.displaySerialNumberData(serialNumberObj);
           console.log(this.context);
           this.props.history.push('/serialNumberTable');
         }
         else if(dataObj.defaultDataStatus && this.state.groupMember!="" ){
            this.setState({displayDefaultLink:true});
           }
        }
     }



    displayDefaultDataPage(item){
       if(item.productList!=0){
       var defaultObj={
         tableData: item,
         countryCode:this.state.countryCode,
         groupMember:this.state.groupMember
       }
       this.setState({displayRecordNotFoundError:true})
       this.props.displaySerialNumberData(defaultObj);
       this.props.history.push('/serialNumberTable');
     }
     else{
       this.setState({displayRecordNotFoundError:true})
     }
   }

   //handle create New serial Number
   handleCreateNewSerialNo(){
      if(this.state.groupMember===""){
         this.setState({displayMissingGrpMemberError:true});
         this.setState({displayRecordExistingError:false});
         this.setState({displayRecordNotFoundError:false});
       }
      else{
        this.setState({displayMissingGrpMemberError:false})
          if(this.state.bUnitObj.selectedId != undefined && this.state.bUnitObj.selectedId != 'undefined'){
            if(this.state.bUnitObj.selectedId.productList.length == 0){
               this.setState({displayRecordNotFoundError:false});
              this.setState({displayRecordExistingError:false});
              var objToUpdate={
                tableData: this.state.bUnitObj.selectedId,
                countryCode:this.state.countryCode,
                groupMember:this.state.groupMember
              }
              this.props.displaySerialNumberData(objToUpdate);
              this.props.history.push('/createSerialNo');
            }else{
              this.setState({displayRecordExistingError:true});
              this.setState({displayRecordNotFoundError:false});
            }
          }else{
              this.setState({displayRecordExistingError:true});
              this.setState({displayRecordNotFoundError:false});
          }
    }


   }

   //handle  Update serial Number
   handleUpdateSerialNo(){
     if(this.state.groupMember===""){
        this.setState({displayMissingGrpMemberError:true});
        this.setState({displayRecordExistingError:false});
        this.setState({displayRecordNotFoundError:false});
      }else{
         this.setState({displayMissingGrpMemberError:false});
         if(this.state.bUnitObj.selectedId != undefined && this.state.bUnitObj.selectedId != 'undefined'){
           if(this.state.bUnitObj.selectedId.productList.length != 0){
               this.setState({displayRecordNotFoundError:false});
               this.setState({displayRecordExistingError:false});
               var objToUpdate={
                 tableData: this.state.bUnitObj.selectedId,
                 countryCode:this.state.countryCode,
                 groupMember:this.state.groupMember
               }
               this.props.displaySerialNumberData(objToUpdate);
               this.props.history.push('/updateSerialNo');
           }else{
               this.setState({displayRecordNotFoundError:true});
               this.setState({displayRecordExistingError:false});
           }
         }else{
           this.setState({displayRecordNotFoundError:false});
           this.setState({displayRecordExistingError:false});

           var objToUpdate={
             tableData: "",
             countryCode:this.state.countryCode,
             groupMember:this.state.groupMember
           }
           this.props.displaySerialNumberData(objToUpdate);
           this.props.history.push('/updateSerialNo');

         }
   }

  //  this.setState({displayRecordNotFoundError:true});

   }
  render(){
    const list=this.arrDefaultAll.map((item,i)=>{
      return(
        <tr key={i}>
          <td>{item.value}</td>
          <td><span onClick={()=>this.displayDefaultDataPage(item)}><a>{item.description}</a></span></td>
        </tr>
      )
    });
      return(
        <div className="row formtoppadding serialNumberSection">
          <div style={{padding: '5px',backgroundColor: '#01afd2',color: 'white' ,position:'relative', bottom:'20px'}}><span>Defination Criteria</span></div>
          <div>{this.state.displayRecordNotFoundError?<span  className="showError">Record not found</span>:null}</div>
          <div>{this.state.displayMissingGrpMemberError?<span id='FEError' className="redText showError FEError">Function not authorised</span>:null}</div>
          <div>{this.state.displayRecordExistingError?<span className="redText showError">Record Already Exists</span>:null}</div>

           <div className="row">
             <div className="col-lg-6">
               <label>Country code</label>
               <div className=".countryCode">{this.state.countryCode}</div>
             </div>
             <div className="col-lg-6">
               <label>Group member</label>
              <div style={{width: '200px' ,height: '30px'}}>
                <input type="text" name="groupMember" className="grpMember"
                value={this.state.groupMember}
                onChange={(event)=>this.handleInputChange(event)}/>
             </div>
            </div>
          </div>
          <div className="row">
          <div className="col-lg-6">
            <label>Business unit ID</label>
              <div><InputDropdownComponent
               ref="business_unit"
               name="dropDown"
               className="idDropdown"
               payload={this.arrDefaultAll}
               validateDropdown={(eventVal,item)=>this.handleBusinessUnitSelection(eventVal,item)}
              />
              </div>
            </div>
          </div>
          {this.state.displayDefaultLink && !this.state.displayMissingGrpMemberError?  <div className="defaultLinkTable" style={{position:'relative', top:'20px'}}>
            <table className="table table-striped table-bordered">
            <thead>
            <tr>
             <th>Code</th>
             <th>Description</th>
            </tr>
            </thead>
            <tbody>
             {list}
            </tbody>
            </table>
            </div>:null}
          <div className="row">
          <div
              className={"col-xs-12 col-sm-9 col-md-10 col-lg-10 pull-right navbar-fixed-bottom bottom-buttons-layout"}>
              <div className="btn-toolbar" style={{ marginLeft: '40px' }}>
                  <button className="btn btn-green" onClick={(dataObj)=>this.handleViewButton(dataObj)} ><embed className="icon" src="icons/show-menu.svg" alt="" /><span className="buttonLabel">View</span></button>
                  <button className="btn btn-green" onClick={this.handleCreateNewSerialNo} ><embed className="icon" src="icons/send.svg" alt="" /><span className="buttonLabel">Create New</span></button>
                  <button className="btn btn-grey" onClick={this.handleUpdateSerialNo}><embed className="icon" src="icons/send-assign.svg" alt="" /><span className="buttonLabel">Update</span></button>
                  <Link to='/' className="btn btn-green"><embed className="icon" src="icons/exit.svg" alt="" /><span className="buttonLabel">Exit</span></Link>
              </div>
          </div>


          </div>
          <Footer />
      </div>
  )
}
}
function matchDispatchToProps(dispatch){
    return bindActionCreators({
      displaySerialNumberData: displaySerialNumberData

    }, dispatch);
}

function mapStateToProps(state){
  console.log("in maptostate" );
  console.log(state);
  return {
    serialNumberData:state.serialNumberData
  };
}



export default connect(mapStateToProps, {fetchSerialData, displaySerialNumberData})(SerialNumber);
