export default function (state = null, action) {
    switch (action.type) {
        case 'DISPLAY_SERIAL_NUMBER_DATA':
            return action.payload;
            break;
    }
    return state;
}
