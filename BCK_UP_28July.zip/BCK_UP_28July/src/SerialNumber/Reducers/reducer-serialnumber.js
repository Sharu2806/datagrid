import { NO_TO_UPDATE } from '../Actions/action-serialnumber';
const INITIAL_STATE={ serialnumberdata:[]  };




export default function(state = INITIAL_STATE,action){

  switch(action.type){
    case NO_TO_UPDATE:
      console.log("In Action" + action.payload);
      return {...state,serialnumberdata:action.payload};

    default: return state;
  }

}
