import React, { Component } from 'react';
import ReactDOM from 'react-dom';

export default class SerialNoTextFields extends Component{

  // constructor(props){
  //   super(props);
  //
  //   this.formatNumber = this.formatNumber.bind(this);
  // }
  //
  // formatNumber(e) {
  //   var s = "00000" + e.target.value;
  //   e.target.value = s.substr(s.length-6);
  // }

  render(){
    return(
      <tr>
        <th scope="row" id={this.props.uniqueId} >{this.props.rowTitle}</th>
        <td className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">
            <input type="number"  id={"min_"+this.props.uniqueId} name={this.props.nameForMinval} className="textfieldsmall" max="999999"  onChange={this.props.handleChange} onBlur={this.props.onBlur}  value={this.props.minValue}/>
            <span name="min_errormsg" id={"minval_"+this.props.uniqueId} className="hideError"></span>
        </td>
        <td className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">
            <input type="number"   id={"max_"+this.props.uniqueId} name={this.props.nameForMaxval} className="textfieldsmall" max="999999" onChange={this.props.handleChange}  onBlur={this.props.onBlur} value={this.props.maxValue}/>
            <span name='max_errormsg' id={"maxval_"+this.props.uniqueId} className="hideError"></span>
        </td>
        <td className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">
            <input type="number"  id={"alloc_"+this.props.uniqueId} name={this.props.nameForAllocNo} className="textfieldsmall" max="999999" onChange={this.props.handleChange} onBlur={this.props.onBlur}  value={this.props.allocNo}/>
            <span name='alloc_errormsg' id={"allocno_"+this.props.uniqueId} className="hideError"></span>
        </td>
      </tr>

    );



  }
}

SerialNoTextFields.defaultProps = {
  uniqueId : [1,2,3,4,5,6,7,8],
  nameForMinval: 'min_val',
  nameForMaxval:  'max_val',
  nameForAllocNo : 'alloc_no',
  minValue : '',
  maxValue : '',
  allocNo : ''


};
