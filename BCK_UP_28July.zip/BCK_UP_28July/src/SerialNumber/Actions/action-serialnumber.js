export const CREATE_SERIAL_NO = 'CREATE_SERIAL_NO';
export const NO_TO_UPDATE = 'NO_TO_UPDATE';
export const DISPLAY_SERIAL_NUMBER_DATA = 'DISPLAY_SERIAL_NUMBER_DATA';
export const GET_BUSINESSUNIT ='GET_BUSINESSUNIT';

export function createSerialNo(data){
  console.log(data);
   //const request = axios.get(ROOT_URL);
  return {
    type:CREATE_SERIAL_NO,
    payload:""
  }
}

export function serialNoToBeUpdated(){

  console.log();
   //const request = axios.get(ROOT_URL);
   let mydata ={
     "productResultList": {
       "productLists": [
         {
           "businessId": "",
           "description":"default",
           "productList": [
             {
               "id": "1",
               "productType": "Import Documentary Credits alldefault",
               "minValue": "000123",
               "maxValue": "000125",
               "lastNoAllo": "000124"
             },
             {
               "id": "2",
               "productType": "Import Bill",
               "minValue": "000124",
               "maxValue": "000140",
               "lastNoAllo": "000135"
             },
             {
               "id": "3",
               "productType": "Import Shipping Guarantee",
               "minValue": "000140",
               "maxValue": "000150",
               "lastNoAllo": "000140"
             },
            {
               "id": "4",
               "productType": "Import Loan",
               "minValue": "000150",
               "maxValue": "000160",
               "lastNoAllo": "000150"
             }
           ]
         },
         {
           "businessId": "111",
           "description":"DEF",
           "productList": [
             ]
           },
           {
             "businessId": "222",
             "description":"DEF",
             "productList": [
               ]
             },
             {
               "businessId": "333",
               "description":"DEF",
               "productList": [
                 ]
         },
         {
           "businessId": "025",
           "description":"ABC",
           "productList": [
             {
               "id": "5",
               "productType": "Import Marginal Deposit",
               "minValue": "000160",
               "maxValue": "000170",
               "lastNoAllo": "000160"
             },
             {
               "id": "6",
               "productType": "Export Bill",
               "minValue": "000170",
               "maxValue": "000180",
               "lastNoAllo": "000170"
             },
             {
               "id": "7",
               "productType": "Export Loan",
               "minValue": "000180",
               "maxValue": "000190",
               "lastNoAllo": "000180"
             },
             {
               "id": "8",
               "productType": "Export Marginal Deposit",
               "minValue": "000190",
               "maxValue": "000200",
               "lastNoAllo": "000190"
             },
             {
               "id": "9",
               "productType": "Export Marginal Deposit",
               "minValue": "000190",
               "maxValue": "000200",
               "lastNoAllo": "000190"
             }
           ]
         },

         {
           "businessId": "021",
           "description":"DEF",
           "productList": [
             {
               "id": "10",
               "productType": "Import Marginal Deposit",
               "minValue": "000360",
               "maxValue": "000470",
               "lastNoAllo": "000360"
             },
             {
               "id": "11",
               "productType": "Export Bill",
               "minValue": "000870",
               "maxValue": "000980",
               "lastNoAllo": "000870"
             },
             {
               "id": "12",
               "productType": "Export Loan",
               "minValue": "000680",
               "maxValue": "000790",
               "lastNoAllo": "000680"
             },
             {
               "id": "13",
               "productType": "Export Marginal Deposit",
               "minValue": "000590",
               "maxValue": "000600",
               "lastNoAllo": "000590"
             },
             {
               "id": "14",
               "productType": "Export Marginal Deposit",
               "minValue": "000390",
               "maxValue": "000400",
               "lastNoAllo": "000390"
             }
           ]
         },
        {
           "businessId": "022",
           "description":"FTR 001 mixed unit 1",
           "productList": [

           ]
         },
         {
            "businessId": "032",
            "description":"FTR 001 mixed",
            "productList": [

            ]
          },{
            "businessId": "040",
            "description":"UIT",
            "productList": [
              {
                "id": "15",
                "productType": "Import Documentary Credits default",
                "minValue": "000123",
                "maxValue": "000125",
                "lastNoAllo": "000124"
              },
              {
                "id": "16",
                "productType": "Import Bill default",
                "minValue": "000124",
                "maxValue": "000140",
                "lastNoAllo": "000135"
              },
              {
                "id": "17",
                "productType": "Import Shipping Guarantee default",
                "minValue": "000140",
                "maxValue": "000150",
                "lastNoAllo": "000140"
              },
             {
                "id": "18",
                "productType": "Import Loan",
                "minValue": "000150",
                "maxValue": "000160",
                "lastNoAllo": "000150"
              }
            ]
          },
          {
            "businessId": "026",
            "description":"FTR 002 mixed",
            "productList": [
              {
                "id": "19",
                "productType": "Import Marginal Deposit",
                "minValue": "001000",
                "maxValue": "002000",
                "lastNoAllo": "001500"
              },
              {
                "id": "20",
                "productType": "Export Bill",
                "minValue": "002000",
                "maxValue": "003000",
                "lastNoAllo": "002500"
              },
              {
                "id": "21",
                "productType": "Export Loan",
                "minValue": "003000",
                "maxValue": "004000",
                "lastNoAllo": "003000"
              },
              {
                "id": "22",
                "productType": "Export Marginal Deposit",
                "minValue": "004000",
                "maxValue": "005000",
                "lastNoAllo": "004000"
              },
              {
                "id": "23",
                "productType": "Export Marginal Deposit",
                "minValue": "005000",
                "maxValue": "006000",
                "lastNoAllo": "005000"
              }
            ]
          },
       ]
     }
   }

  return {
    type:NO_TO_UPDATE,
    payload:mydata
  }
}
export function getSelectedBusinessUnit(){

  console.log();
   //const request = axios.get(ROOT_URL);


  return {
    type:GET_BUSINESSUNIT,
    payload:""
  }
}


export const displaySerialNumberData = (data) => {

   return {
     type:'DISPLAY_SERIAL_NUMBER_DATA',
     payload: data
   }
 };

export function fetchSerialData() {
  console.log('fetch seruial data action');
    return dispatch => {
       fetch('http://A356A7V11008738:8088/api/getBusinessId')
       .then(result => result.json()).then(body =>

           dispatch({
               type: 'NO_TO_UPDATE',
               payload: body
           })
       ).catch(err => console.log(err.message));
   }
 }

 export function sendData(obj) {
   debugger;
     return dispatch => {
         var data = JSON.stringify(obj);
         console.log('Sending Data to WDM', data);

         //fetch('http://10.191.131.54:8090/WDM/save', {
         fetch('http://A356A7V11008738:8088/api/viewAndUnpdate', {
             method: 'post',
             headers: {
                 'Accept': 'application/json',
                 'Content-Type': 'application/json',
             },
             body: data
         }).then(result => result.json())
             .then(body => console.log(body))
             .catch(error => console.log(error))
     }
 }
