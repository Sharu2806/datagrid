import React, { Component } from 'react'
import {connect} from 'react-redux';
import ReactDOM from  "react-dom";
import Footer from './footer';

class SerialNumberTable extends Component{
  constructor(props){
    super(props);
    this.state={
      renderDefaultProduct:this.props.SerialNumberData.defaultDataPresent
    }
  }
  render(){
    if(this.props.SerialNumberData.tableData.jsonValue==="default"){
      this.businessUnit=""
    }else{
      this.businessUnit=this.props.SerialNumberData.tableData.value
    }
    const list=this.props.SerialNumberData.tableData.productList.map((item,index)=>{
      return(
        <tr key={index}>
          <th className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">{item.productType}</th>
          <td className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">{item.minValue}</td>
          <td className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">{item.maxValue}</td>
          <td className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">{item.lastNoAllo}</td>
        </tr>
      )
    })
    return(
      <div>
    <div  className="col-xs-12 col-sm-12 col-md-12 col-lg-12" style={{position:'relative', top:'10px' ,padding: '5px',backgroundColor: '#01afd2',color: 'white'}}><span>Serial Number</span></div>
        <div className="row formtoppadding serialNumberTable" style={{position:'relative', top:'20px'}}>

          <div className="row">
             <div className="col-lg-6">
             <label>Country code</label>
             <div>{this.props.SerialNumberData.countryCode}</div>
             </div>
             <div className="col-lg-6">
             <label>Group member</label>
             <div>{this.props.SerialNumberData.groupMember}</div>
             </div>
           </div>
           <div className="row">
           <div className="col-lg-6">
            <label>Business unit Id</label>
            <div>{this.businessUnit}</div>
            </div>
           </div>
           <table className="table table-striped table-bordered" style={{position:'relative', top:'20px'}}>
           <thead>
           <tr>
            <th className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">Product type</th>
            <th className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">Min value</th>
            <th className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">Max value</th>
            <th className="col col-lg-3 col-md-3 col-sm-3 col-xs-3">Last No.allocation</th>
          </tr>
          </thead>
          <tbody>
          {list}
          </tbody>
           </table>
           <Footer fromSource="serialNumberTable"/>
        </div>
</div>
    )
  }
}
function mapStateToProps(state){
  return{
    SerialNumberData:state.displaySerialNumberActionReducer
  }
}
export default connect(mapStateToProps)(SerialNumberTable)
