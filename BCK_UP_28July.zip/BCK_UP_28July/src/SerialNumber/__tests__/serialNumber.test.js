import React from 'react';
import { Provider,connect } from 'react-redux';
import ReactDOM from 'react-dom';
import { shallow,mount } from 'enzyme';
import { createStore} from 'redux';
import SerialNumber from '../serialNumber.js';
import rootReducer from '../.././store.js';
import Footer from '../footer.js';
import InputDropdownComponent from '../../SharedComponents/dropdownComponent';
import { Route, Link, MemoryRouter } from 'react-router-dom'

let store = rootReducer;

let app;
    beforeEach(() => {
        app  = shallow(<Provider store={store} >
          <MemoryRouter>
          <SerialNumber />
          </MemoryRouter>
        </Provider>);

    })

       describe('Serial Number', () => {

        it('renders without crashing', () => {
            const div = document.createElement('div');
            ReactDOM.render(<app/>, div);
        });
          //To check default value of Group member
        it ('should have default state val for Group Member', () => {
           app.setProps({ groupMember: "HSBC" });
           expect(app.props().groupMember).toBe("HSBC");
          });

        it ('should have default state val for Group Member', () => {
          app.setProps({ groupMember: "TEST" });
          expect(app.props().groupMember).not.toBe("HSBC");
         });

        it ('should have country code', () => {
         app.setProps({ countryCode: "JP" });
         expect(app.props().countryCode).toBe("JP");
        });

         it('on click of view button , state changes ',()=>{
          const btn=app.find(Footer).find('#viewBtn');
          btn.simulate('click');
          expect(app.find(Footer).nodes[0].state.viewButtonClicked).toBe(true)
        });

        it('clicking view button on selection of unit id which some record, error message is not displayed',()=>{
         const idToSelect=app.children().find('InputDropdownComponent').find('.idDropdown').findWhere(x=>x.text() === '026')
         const btn=app.find(Footer).find('#viewBtn');
         idToSelect.simulate('click');
         btn.simulate('click');
         expect(app.find('#errorTxtRecord').length).toBe(0)
       });

       it('clicking view button without id selection default products table displayed',()=>{
        const btn=app.find(Footer).find('#viewBtn');
        btn.simulate('click');
        expect(app.find('.defaultLinkTable').length).toBe(1)
        });

      it('group member field removed, view button clicked, error message displayed',()=>{
        const grpMemberInput=app.find('.grpMember');
        grpMemberInput.simulate('change', {target: {value: ''}});
        const btn=app.find(Footer).find('#viewBtn');
        btn.simulate('click');
        expect(app.find('.FEError').text()).toEqual('FE rejected')
      });

      it('group member field HSBC is present, view button clicked,no error message displayed',()=>{
        const grpMemberInput=app.find('.grpMember');
        grpMemberInput.simulate('change', {target: {value: 'HSBC'}});
        const btn=app.find(Footer).find('#viewBtn');
        btn.simulate('click');
        expect(app.find('.FEError').length).toBe(0)
      })
      });
