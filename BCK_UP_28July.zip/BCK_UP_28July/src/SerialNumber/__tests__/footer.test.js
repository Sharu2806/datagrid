import React from 'react';
import { Provider,connect } from 'react-redux';
import ReactDOM from 'react-dom';
import { shallow,mount } from 'enzyme';
import Footer from '../footer.js';
import store from '../.././store.js'
import SerialNumber from '../serialNumber.js';
import { Route, Link, MemoryRouter } from 'react-router-dom'



let app;
    beforeEach(() => {
        app  = mount(<Provider store={store}>
          <MemoryRouter>
          <Footer />
          </MemoryRouter>
        </Provider>);
    })
  //tests whether Serial Number section contains Footer component
  describe('Footer component', () => {
   it('Serial number contains footer component', () => {
   expect(app.contains(<Footer/>)).toEqual(true);
});

  });
