import React from 'react';
import ReactDOM from 'react-dom';
import { shallow,mount } from 'enzyme';
import displaySerialNumber from '../.././Reducers/displaySerialNumberActionReducer'

describe('Display Serial Number reducer',()=>{
  it('has a default state',()=>{
    expect(displaySerialNumber(undefined,{type:'unexpected'})).toEqual(null)
  });
});
