import { applyMiddleware, combineReducers, createStore } from 'redux';
import logger from 'redux-logger';
import thunk from 'redux-thunk';

import serialNumberReducer from './SerialNumber/Reducers/reducer-serialnumber';
import displaySerialNumberActionReducer from './SerialNumber/Reducers/displaySerialNumberActionReducer'

const mainReducer=combineReducers({
    serialNumberData:serialNumberReducer,
    displaySerialNumberActionReducer:displaySerialNumberActionReducer
});

const store = createStore(mainReducer, applyMiddleware(thunk, logger));

export default store;
