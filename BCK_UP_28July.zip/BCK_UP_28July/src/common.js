export function validateErrors(obj) {
    //console.log("Data is :: ", obj);
    var state = obj.state;
    let allFields = [];
    for (let propName in state) {
        if (state.hasOwnProperty(propName)) {
            allFields.push(propName);
        }
    }
    let found = false;
    for (let i = 0; i < allFields.length - 1; i++) {
        //console.log("element Name:: ",allFields[i]);
        let element = document.getElementsByName(allFields[i]);
        //console.log("element :: ",element);
        if (element && element.length > 0 && state.errors) {
            found = state.errors.some((item) =>
                item.fieldName === element[0].name
            );
            if (!found) {
                addError(element[0], obj);
            }
        }
    }
    if (state.errors.length === 0) {
        return true;
    } else {
        return false;
    }
}

export function addError(event, obj) {
    var errorFromJson = obj.errorFromJson;
    let target;
    if (event.type === 'blur') {
        event.preventDefault();
        target = event.target;
    } else {
        target = event;
    }
    let name = target.name;
    let value = target.value;
    let error;
    if (target.required && !value && errorFromJson[name]) {
        error = {
            fieldName: name,
            error: errorFromJson[name].required,
        };
        pushErrorNew(error, obj);
    } else if (target.pattern && value && !new RegExp(target.pattern).test(value)) {
        error = {
            fieldName: name,
            error: errorFromJson[name].inValid,
        };
        pushErrorNew(error, obj);
    }
}

export function pushErrorNew(error, obj) {
    let tempErrorHolder = obj.state.errors;
    tempErrorHolder.push(error);

    obj.setState({ errors: tempErrorHolder });
}

// removes error when the input field gets focussed with obj:{fieldName:abc, error:xyz}
export function removeError(event, obj) {
    var state = obj.state;
    let target;
    event.preventDefault();
    target = event.target;

    let tempErrorHolder = state.errors;
    let indexValue = -1;
    for (let i = 0; i < tempErrorHolder.length; i++) {
        if (tempErrorHolder[i].fieldName === target.name) {
            indexValue = i;
            break;
        }
    }
    if (indexValue > -1) {
        tempErrorHolder.splice(indexValue, 1);
        obj.setState({
            errors: tempErrorHolder
        });
    }
}

export function handleChange(event, obj) {
    let target = event.target;
    let name = target.name;
    let value = target.value;
    obj.setState({
        [name]: value
    });
}

export function deleteErrors(obj) {

    for (var key in obj) {
        delete obj[key]['errors'];
    }

}

export function handleSaveClick(obj, id) {
    let tabName = document.getElementById(id).getElementsByClassName("active")[0].childNodes[0].getAttribute("href");
    let tabName2 = tabName.substring(1);
    obj[tabName2].saveData();
}

export function handleTabClick(event, obj) {

    var currentTabName = obj.currentActiveTab;
    var nextTabName = event.target.getAttribute("href").substring(1);
    obj[currentTabName].saveData();
    //Need to prevent tabout logic here
    var errorsObj = obj[currentTabName].state.errors;
    obj.currentActiveTab = nextTabName;
}

export function getDropdownsList(objList,objId) {
    var optionsList = [];
    if (objList) {
        var selectList = document.getElementById(objId);
        for (var i = 0; i < objList.length; i++) {
            var obj = objList[i]
            var optionObj = document.createElement("option");
            //var optionObj = <option value={obj.code} key={i}>{obj.DropDownValue}</option>
            optionObj.value = obj.code;
            optionObj.text = obj.DropDownValue;
            optionsList.push(optionObj)
            selectList.appendChild(optionObj);
        }
    }
    //return optionsList;
}