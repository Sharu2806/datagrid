import React from 'react';

function ErrorDisplay(props) {
    var element = null;
    if (props.errors) {
        for (var i = 0; i < props.errors.length; i++) {
            var error = props.errors[i];
            if (error.fieldName === props.fieldName) {
                element = <span key={error.fieldName}>{error.error}</span>
            }
        }
    }
    if (element)
        return <span className={props.className}>{element}</span>
    else
        return null
}

export default ErrorDisplay;