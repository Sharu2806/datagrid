import React from 'react';
import PropTypes from 'prop-types';

const CustomTextArea = (props) => (
<span>
  {
    !props['data-suppressfield']  &&
    <span className={props['data-controlclass']}>
      { props.title &&
        <label className={props['data-labelclass']} htmlFor={props.name}>
          {props.title}{props.required?'*':''}
        </label>
      }
      <textarea {...props} />
    </span>
  }
</span>
);

CustomTextArea.propTypes = {
  'data-suppressfield': PropTypes.bool,
  'data-controlclass': PropTypes.string,
  'data-labelclass': PropTypes.string
};

export default CustomTextArea;
