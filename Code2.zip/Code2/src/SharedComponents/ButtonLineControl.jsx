import React, { Component } from 'react';
class ButtonLineControl extends Component {

    constructor(props) {
        super(props);
        this.state = {
            updown: false
        }

        this.changeUpDown = this.changeUpDown.bind(this);
        this.updateDimensions = this.updateDimensions.bind(this);
        this.addHiddenClass = this.addHiddenClass.bind(this);
        this.doesContainHiddenClass = this.doesContainHiddenClass.bind(this);
        this.removeHiddenClass = this.removeHiddenClass.bind(this);
    }

    componentDidMount() {
        this.updateDimensions();
        window.addEventListener('resize', this.updateDimensions);
    }

    componentWillUnmount() {
        window.removeEventListener('resize', this.updateDimensions);
    }

    changeUpDown() {
        this.setState({
            updown: !this.state.updown
        })
    }

    updateDimensions() {
        let buttonLineWidth = this.getWidthById(this.props.id);
        // 55 is sum of margin from the left and right
        buttonLineWidth -= 55;

        let childNodesRef = document.getElementById(this.props.id).getElementsByClassName("btn-toolbar")[0].childNodes;

        let noOfButtons = childNodesRef.length;

        // removing hidden class from all the buttons, otherwise gives zero
        for (let j = 0; j < noOfButtons - 1; j++) {
            let id = childNodesRef[j].id;
            let dropId = id.substring(7);
            this.removeHiddenClass(id);
            this.addHiddenClass('dropdown-' + dropId);
            this.addHiddenClass('dropdown-' + dropId + '-white');
        }
        this.removeHiddenClass('button-more');
        // end of removing hidden

        let buttonMoreWidth = this.getWidthById('button-more');

        // removing extra 10px margin from the right most button
        document.getElementById(childNodesRef[noOfButtons - 2].id).classList.add('margin-right-none');

        let i;
        for (i = 0; i < noOfButtons - 1; i++) {
            let id = childNodesRef[i].id;
            let currentButtonWidth = this.getWidthById(id);
            if (buttonLineWidth - (currentButtonWidth + 18 + buttonMoreWidth) >= 0) {
                buttonLineWidth = buttonLineWidth - currentButtonWidth - 10;
                let dropId = id.substring(7);
                if (this.doesContainHiddenClass(id)) {
                    this.removeHiddenClass(id);
                    this.addHiddenClass('dropdown-' + dropId);
                    this.addHiddenClass('dropdown-' + dropId + '-white');
                }
            }
            else {
                break;
            }
        }
        if (i === noOfButtons - 1) {
            let id = childNodesRef[i].id;
            if (!this.doesContainHiddenClass('button-more'))
                this.addHiddenClass('button-more');
        }
        else if (i === noOfButtons - 2 && (this.getWidthById(childNodesRef[i].id) <= buttonMoreWidth || this.getWidthById(childNodesRef[i].id) <= buttonLineWidth - 30)) {
            if (!this.doesContainHiddenClass('button-more'))
                this.addHiddenClass('button-more');
            if (this.doesContainHiddenClass(childNodesRef[i].id)) {
                this.removeHiddenClass(childNodesRef[i].id);
                let dropId = childNodesRef[i].id.substring(7);
                this.addHiddenClass('dropdown-' + dropId);
                this.addHiddenClass('dropdown-' + dropId + '-white');
            }
            i++;
        }
        else {
            if (this.doesContainHiddenClass('button-more'))
                this.removeHiddenClass('button-more');
        }

        while (i < (noOfButtons - 1)) {
            let id = childNodesRef[i].id;
            let dropId = id.substring(7);
            if (!this.doesContainHiddenClass(id)) {
                this.addHiddenClass(id);
                this.removeHiddenClass('dropdown-' + dropId);
                if (i !== noOfButtons - 2)
                    this.removeHiddenClass('dropdown-' + dropId + '-white');
            }
            i++;
        }
    }

    addHiddenClass(value) {
        return document.getElementById(value).classList.add('hidden');
    }

    removeHiddenClass(value) {
        return document.getElementById(value).classList.remove('hidden');
    }

    doesContainHiddenClass(value) {
        return document.getElementById(value).classList.contains('hidden');
    }

    getWidthById(value) {
        return document.getElementById(value).offsetWidth;
    }

    render() {
        var obj = JSON.parse(JSON.stringify(this.props.buttonList));
        let row = [];
        for (let i = 0; i < obj.length; i++) {
            let item = obj[i];
            row.push(
                <li key={'dropdown-' + item.btnName.replace(/\s/g, '')} id={'dropdown-' + item.btnName.replace(/\s/g, '')}>
                    <a><span className='buttonLabel'>{item.btnName}</span></a>
                </li>
            );
            row.push(
                <li
                    key={'dropdown-' + item.btnName.replace(/\s/g, '') + 'white'}
                    id={'dropdown-' + item.btnName.replace(/\s/g, '') + '-white'}
                    className="divider"
                    style={{ backgroundColor: 'white' }}
                >
                </li>);
        }
        // let buttonList = this.props.buttonList.map(item => <button key={item.btnName} id={item.btnName} className="btn btn-grey">{item.btnName}</button>)
        return (
            <div className="btn-toolbar" style={{ marginLeft: '25px' }}>
                {
                    this.props.buttonList.map(item =>
                        <button
                            key={item.btnName}
                            id={'button-' + item.btnName.replace(/\s/g, '')}
                            className={item.btnClass}
                            onClick={item.btnClickEvent}
                        >
                            {
                                item.btnIcon ?
                                    <embed className="icon" src={'icons/' + item.btnIcon + '.svg'} alt="" /> : null
                            }
                            <span className={item.btnIcon ? 'buttonLabel' : 'buttonLabelWithoutIcon'}>{item.btnName}</span>
                        </button>
                    )
                }
                {/*<button id="button-save" className="btn btn-green"><embed className="icon" src="icons/save.svg" alt="" /><span className="buttonLabel">Save</span></button>*/}
                {/*<button id="button-send" className="btn btn-green"><embed className="icon" src="icons/send.svg" alt="" /><span className="buttonLabel">Send</span></button>
                <button id="button-hold" className="btn btn-grey"><embed className="icon" src="icons/hold.svg" alt="" /><span className="buttonLabel">Hold</span></button>
                <button id="button-repair" className="btn btn-default" style={{ backgroundColor: "#b6b6b6", color: "white" }}><embed className="icon" src="icons/repair.svg" alt="" /><span className="buttonLabel">Repair</span></button>
                <button id="button-open-image" className="btn btn-grey"><embed className="icon" src="icons/open_image.svg" alt="" /><span className="buttonLabel">Open Image</span></button>
                <button id="button-cancel" className="btn btn-grey"><embed className="icon" src="icons/cancel.svg" alt="" /><span className="buttonLabel">Cancel</span></button>
                <button id="button-assign" className="btn btn-grey"><embed className="icon" src="icons/assign.svg" alt="" /><span className="buttonLabel">Assign</span></button>
                <button id="button-copy" className="btn btn-grey"><embed className="icon" src="icons/copy.svg" alt="" /><span className="buttonLabel">Copy</span></button>*/}
                <div style={{ backgroundColor: '#333333' }}>
                    <div className="dropup">
                        <button id="button-more" className="btn btn-default dropdown-toggle" data-toggle="dropdown" style={{ backgroundColor: '#333333', color: 'white' }} onClick={this.changeUpDown.bind(this)}>
                            <span className="" style={{ fontSize: '16px' }}>More {this.state.updown === true ? <img className="icon" src="icons/arrow-down.svg" alt="" /> : <img className="icon" src="icons/arrow-up.svg" alt="" />}</span>
                        </button>
                        <ul className="dropdown-menu pull-right">
                            {/*<li style={{ backgroundColor: "#b6b6b6", color: "white" }}><a><embed className="icon" src="public/icons/update_L3.svg" alt="" /><span className="buttonLabel">Update L3</span></a></li>*/}
                            {/*<li className="divider" style={{backgroundColor: "white"}}></li>*/}


                            {/*<li id="dropdown-save"><a ><embed className="icon" src="icons/save.svg" alt="" /><span className="buttonLabel">Save</span></a></li>
                            <li id="dropdown-save-white" className="divider" style={{ backgroundColor: "white" }}></li>
                            <li id="dropdown-send"><a><embed className="icon" src="icons/send.svg" alt="" /><span className="buttonLabel">Send</span></a></li>
                            <li id="dropdown-send-white" className="divider" style={{ backgroundColor: "white" }}></li>
                            <li id="dropdown-hold"><a><embed className="icon" src="icons/hold.svg" alt="" /><span className="buttonLabel">Hold</span></a></li>
                            <li id="dropdown-hold-white" className="divider" style={{ backgroundColor: "white" }}></li>
                            <li id="dropdown-repair"><a style={{ backgroundColor: "#b6b6b6", color: "white" }}><embed className="icon" src="icons/repair.svg" alt="" /><span className="buttonLabel">Repair</span></a></li>
                            <li id="dropdown-repair-white" className="divider" style={{ backgroundColor: "white" }}></li>
                            <li id="dropdown-open-image"><a><embed className="icon" src="icons/open_image.svg" alt="" /><span className="buttonLabel">Open Image</span></a></li>
                            <li id="dropdown-open-image-white" className="divider" style={{ backgroundColor: "white" }}></li>
                            <li id="dropdown-cancel"><a><embed className="icon" src="icons/cancel.svg" alt="" /><span className="buttonLabel">Cancel</span></a></li>
                            <li id="dropdown-cancel-white" className="divider" style={{ backgroundColor: "white" }}></li>
                            <li id="dropdown-assign"><a><embed className="icon" src="icons/assign.svg" alt="" /><span className="buttonLabel">Assign</span></a></li>
                            <li id="dropdown-assign-white" className="divider" style={{ backgroundColor: "white" }}></li>
                            <li id="dropdown-copy"><a><embed className="icon" src="icons/copy.svg" alt="" /><span className="buttonLabel">Copy</span></a></li>
                            <li id="dropdown-copy-white" className="divider" style={{ backgroundColor: "white" }}></li>*/}
                            {row}
                            {/*<li><a><embed className="icon" src="icons/AML_Checking.svg" alt="" /><span className="buttonLabel">AML Checking</span></a></li>
                            <li className="divider" style={{ backgroundColor: 'white' }}></li>
                            <li><a><span className="buttonLabel">Get Interaction</span></a></li>*/}
                        </ul>
                    </div>
                </div>
            </div>
        );
    }
}

export default ButtonLineControl;