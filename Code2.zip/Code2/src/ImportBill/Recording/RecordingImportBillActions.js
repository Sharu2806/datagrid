


export function fetchRecordingData() {

    return dispatch => {
       
        fetch('./json/ImportBillError.json').then(result => result.json()).then(body =>
            dispatch({
                type: 'FETCH_RECORDING_DATA',
                payload: body
            })
        );
    }
}


export function fetchRecordingDataDC() {

    return dispatch => {
       
        fetch('./json/ImportBillError.json').then(result => result.json()).then(body =>
            dispatch({
                type: 'FETCH_RECORDING_DATA_DC',
                payload: body
            })
        );
    }
}


export function saveDefinitionCriteriaData(obj) {
    console.log('save generateDCNumber action :: ', obj);
    return {
        type: 'SAVE_DEFINITION_CRITERIA_DATA',
        payload: obj
    };
}

export function generateDCNumber(obj) {

     console.log('save generateDCNumber action1 :: ', obj);
    //   return dispatch => {
    //         var data = JSON.stringify(obj);
    //         console.log('Sending Data to Mule', data);
    //         fetch('http://localhost:8081/postRecordingImport', {
    //             method: 'post',
    //             headers: {
    //                 'Accept': 'application/json',
    //                 'Content-Type': 'application/json'
    //             },
    //             body: JSON.stringify(obj)
    //         }).then(result => result.json())
    //             .then(body => successCall(body))
    //             .catch(error => errorCall(error))
    //     }  
   return dispatch => {
	  console.log('Sending data to mule :: ');
        fetch('http://10.191.131.222:8081/recording?accountNo=BDHSBC123456001123&productType=IBC').then(result => result.json()).then(body =>
            dispatch({
                type: 'GENERATE_DC_NUMBER',
                payload: body
            })
        );
    }  
}
/*function successCall(body) {
    // console.log("response :: ", body);
}
function errorCall(error) {
    alert(error)
}*/
