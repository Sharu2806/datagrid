
import React, { Component } from 'react';
import ErrorDisplay from '../../SharedComponents/ErrorDisplay';

import Validator from  'validator';
import isEmpty from 'lodash/isEmpty';
import classnames from 'classnames';

class DefinitionCriteria extends Component {

    constructor(props) {
        super(props);
        this.state = {
            accountNumber: "",
            accountNumber_gm:"",
            accountNumber_cn: "",
            accountNumber_ia: "",
            accountNumber_bn: "",           
            productType:"",
            issuanceBranch :"",
           transactionNumber: "",
           transactionNumberUn : "",
            dcNumber: "",
            dcNumber1 : "",
            dcNumber2 : "",
            dcNumber3: "",
            createTemplate: "Y",
            summaryAmendment: "N",
            copyFromAccount: "",
            copyFromAccountNumber_gm:"",
            copyFromAccountNumber_bn: "",
            copyFromAccountNumber_cn: "",
            copyFromAccountNumber_ia: "",
            businessUnitId: "0101",
            wolfStatus: "Y",
            copyFromTrn: "",
            copytransactionNumberUn : "",
            copyIssuanceBranch: "",
           error: [],
           errors: [],
			   
        };

        this.continue = this.continue.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.addError = this.addError.bind(this);
        this.removeError = this.removeError.bind(this);
    }

    componentWillMount() {
        this.setState({
            ...this.props.inputData
        });
    }

  componentDidMount() {

        fetch('json/ImportBillError.json', {
            method: 'GET'
        }).then(result => result.json())
            .then(body => this.saveError(body));
    }
    //storing error json in a local variable
    saveError(value) {
        this.errorFromJson = value;

    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.outputData) {
            this.props.history.push('/importbilldcrecording');
        }
    }

    continue(event) {
        this.setState({errors :"" });
         if(this.isValid()){
        var account = this.state.accountNumber.substring(0,2) + 
        this.state.accountNumber_gm  + this.state.accountNumber_bn 
        + this.state.accountNumber_cn +this.state.accountNumber_ia;
        var dc = this.state.dcNumber1 + this.state.dcNumber2 + this.state.dcNumber3;
        var copyAccount =  this.state.accountNumber.substring(0,2) + 
        this.state.copyFromAccountNumber_gm + this.state.copyFromAccountNumber_bn 
        + this.state.copyFromAccountNumber_cn +this.state.copyFromAccountNumber_ia;
        this.setState({accountNumber :account , dcNumber:dc,copyFromAccount : copyAccount});
         

        this.continueAgain()
         }
       

    }

    continueAgain(){
      
       
        setTimeout(function() { this.props.saveDefinitionCriteriaData(this.state);
            var obj = {
            "definitionCriteria" : {
            "accountNumber": this.state.accountNumber,
            "productType":this.state.productType,
            "issuanceBranch" :this.state.issuanceBranch,
           "transactionNumber": this.state.transactionNumber,
           "transactionNumberUn" : this.state.transactionNumberUn,
            "dcNumber": this.state.dcNumber,
			"createTemplate": this.state.createTemplate,
            "summaryAmendment": this.state.summaryAmendment,
            "copyFromAccount": this.state.copyFromAccount,
			"businessUnitId": this.state.businessUnitId,
            "wolfStatus": this.state.wolfStatus,
            "copyFromTrn": this.state.copyFromTrn
            }
        };
         this.props.generateDCNumber(obj); }.bind(this), 1000);
	 }
        
              
    
    
validateInput(data){
    let errors = {};

console.log("Calling validate Input () :"+data);
console.log("calling the errors " + JSON.stringify(this.state));



if((Validator.isEmpty(data.transactionNumberUn) || Validator.isEmpty(data.issuanceBranch) ||Validator.isEmpty(data.transactionNumber) || Validator.isEmpty(data.productType)))
{
     if(Validator.isEmpty(data.accountNumber_bn) || Validator.isEmpty(data.accountNumber_cn) 
         || Validator.isEmpty(data.accountNumber_ia)  || Validator.isEmpty(data.accountNumber_gm))
        {
            errors.accountNumber = 'Account Number is Required';
            errors.transactionNumber = 'Transaction Number is Required';
        }
    else{
        if(Validator.isEmpty(data.productType)){
             errors.transactionNumber = 'Product type is Required';
        }
    }   
       
}
else{
    if((Validator.isEmpty(data.accountNumber_cn) && !Validator.isEmpty(data.accountNumber_ia)) 
        ||(!Validator.isEmpty(data.accountNumber_cn) && Validator.isEmpty(data.accountNumber_ia)) )
        errors.accountNumber = 'Please enter the complete Account Number';
    else if(!(Validator.isEmpty(data.accountNumber_cn) && Validator.isEmpty(data.accountNumber_ia)))
    {
            if(Validator.isEmpty(data.accountNumber_bn) || Validator.isEmpty(data.accountNumber_gm))
                errors.accountNumber = 'Please enter the complete Account Number';
    }
   
        
}
if((!Validator.isEmpty(data.dcNumber1) && (Validator.isEmpty(data.dcNumber2) || Validator.isEmpty(data.dcNumber3) ))
    || (!Validator.isEmpty(data.dcNumber2) && (Validator.isEmpty(data.dcNumber1) || Validator.isEmpty(data.dcNumber3)))
    || (!Validator.isEmpty(data.dcNumber3) && (Validator.isEmpty(data.dcNumber1) || Validator.isEmpty(data.dcNumber2))))
    {
        errors.dcNumber = 'Please enter the complete DC Number';
    }
if((Validator.isEmpty(data.copyFromAccountNumber_cn) && !Validator.isEmpty(data.copyFromAccountNumber_ia)) 
        ||(!Validator.isEmpty(data.copyFromAccountNumber_cn) && Validator.isEmpty(data.copyFromAccountNumber_ia)) )
        {
             errors.copyFromAccount = 'Please enter the complete Copy from Account Number';
        }
if((!Validator.isEmpty(data.copyFromTrn) && (Validator.isEmpty(data.copyIssuanceBranch) || Validator.isEmpty(data.copytransactionNumberUn) ))
    || (!Validator.isEmpty(data.copyIssuanceBranch) && (Validator.isEmpty(data.copyFromTrn) || Validator.isEmpty(data.copytransactionNumberUn)))
    || (!Validator.isEmpty(data.copytransactionNumberUn) && (Validator.isEmpty(data.copyFromTrn) || Validator.isEmpty(data.copyIssuanceBranch))))
    {
        errors.copyFromTrn = 'Please enter the complete Copy from TRN Number';
    }

    

    return {
        errors,
        isValid:isEmpty(errors)
    }
}

    isValid(){
       const { errors, isValid} = this.validateInput(this.state);
       if(!isValid){
           this.setState({errors});
       }
       return isValid;
    }



    handleChange(event) {
        this.removeError(event);
         this.setState({ [event.target.name]: event.target.value});
    }


     addError(event) {
        let target;
        if (event.type === 'blur') {
            event.preventDefault();
            target = event.target;
        } else {
            target = event;
        }
        let name = target.name;
        let value = target.value;
        let error;
        if (target.pattern && value && !new RegExp(target.pattern).test(value)) {
            error = {
                fieldName: name,
                error: this.errorFromJson[name].inValid,
            };
            this.pushErrorNew(error);
        }
        else if(target.value.length !== target.maxLength && target.value !== "")
        {
             error = {
                fieldName: name,
                error: this.errorFromJson[name].maxLength,
            };
            this.pushErrorNew(error);
        }
    }
   /* pushError(error) {
          console.log("Error occurs " + error.fieldName);

        this.setState((prevState) => {
            let tempErrorHolder = prevState.errors;
            console.log("Error occurs at temperror " + JSON.stringify(tempErrorHolder));
            tempErrorHolder = tempErrorHolder.filter((item) =>
            {    console.log("Error occurs at filter " + JSON.stringify(item));
                item.fieldName !== error.fieldName
            });
            tempErrorHolder.push(error);
            return { errors: tempErrorHolder }
        });
    }*/

    pushErrorNew(error) {
        let tempErrorHolder = this.state.error;
        if(error !=="")
        {
        tempErrorHolder.push(error);
        this.setState({ error : tempErrorHolder });
        }
    }
    removeError(event) {
        let target;
        event.preventDefault();
        target = event.target;        
        let tempErrorHolder = this.state.error;
        let indexValue = -1;

            if (new RegExp("accountNumber").test(target.name)) {
                     this.state.errors.accountNumber = ""
            }
            else if (new RegExp("transactionNumber").test(target.name) || new RegExp("issuanceBranch").test(target.name) || new RegExp("transactionNumberUn").test(target.name) ) {
                     this.state.errors.transactionNumber = ""
            }
            else if(new RegExp("dcNumber").test(target.name)) {
                     this.state.errors.dcNumber = ""
            }
            else if(new RegExp("copyFromAccount").test(target.name)) {
                     this.state.errors.copyFromAccount = ""
            }
             else if (new RegExp("copyFromTrn").test(target.name) || new RegExp("copyIssuanceBranch").test(target.name) || new RegExp("copytransactionNumberUn").test(target.name)) {
                     this.state.errors.copyFromTrn = ""
            }

        for (let i = 0; i < tempErrorHolder.length; i++) {
            if (tempErrorHolder[i].fieldName === target.name) {
                indexValue = i;
                break;
            }
        }
        if (indexValue > -1) {
            tempErrorHolder.splice(indexValue, 1);
            this.setState({
                error: tempErrorHolder
            });
        }
       
    }


    render() {
        const {errors} = this.state;
        return (
            <div>
                <form style={{ marginBottom: '180px' }}>
                   
                    <div className="row">
                        <div className="col-md-12 col-lg-12">
                            <span className="Muli-Bold" style={{ fontSize: '16px' }}>Definition Criteria</span>
                            <hr style={{ borderColor: '#cacaca', marginTop: '1px' }} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Account Number</span>
                            <br />
                              <div className="row no-gutter">
                                  <div className={classnames("form-group",{'has-error':errors.accountNumber})}>
                                  
                                <input
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '45px', marginRight: '3px', display: 'inline-block' }} 
                                    name="accountNumber" id="accountNumber" 
                                    value={this.state.accountNumber.substring(0,2)} disabled/>
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '65px', marginRight: '3px', display: 'inline-block' }} 
                                    name="accountNumber_gm" id="accountNumber_gm" 
                                    value={this.state.accountNumber_gm}
                                    onChange={this.handleChange}
                                    maxLength={4}
                                    pattern="^[a-zA-Z]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError}
                                    />
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '52px', marginRight: '3px', display: 'inline-block' }} 
                                    name="accountNumber_bn" id="accountNumber_bn" 
                                    value={this.state.accountNumber_bn} 
                                    onChange={this.handleChange}
                                    maxLength={3}
                                    pattern="^[0-9]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError}/>
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '80px', marginRight: '3px', display: 'inline-block' }} 
                                    name="accountNumber_cn" id="accountNumber_cn" 
                                    value={this.state.accountNumber_cn}
                                    onChange={this.handleChange}
                                    maxLength={6}
                                    pattern="^[0-9]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError} />
                                
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '52px', marginRight: '3px', display: 'inline-block' }} 
                                    name="accountNumber_ia" id="accountNumber_ia" 
                                    value={this.state.accountNumber_ia}
                                    onChange={this.handleChange}
                                    maxLength={3}
                                    pattern="^[0-9]*$"
                                    onBlur={this.addError} 
                                    onFocus={this.removeError} />
                                    
                                <span className="help-block">
                                <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='accountNumber_gm' 
                                    className='errorClass' />                                    
                                <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='accountNumber_bn' 
                                    className='errorClass' />
                                <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='accountNumber_cn' 
                                    className='errorClass' />
                                <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='accountNumber_ia' 
                                    className='errorClass' /></span>
                                <div className ='errorClass' >{errors.accountNumber && errors.accountNumber}</div>
                                    </div>
                            </div>
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                             <span className="label-margin-below">Transaction Number</span>
                            <br />
                             <div className="row no-gutter">
                                 <div className={classnames("form-group",{'has-error':errors.transactionNumber})}>
                            <select 
                                className="form-control selectCss" 
                                name="productType" 
                                value={this.state.productType} 
                                onChange={this.handleChange} 
                                style={{ width: '75px', marginRight: '3px', display: 'inline-block' }} 
                                id="productType">
                                <option value=""></option>
                                <option value="BDU">BDU</option>
                                <option value="BR">BR</option>
                                <option value="CGI">CGI</option>
                                <option value="CGJ">CGJ</option>
                                <option value="IBC">IBC</option>
                                <option value="DPB">DPB</option>
                                <option value="IBC">IBC</option>
                                <option value="OAM">OAM</option>
                                <option value="RFI">RFI</option>
                            </select>  
                             <input 
                                type="text" 
                                className="form-control" 
                                value={this.state.issuanceBranch} 
                                onChange={this.handleChange} 
                                style={{ width: '58px', display: 'inline-block' , marginRight: '3px'}} 
                                name="issuanceBranch" id="issuanceBranch"
                                maxLength={3}
                                pattern="^[A-Za-z]*$"
                                onBlur={this.addError} 
                                onFocus={this.removeError}/>
                            <input 
                                type="text" 
                                className="form-control" 
                                value={this.state.transactionNumber} 
                                onChange={this.handleChange} 
                                style={{ width: '80px', display: 'inline-block' , marginRight: '3px'}} 
                                name="transactionNumber" id="transactionNumber"
                                maxLength={6}
                                pattern="^[0-9]*$"
                                onBlur={this.addError} 
                                onFocus={this.removeError}  />
                             <input 
                                type="text" 
                                className="form-control" 
                                value={this.state.transactionNumberUn} 
                                onChange={this.handleChange} 
                                style={{ width: '58px', marginRight: '3px', display: 'inline-block'}} 
                                name="transactionNumberUn" id="transactionNumberUn" 
                                maxLength={3}
                                pattern="^[A-Za-z]*$"
                                onBlur={this.addError} 
                                onFocus={this.removeError}
                                />   
                                 <span className="help-block">
                                <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='issuanceBranch' 
                                    className='errorClass' />
                                <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='transactionNumber' 
                                    className='errorClass' />                                
                                <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='transactionNumberUn' 
                                    className='errorClass' />
                                  <div className ='errorClass' >{errors.transactionNumber && errors.transactionNumber}
                                  </div>
                             </span>
                                </div>
                            </div>  
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">DC Number</span>
                            <br />
                           <div className="row no-gutter">
                                 <div className={classnames("form-group",{'has-error':errors.dcNumber})}>      
                            <select 
                                className="form-control selectCss" 
                                name="dcNumber1" 
                                value={this.state.dcNumber1} 
                                onChange={this.handleChange} 
                                style={{ width: '75px', marginRight: '3px', display: 'inline-block' }} 
                                id="dcNumber1">
                                <option value=""></option>
                                <option value="DPC">DPC</option>
                                <option value="GUA">GUA</option>
                                <option value="IBC">IBC</option>
                                <option value="TEE">TEE</option>
                            </select>  
                            <input 
                                type="text" 
                                className="form-control" 
                                value={this.state.dcNumber2} 
                                onChange={this.handleChange} 
                                style={{ width: '58px', display: 'inline-block',marginRight: '3px' }} 
                                name="dcNumber2" id="dcNumber2"
                                maxLength={3} 
                                pattern="^[a-zA-Z]*$"
                                onBlur={this.addError} 
                                onFocus={this.removeError}/>
                            <input 
                                type="text" 
                                className="form-control" 
                                value={this.state.dcNumber3} 
                                onChange={this.handleChange} 
                                style={{ width: '95px', display: 'inline-block' }} 
                                name="dcNumber3" id="dcNumber3" 
                                 maxLength={6} 
                                pattern="^[0-9]*$"
                                onBlur={this.addError} 
                                onFocus={this.removeError}/>
                            <span className="help-block">
                            <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='dcNumber2' 
                                    className='errorClass' />                                    
                            <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='dcNumber3' 
                                    className='errorClass' /></span>
                                      <div className ='errorClass' >{errors.dcNumber && errors.dcNumber}  </div>                          
                            </div>
                            </div>
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-7 col-lg-5">
                            <span className="label-margin-below">Create Template</span>
                            <br />
                             <div className="row">
                              {this.state.createTemplate ==="Yes" ?
                                <div className="col-xs-4 col-sm-4 col-md-5 col-lg-6" onChange={this.handleChange}>                                    
                                    <input 
                                        type="radio" 
                                        name="createTemplate" 
                                        id="createTemplate" 
                                        value="Yes" 
                                        defaultChecked="true"/>Yes &nbsp; &nbsp; &nbsp;
                                    <input 
                                        type="radio"
                                        name="createTemplate" 
                                        id="createTemplate" 
                                        value="No" 
                                        />No
                                </div> :
                                 <div className="col-xs-4 col-sm-4 col-md-5 col-lg-6" onChange={this.handleChange}>                                    
                                    <input 
                                        type="radio" 
                                        name="createTemplate" 
                                        id="createTemplate" 
                                        value="Yes" 
                                        />Yes &nbsp; &nbsp; &nbsp;
                                    <input 
                                        type="radio"
                                        name="createTemplate" 
                                        id="createTemplate" 
                                        value="No" 
                                        defaultChecked="true"/> No
                                        </div>}
                            </div>
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Summary Amendment</span>
                            <br />
                             <div className="row">
                                <div className="col-xs-4 col-sm-4 col-md-5 col-lg-6" >
                                    <input 
                                        type="radio" 
                                        name="summaryAmendment" 
                                        id="summaryAmendment" 
                                        value="Yes" 
                                         disabled/>Yes &nbsp;&nbsp; &nbsp;                             
                                    <input 
                                        type="radio" 
                                        name="summaryAmendment" 
                                        id="summaryAmendment" 
                                        value="No" 
                                        disabled/>No
                                </div>
                            </div>
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Copy From Account</span>
                            <br />
                             <div className="row no-gutter">
                                 <div className={classnames("form-group",{'has-error':errors.copyFromAccount})}>
                                 <input
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '45px', marginRight: '3px', display: 'inline-block' }} 
                                    name="copyFromAccount" id="copyFromAccount" 
                                    value={this.state.accountNumber.substring(0,2)}                                                                   
                                    disabled/>
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '65px', marginRight: '3px', display: 'inline-block' }} 
                                    name="copyFromAccountNumber_gm" id="copyFromAccountNumber_gm" 
                                    value={this.state.copyFromAccountNumber_gm}
                                    onChange={this.handleChange}
                                    maxLength={4}
                                    pattern="^[a-zA-Z]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError}                                    
                                    />
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '52px', marginRight: '3px', display: 'inline-block' }} 
                                    name="copyFromAccountNumber_bn" id="copyFromAccountNumber_bn" 
                                    value={this.state.copyFromAccountNumber_bn}
                                    onChange={this.handleChange}
                                    maxLength={3}
                                     pattern="^[0-9]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError} 
                                    
                                    />
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '80px', marginRight: '3px', display: 'inline-block' }} 
                                    name="copyFromAccountNumber_cn" id="copyFromAccountNumber_cn" 
                                    value={this.state.copyFromAccountNumber_cn}
                                    onChange={this.handleChange}
                                    maxLength={6}
                                    pattern="^[0-9]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError}
                                    />
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '52px', marginRight: '3px', display: 'inline-block' }} 
                                    name="copyFromAccountNumber_ia" id="copyFromAccountNumber_ia" 
                                    value={this.state.copyFromAccountNumber_ia}
                                    onChange={this.handleChange}
                                    maxLength={3}
                                    pattern="^[0-9]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError}
                                    
                                    /> 
                                <span className="help-block">
                                <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='copyFromAccountNumber_gm' 
                                    className='errorClass' /> 
                                <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='copyFromAccountNumber_bn' 
                                    className='errorClass' /> 
                                 <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='copyFromAccountNumber_cn' 
                                    className='errorClass' /> 
                                <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='copyFromAccountNumber_ia' 
                                    className='errorClass' />                                    
                                    
                                    </span>
                                      <div className ='errorClass' > {errors.copyFromAccount && errors.copyFromAccount} </div>
                                     
                                     </div> </div>
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Copy From TRN</span>
                            <br />
                           <div className="row no-gutter">
                               <div className={classnames("form-group",{'has-error':errors.copyFromTrn})}>
                               <select 
                                className="form-control selectCss" 
                                name="productTypeTrn" 
                                value={this.state.productType}  
                                style={{ width: '75px', marginRight: '3px', display: 'inline-block' }} 
                                id="productTypeTrn" disabled>                               
                                <option value=""></option>
                                <option value="BDU">BDU</option>
                                <option value="BR">BR</option>
                                <option value="CGI">CGI</option>
                                <option value="CGJ">CGJ</option>
                                <option value="IBC">IBC</option>
                                <option value="DPB">DPB</option>
                                <option value="IBC">IBC</option>
                                <option value="OAM">OAM</option>
                                <option value="RFI">RFI</option>
                            </select>  
                             <input 
                                type="text" 
                                className="form-control" 
                                value={this.state.copyIssuanceBranch} 
                                onChange={this.handleChange} 
                                style={{ width: '58px', display: 'inline-block' , marginRight: '3px'}} 
                                name="copyIssuanceBranch" id="copyIssuanceBranch" 
                                maxLength={3}
                                pattern="^[a-zA-Z]*$"
                                onBlur={this.addError}
                                onFocus={this.removeError}                               
                                
                                />
                            <input 
                                type="text" 
                                className="form-control" 
                                value={this.state.copyFromTrn} 
                                onChange={this.handleChange} 
                                style={{ width: '80px', display: 'inline-block' , marginRight: '3px'}} 
                                name="copyFromTrn" id="copyFromTrn"
                                maxLength={6}
                                pattern="^[0-9]*$"
                                onBlur={this.addError}
                                onFocus={this.removeError}                                                          
                                 />
                             <input 
                                type="text" 
                                className="form-control" 
                                value={this.state.copytransactionNumberUn} 
                                onChange={this.handleChange} 
                                style={{ width: '58px', marginRight: '3px', display: 'inline-block'}} 
                                name="copytransactionNumberUn" id="copytransactionNumberUn" 
                                maxLength={3}
                                pattern="^[A-Za-z]*$"
                                onBlur={this.addError}
                                onFocus={this.removeError}
                                />  
                            <span className="help-block">
                            <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='copyIssuanceBranch' 
                                    className='errorClass' />
                            <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='copyFromTrn' 
                                    className='errorClass' /> 
                            <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='copytransactionNumberUn' 
                                    className='errorClass' />
                            </span>



                                     <div className ='errorClass' >  {errors.copyFromTrn && errors.copyFromTrn} </div>
                                      </div>
                            </div>
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Bussiness Unit ID</span>
                            <br />
                            <input 
                                type="text" 
                                className="form-control" 
                                name="businessUnitId" 
                                id="businessUnitId" 
                                value={this.state.businessUnitId}
                                onChange={this.handleChange} 
                                maxLength={4}
                                pattern="^[0-9]*$"
                                onBlur={this.addError} 
                                onFocus={this.removeError}
                                />
                            <span className="help-block">
                            <ErrorDisplay 
                                    errors={this.state.error} 
                                    fieldName='businessUnitId' 
                                    className='errorClass' /> </span>

                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Wolf Status</span>
                            <br />
                            <select 
                                className="form-control selectCss" 
                                name="wolfStatus" 
                                id="wolfStatus" 
                                style={{ width: '250px'}}
                                value={this.state.wolfStatus}
                                onChange={this.handleChange} >
                                <option value=""></option>
                                <option value="Y">Y</option>
                                <option value="N">N</option>
                                <option value="P">P</option>
                                <option value="A">A</option>
                            </select>
                        </div>
                    </div>
                </form>
                <div
                    className={"col-xs-12 col-sm-9 col-md-10 col-lg-10" + " pull-right navbar-fixed-bottom bottom-buttons-layout"}
                >
               {/* <div className="" style={{ backgroundColor: '#dedede', marginTop: '30px', paddingTop: '30px', paddingBottom: '30px', marginLeft: '-30px', marginRight: '-30px' }}>
                */}    <div className="btn-toolbar" style={{marginLeft:'40px'}}>
                        <button 
                            className="btn btn-green" 
                            onClick={this.continue}>
                            <i className="fa fa-long-arrow-right" aria-hidden="true"></i> Continue</button>
                        <button 
                            className="btn btn-default" 
                            style={{ backgroundColor: "#666", color: "white" }}>
                            <i className="fa fa-search"></i> Search</button>
                        <button 
                            className="btn btn-default" 
                            style={{ backgroundColor: "#666", color: "white" }}>
                            <i className="fa fa-times-circle-o"></i> Exit</button>
                    </div>
                </div>
            </div>
        );
    }
}

export default DefinitionCriteria;
