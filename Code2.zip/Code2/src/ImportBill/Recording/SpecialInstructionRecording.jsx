import React from 'react';

class SpecialInstructionRecording extends React.Component {

    constructor() {
        super();
        this.state = {
            isSlideIn: true,
            isPopIn: false
        };
        this.adjustNav = this.adjustNav.bind(this);
        this.adjustPopup = this.adjustPopup.bind(this);
    }
    adjustNav() {
        if (this.state.isSlideIn)
            document.getElementById("myNav").style.height = '25px';
        else
            document.getElementById("myNav").style.height = '300px';
        this.setState({
            isSlideIn: !this.state.isSlideIn,
        })
    }
    adjustPopup() {
        this.adjustNav();
        //document.getElementById("overlayId").click()
        this.setState({
            isPopIn: !this.state.isPopIn,
        })
    }

    render() {
        var imgStyle = { display: "inline-block", float: "right", marginRight: "1%" };
        return (
            <div id="specialInst" style={{display:"none"}}>
                <div style={{ marginBottom: "25px" }} >
                    <div id="myNav" style={{ height: "300px" }} className="overlay" >
                        <div style={{ textAlign: "center", color: "white" }}>
                            Special Instructions
                            {this.state.isSlideIn}
                                {this.state.isPopIn ?
                                <img
                                    src='icons/pop-in.svg'
                                    alt="Expand"
                                    height="25"
                                    width="25"
                                    onClick={this.adjustPopup}
                                    style={imgStyle}
                                />
                                :
                                <img
                                    src='icons/pop-out.svg'
                                    alt="Collapse"
                                    height="25"
                                    width="25"
                                    onClick={this.adjustPopup}
                                    style={imgStyle}
                                />
                            }
                            {this.state.isSlideIn ?
                                <img
                                    src='icons/slide-out.svg'
                                    alt="Collapse"
                                    height="25"
                                    width="25"
                                    onClick={this.adjustNav}
                                    style={imgStyle}
                                />
                                :
                                <img
                                    src='icons/slide-in.svg'
                                    alt="Expand"
                                    height="25"
                                    width="25"
                                    onClick={this.adjustNav}
                                    style={imgStyle}
                                />
                            }
                        </div>
                        <div className="overlay-content" style={{ color: "white" }}>
                            <div className='col-md-12'>
                                <div className='row'>
                                    <div className='col-md-3'></div>
                                    <div className="col-md-6">
                                        *** SPECIAL INSTRUCTION FOR ACCOUNT NO. {this.props.specialInstruction}***
                                        </div>
                                    <div className='col-md-3'></div>
                                </div>
                                <div className='row'>
                                    <div className='col-md-3'></div>
                                    <div className="col-md-6">
                                        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
                                        </div>
                                    <div className='col-md-3'></div>
                                </div>
                                <div className='row'>
                                    <div className='col-md-3'></div>
                                    <div className="col-md-6">
                                        *** SPECIAL INSTRUCTION FOR PRODUCT TYPE BR  ***
                                        </div>
                                    <div className='col-md-3'></div>
                                </div>
                                <div className='row'>
                                    <div className='col-md-3'></div>
                                    <div className="col-md-6">
                                        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
                                        </div>
                                    <div className='col-md-3'></div>
                                </div>
                                <div className='row'>
                                    <div className='col-md-3'></div>
                                    <div className="col-md-6">
                                        *** END OF SPECIAL INSTRUCTION ***
                                        </div>
                                    <div className='col-md-3'></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="button" id="overlayId" className="btn btn-info btn-lg" style={{ display: "none" }} data-toggle="modal" data-target="#myModal">Open Modal</button>
                    <div className="modal fade" id="myModal" role="dialog">
                        <div className="modal-dialog">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <button type="button" className="close" data-dismiss="modal">
                                        <img
                                            src='img/slide-in.svg'
                                            alt="Expand"
                                            height="25"
                                            width="25"
                                            onClick={this.adjustNav}
                                            style={imgStyle}
                                        />
                                    </button>
                                    <h4 className="modal-title">Special Instruction</h4>
                                </div>
                                <div className="modal-body">
                                   
                                </div>
                                <div className="modal-footer">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default SpecialInstructionRecording;