import React, { Component } from 'react';

export class BasicInformation extends Component {

    constructor(props) {
        super(props);
        this.state = {
            gwisId: '',
            status: '',
            createdUser: '',
            lastModifiedUser: '',
            lastModifiedTime: '',
            createdTime:'',
            workStep: '',
            nextWorkStep: ''
        }
        this.fetchData = this.fetchData.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.saveData = this.saveData.bind(this);
    }

    componentWillMount() {
        this.setState({
            ...this.props.inputData
        });
    }


    componentDidMount() {
        this.props.onRef(this);
        this.setState({
            ...this.props.inputData
        });
    }

    componentWillUnmount() {
        this.props.onRef(undefined)
    }

    fetchData() {
        let obj = this.props.inputData;
        this.setState({
            ...obj
        });
    }


    handleChange(event) {
        let target = event.target;
        let name = target.name;
        let value = target.value;
        this.setState({
            [name]: value
        });
    }

    saveData() {
         this.props.saveBasicInformationData(this.state);
    }

    render() {
        return (
            <form>
                <div className="row row-margin">
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">GWIS ID</span><br />
                        <input 
                            type="text" 
                            className="form-control"  
                            value={this.state.gwisId} 
                            onChange={this.handleChange} 
                            name="gwisId" id="gwisId" disabled />
                        </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Status</span> <br />
                        <input 
                            type="text" 
                            className="form-control" 
                            value={this.state.status} 
                            onChange={this.handleChange} 
                            name="status" id="status" disabled />
                        </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Created User</span><br />
                        <input 
                            type="text" 
                            className="form-control" 
                            value={this.state.createdUser} 
                            onChange={this.handleChange} 
                            name="createdUser" id="createdUser" disabled />
                        </div>
                </div>

                <div className="row row-margin">
                     <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                         <span className="label-margin-below">Created Time</span><br />
                         <input 
                            type="text" 
                            className="form-control" 
                            value={this.state.createdTime} 
                            onChange={this.handleChange} 
                            name="createdTime" id="createdTime" disabled />
                    </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Last Modified User</span><br />
                       <input 
                          type="text" 
                          className="form-control"  
                          value={this.state.lastModifiedUser} 
                          onChange={this.handleChange} 
                          name="lastModifiedUser" id="lastModifiedUser" disabled />
                        </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Last Modified Time</span><br />
                        <input 
                            type="text" 
                            className="form-control"  
                            value={this.state.lastModifiedTime} 
                            onChange={this.handleChange} 
                            name="lastModifiedTime" id="lastModifiedTime" disabled/>

                    </div>
                </div>
                <div className="row row-margin">

                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Current Work Step</span><br />
                        <input 
                            type="text" 
                            className="form-control"  
                            value={this.state.workStep} 
                            onChange={this.handleChange} 
                            name="workStep" id="workStep" disabled />
                       </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Next Work Step</span><br />
                        <select 
                            className="form-control selectCss" 
                            value={this.state.nextWorkStep} 
                            onChange={this.handleChange} 
                            name="nextWorkStep" id="nextWorkStep">
                            <option>Document Attach</option>
                            <option>Recording</option>
                            <option>Document Management Pre Work</option>
                            <option>Auto Indexing </option>
                        </select>
                    </div>
                </div>
            </form>
        );
    }
}
export default BasicInformation;