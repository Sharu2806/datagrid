
export function fetchIndexingData(obj) {

    /*return {
            type: 'FETCH_INDEXING_DATA',
            payload: allindex
        };*/
    return dispatch => {
        //http://10.191.131.222:8091/WDM/fetch
        fetch('./json/importBillIndexing.json').then(result => result.json()).then(body =>
            dispatch({
                type: 'FETCH_INDEXING_DATA',
                payload: body
            })
        );
    }
}

export function saveBasicInformationData(obj) {
    return {
        type: 'SAVE_BASIC_INFORMATION_DATA',
        payload: obj
    };
}

export function saveCommonInformationData(obj) {
    return {
        type: 'SAVE_COMMON_INFORMATION_DATA',
        payload: obj
    };
}

export function saveIndexingInformationData(obj) {
    return {
        type: 'SAVE_INDEXING_INFORMATION_DATA',
        payload: obj
    };
}

export function sendData(obj) {

    return dispatch => {
        var data = JSON.stringify(obj);
        console.log('Sending Data to java service', data);
        //http://10.191.131.222:8091/WDM/save
        fetch('http://10.191.131.222:8091/WDM/save', {
            method: 'post',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: data
        }).then(result => result.json())
            .then(body => successCall(body))
            .catch(error => errorCall(error))
    }
}

function successCall(body) {
    alert("WORK ITEM " + body.basicInformation.gwisId + " sent successfully for Recording");
}
function errorCall(error) {
    alert(error);
}

