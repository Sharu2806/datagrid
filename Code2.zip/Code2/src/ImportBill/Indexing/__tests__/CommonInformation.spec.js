import CommonInformation from '../CommonInformation/CommonInformation';
import { SubmissionError } from 'redux-form'
import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, render, mount } from 'enzyme';
import 'isomorphic-fetch';

import data from '../../../../public/json/commonInformationRecord.json';

let commonInfo = null;
let priority = null;
let branchCode = null;
let targetDate = null;
let processingType = null;
let custSegmnt = null;
let lob = null;
let supplementary = null;
let processingSite = null;  
let attachToAppReference = null;  
            
beforeAll(() => {
    commonInfo = shallow(<CommonInformation/>);    
    priority = commonInfo.find('input[name="priority"]');
    branchCode = commonInfo.find('input[name="branchCode"]');
	targetDate = commonInfo.find('input[name="targetDate"]');
	processingType = commonInfo.find('input[name="processingType"]');
	custSegmnt = commonInfo.find('input[name="custSegmnt"]');
	lob = commonInfo.find('input[name="lob"]');
	supplementary = commonInfo.find('input[name="supplementary"]');
	processingSite = commonInfo.find('input[name="processingSite"]');    
	attachToAppReference = commonInfo.find('input[name="attachToAppReference"]');    
});

describe('CommonInformation', () => {
    it('renders without crashing', () => {
        expect(commonInfo.find('form').length).toBe(1);
    });

    it('page header should be - Basic Information', () => {
        const header = <span className="Muli-Bold" style={{ fontSize: '16px' }}>Basic Information</span>;
        expect(commonInfo.contains(header)).toEqual(false);
    });

    describe('priority', () => {
     /*   it('should render once', () => {
            expect(priority.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(priority.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            priority.simulate('blur',{target:{...priority.props()}, type: 'blur', preventDefault: () => {} });
            expect( commonInfo.find('ErrorDisplay[fieldName="priority"]').prop('errors').length).toBe(1);
            expect( commonInfo.find('ErrorDisplay[fieldName="priority"]').prop('errors')[0]['error']).toBe("priority is required");
        });*/
    });

    describe('branchCode', () => {
        it('should render once', () => {
            expect(branchCode.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(branchCode.prop('required')).toBe(true);
        });
      /*  it('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            branchCode.simulate('blur',{target:{...branchCode.props()}, type: 'blur', preventDefault: () => {} });
            expect( commonInfo.find('ErrorDisplay[fieldName="branchCode"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('targetDate', () => {
        it('should render once', () => {
            expect(targetDate.length).toBe(1);
        });

    /*    it('should have validation attributes set', () => {
            expect(sttargetDateatus.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            targetDate.simulate('blur',{target:{...targetDate.props()}, type: 'blur', preventDefault: () => {} });
            expect( commonInfo.find('ErrorDisplay[fieldName="targetDate"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('processingType', () => {
     /*   it('should render once', () => {
            expect(processingType.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(processingType.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            processingType.simulate('blur',{target:{...processingType.props()}, type: 'blur', preventDefault: () => {} });
            expect( commonInfo.find('ErrorDisplay[fieldName="processingType"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('custSegmnt', () => {
      /*  it('should render once', () => {
            expect(custSegmnt.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(custSegmnt.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            custSegmnt.simulate('blur',{target:{...custSegmnt.props()}, type: 'blur', preventDefault: () => {} });
            expect( commonInfo.find('ErrorDisplay[fieldName="custSegmnt"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('lob', () => {
 /*       it('should render once', () => {
            expect(lob.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(lob.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            lob.simulate('blur',{target:{...lob.props()}, type: 'blur', preventDefault: () => {} });
            expect( commonInfo.find('ErrorDisplay[fieldName="lob"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('supplementary', () => {
   /*     it('should render once', () => {
            expect(supplementary.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(supplementary.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            supplementary.simulate('blur',{target:{...supplementary.props()}, type: 'blur', preventDefault: () => {} });
            expect( commonInfo.find('ErrorDisplay[fieldName="supplementary"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('processingSite', () => {
  /*      it('should render once', () => {
            expect(processingSite.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(processingSite.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            processingSite.simulate('blur',{target:{...processingSite.props()}, type: 'blur', preventDefault: () => {} });
            expect( commonInfo.find('ErrorDisplay[fieldName="processingSite"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('attachToAppReference', () => {
  /*      it('should render once', () => {
            expect(attachToAppReference.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(attachToAppReference.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            attachToAppReference.simulate('blur',{target:{...attachToAppReference.props()}, type: 'blur', preventDefault: () => {} });
            expect( commonInfo.find('ErrorDisplay[fieldName="attachToAppReference"]').prop('errors').length).toBe(0);
        });*/
    });
    
});
