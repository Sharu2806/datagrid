export default (state=null, action) => {
    switch (action.type) {
        case "FETCH_INDEXING_DATA":
             state = {
                  ...action.payload
                };
            break;
        case "SAVE_BASIC_INFORMATION_DATA":
            state = [{
                text: 'SAVE_BASIC_INFORMATION_DATA',
                completed:false},
                ...state,    
                {            
                basicInformation: {
                    ...action.payload
                }
                }
            ]            
            break;
        case "SAVE_COMMON_INFORMATION_DATA":

            state = [{
                text: 'SAVE_COMMON_INFORMATION_DATA',
                completed:false},
                ...state,
                {
                commonInformation: {
                    ...action.payload
                }
                }
            ]
           
            break;
        case "SAVE_INDEXING_INFORMATION_DATA":

            state = [{
                text: 'SAVE_INDEXING_INFORMATION_DATA',
                completed:false},
                ...state,
                {
                indexingInformation: {
                    ...action.payload
                }
                }
            ]            
            break;

        case "SEND_DATA":
            //console.log("Sending data in reducer ", action.payload);
            alert("Data Sent Successfully");
            state = [{
                text: 'SEND_DATA',
                status:'Data Sent Successfully',
                completed:false}              
                               
            ]
            
            break;

        case "GET_CUST_NAME":
            //console.log("Get Cust Name in reducer ", action.payload);
            state = [{
                text: 'GET_CUST_NAME',
                completed:false},
                ...state,
                {
                indexingInformation: {
                    customerName: action.payload,
                }  
                }
            ]
            
            //console.log(state);
            break;
        default:
            
    }
    return state;
}