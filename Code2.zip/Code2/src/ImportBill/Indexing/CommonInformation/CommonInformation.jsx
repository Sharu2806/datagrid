import React from 'react';

import ErrorDisplay from '../../../SharedComponents/ErrorDisplay';

var commonInfoValidate = {
    "priority": { mandatory: true },
     "branchCode": { mandatory: true },
    "targetDate": { mandatory: true },
    "processingType": { mandatory: true },
    "custSegmnt": { mandatory: true },
    "lob": { mandatory: true },
    "supplementary": { mandatory: true },
    "processingSite":{mandatory:true},
    "attachToAppReference": {mandatory:true}
};
var priorityCritical = "Critical (>=75, <=99)";
var priorityHigh = "High (>=50, <=74)";
var priorityMedium = "Medium (>=25, <=49)";
var priorityLow = "Low (>=0, <=24)";

class CommonInformation extends React.Component {
    errorFromJson;
    constructor(props) {
        super(props);

     this.state = {
            inChannel: '',
            channelDateTime: '',
            scanBatchRef: '',
            branchCode: '',
            targetDate: '',
            priority: '',
            custSegmnt: '',
            lob: '',
            strtPgNo: '0',
            portfolioCode: '',
            supplementary: '',
            processingSite: '',
            processingType: '',
            sendNextQueue:'',
            attachToAppReference:'',
            errors: []
        };

        this.saveError = this.saveError.bind(this);
        this.addError = this.addError.bind(this);
        this.removeError = this.removeError.bind(this);
        this.handleInputChange = this.handleInputChange.bind(this);
        this.saveData = this.saveData.bind(this);
        this.fetchData = this.fetchData.bind(this);
    }
    saveError(value) {
        this.errorFromJson = value;
    }
    componentDidMount() {
        this.props.onRef(this);
        
        fetch('json/ImportBillError.json', {
            method: 'GET'
        })
            .then(result => result.json())
            .then(body => this.saveError(body));

    }

    componentWillUnmount() {
        this.props.onRef(undefined)
    }

    saveData() {
          this.props.saveCommonInformationData(this.state);
    }

    fetchData() {

        let obj = this.props.inputData;
        this.setState({
            ...obj
        }
        );
    }


    handleInputChange(event) {
        this.removeError(event);
        this.setState({ [event.target.name]: event.target.value });
    }

    addError(event) {
        let target;
        if (event.type === 'blur') {
            event.preventDefault();
            target = event.target;
        } else {
            target = event;
        }
        let name = target.name;
        let value = target.value;
        let error;
        if (target.required && !value) {
            error = {
                fieldName: name,
                error: this.errorFromJson[name].required,
            };
            this.pushErrorNew(error);
        }else if(name === 'branchCode'&& value.length !==3){
          
            error = {
                fieldName: name,
                error: this.errorFromJson[name].minLength,
            };
            this.pushErrorNew(error);
   
        }
    }
    pushErrorNew(error) {
        let tempErrorHolder = this.state.errors;
        tempErrorHolder.push(error);

        this.setState({ errors: tempErrorHolder });
    }
   removeError(event) {
        let target;
        event.preventDefault();
        target = event.target;

        let tempErrorHolder = this.state.errors;
        let indexValue = -1;
        for (let i = 0; i < tempErrorHolder.length; i++) {
            if (tempErrorHolder[i].fieldName === target.name) {
                indexValue = i;
                break;
            }
        }
        if (indexValue > -1) {
            tempErrorHolder.splice(indexValue, 1);
            this.setState({
                errors: tempErrorHolder
            });
        }
    }
    render() {
        return (
                <form>
                  <div className="row row-margin">
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">In Channel</span><br />
                        <select 
                            className="form-control selectCss" 
                            value={this.state.inChannel} 
                            onChange={this.handleInputChange} 
                            name="inChannel" id="inChannel" disabled>
                            <option value="scan">Scan</option>
                            <option value="Print">Print</option>
                        </select>
                    </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Channel In Date Time</span><br />
                        <input 
                            type="text" 
                            className="form-control" 
                            value={this.state.channelDateTime} 
                            onChange={this.handleInputChange} 
                            name="channelDateTime" id="channelDateTime" disabled/>
                    </div>
                     <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Scan/Fax Batch Reference</span><br />
                        <input 
                            type="text" 
                            className="form-control"
                            value={this.state.scanBatchRef} 
                            onChange={this.handleInputChange} 
                            name="scanBatchRef" id="scanBatchRef" disabled/>
                    </div>
                </div>
                <div className="row row-margin">                 
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Branch Code<span style={{ color: 'red' }}>*</span></span><br />
                        <input 
                            type="text" 
                            className="form-control" 
                            value={this.state.branchCode} 
                            onChange={this.handleInputChange} 
                            name="branchCode" id="branchCode"  
                            required={commonInfoValidate ? commonInfoValidate.branchCode.mandatory : false} 
                            onBlur={this.addError} 
                            onFocus={this.removeError} 
                            min={0} />
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName='branchCode' 
                            className='errorClass' />
                    </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Target Completion Date Time<span style={{ color: 'red' }}>*</span></span><br />
                        <input 
                            type="text" 
                            className="form-control" 
                            required={commonInfoValidate ? commonInfoValidate.targetDate.mandatory : false} 
                            onBlur={this.addError} 
                            onFocus={this.removeError} 
                            value={this.state.targetDate} 
                            onChange={this.handleInputChange} 
                            name="targetDate" id="targetDate" disabled />
                         </div>
                     <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Priority<span style={{ color: 'red' }}>*</span></span><br />
                        <select 
                            className="form-control selectCss" 
                            onFocus={this.removeError} 
                            onBlur={this.addError} 
                            required={commonInfoValidate ? commonInfoValidate.targetDate.mandatory : false} 
                            value={this.state.priority}
                            onChange={this.handleInputChange}
                            name="priority" id="priority">
                            <option value="">Please Select</option>
                            <option value={priorityCritical}>{priorityCritical}</option>
                            <option value={priorityHigh}>{priorityHigh}</option>
                            <option value={priorityMedium}>{priorityMedium}</option>
                            <option value={priorityLow}>{priorityLow}</option>
                        </select>
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName='priority' 
                            className='errorClass' />
                    </div>
                </div>
                <div className="row row-margin">
                     <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Customer Segmentation<span style={{ color: 'red' }}>*</span></span>
                        <br />
                        <div className="row">
                            <div className="col-xs-4 col-sm-5 col-md-7 col-lg-4">
                                <input 
                                    type="radio" 
                                    name="custSegmnt" id="custSegmnt" 
                                    value="Standard" 
                                    onFocus={this.removeError} 
                                    onChange={this.handleInputChange} 
                                    defaultChecked={this.state.custSegmnt === 'Standard'} />&nbsp;&nbsp;Standard
                            </div>
                            <div className="col-xs-8 col-sm-7 col-md-6 col-lg-4">
                                <input 
                                    type="radio" 
                                    name="custSegmnt" id="custSegmnt2" 
                                    value="Premium" 
                                    onFocus={this.removeError} 
                                    onChange={this.handleInputChange} 
                                    defaultChecked={this.state.custSegmnt === 'Premium'} />&nbsp; Premium
                            </div>
                        </div>
                    </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">LOB<span style={{ color: 'red' }}>*</span></span><br />
                        <select 
                            className="form-control selectCss" 
                            onFocus={this.removeError} 
                            onBlur={this.addError} 
                            required={commonInfoValidate ? commonInfoValidate.lob.mandatory : false} 
                            value={this.state.lob} 
                            onChange={this.handleInputChange} 
                            name="lob" id="lob">
                            <option value="">Please Select</option>
                            <option value="RBWM">RBWM</option>
                            <option value="CMB">CMB</option>
                        </select>
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName='lob' 
                            className='errorClass' />
                    </div>
                     <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Portfolio Code</span><br />
                        <input 
                            type="text"
                            className="form-control" 
                            value={this.state.portfolioCode} 
                            onChange={this.handleInputChange} 
                            name="portfolioCode" id="portfolioCode" />
                    </div>             
                </div>
                <div className="row row-margin">           
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Processing Site<span style={{ color: 'red' }}>*</span></span><br />
                        <select 
                            className="form-control selectCss" 
                            onFocus={this.removeError} 
                            onBlur={this.addError} 
                            required={commonInfoValidate ? commonInfoValidate.processingSite.mandatory : false} 
                            value={this.state.processingSite} 
                            onChange={this.handleInputChange} 
                            name="processingSite" id="processingSite">
                            <option value="">Please Select</option>
                            <option value="AMH">AMH</option>
                            <option value="GZC">GZC</option>
                            <option value="KLH">KLH</option>
                            <option value="CBH">CBH</option>
                            <option value="SCS">SCS</option>
                            <option value="MMO">MMO</option>
                            <option value="SDC">SDC</option>
                            <option value="STD">STD</option>
                            <option value="CHN">CHN</option>
                        </select>
                        <ErrorDisplay errors={this.state.errors} fieldName='processingSite' className='errorClass' />
                    </div>
                     <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Starting Page no for customer view</span><br />
                        <input 
                            type="number" 
                            className="form-control" 
                            value={this.state.strtPgNo} 
                            onChange={this.handleInputChange} 
                            name="strtPgNo" id="strtPgNo" />
                    </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Process Type</span><br />
                        <select 
                            className="form-control selectCss"
                            required={commonInfoValidate ? commonInfoValidate.processingSite.mandatory : false} 
                            value={this.state.processingType} 
                            onChange={this.handleInputChange} 
                            name="processingType" id="processingType">
                            <option value="Import DC Bill">Import DC Bill</option>
                        </select>
                    </div>       
                </div>
                <div className="row row-margin">
                     <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Supplementary</span>
                        <br />
                        
                            {this.state.supplementary === "Yes" ? 
                           <div className="row"> <div className="col-xs-4 col-sm-4 col-md-5 col-lg-4">                                
                                <input 
                                    type="radio" 
                                    name="supplementary"  
                                    value="Yes" 
                                    onClick={this.handleInputChange} 
                                    defaultChecked="checked" /> &nbsp;Yes
                            </div>
                            <div className="col-xs-8 col-sm-8 col-md-7 col-lg-8">
                                <input 
                                    type="radio" 
                                    name="supplementary"  
                                    value="No" 
                                    onClick={this.handleInputChange} /> &nbsp;No
                            </div>
                            </div> : <div className="row">
                                <div className="col-xs-4 col-sm-4 col-md-5 col-lg-4">                                
                                <input 
                                    type="radio" 
                                    name="supplementary"  
                                    value="Yes" 
                                    onClick={this.handleInputChange}  /> &nbsp;Yes
                            </div>
                            <div className="col-xs-8 col-sm-8 col-md-7 col-lg-4">
                                <input 
                                    type="radio" 
                                    name="supplementary"  
                                    value="No" 
                                    onClick={this.handleInputChange} 
                                    defaultChecked="checked" /> &nbsp;No
                            </div>
                        </div>}
                    </div>
                       {this.state.supplementary === "Yes" ?
                        <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                            <span className="label-margin-below">Send original item to next queue </span>
                            <br />
                            <div className="row">
                                <div className="col-xs-4 col-sm-4 col-md-5 col-lg-4">
                                    <input 
                                        type="radio"
                                        name="sendNextQueue" id="formalAmendment" 
                                        value="Yes" 
                                        onChange={this.handleInputChange} /> &nbsp;Yes
                                </div>
                                <div className="col-xs-8 col-sm-8 col-md-7 col-lg-4">
                                    <input 
                                        type="radio" 
                                        name="sendNextQueue" id="formalAmendment2" 
                                        value="No" 
                                        onChange={this.handleInputChange} 
                                        defaultChecked /> &nbsp;No
                                </div>
                            </div>
                        </div>
                        : null}
                    {
                        this.state.supplementary === "Yes" ?
                            <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                                <span className="label-margin-below">Attach To Application Reference</span><span style={{ color: 'red' }}>*</span><br />
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    value={this.state.attachToAppReference} 
                                    onFocus={this.removeError} 
                                    onBlur={this.addError} 
                                    required={commonInfoValidate ? commonInfoValidate.attachToAppReference.mandatory : false} 
                                    onChange={this.handleInputChange} 
                                    name="attachToAppReference" id="attachToAppReference" />
                                <ErrorDisplay 
                                    errors={this.state.errors} 
                                    fieldName='attachToAppReference' 
                                    className='errorClass' />
                            </div>

                            : null}
                   
                    
                </div>
            </form>
        )
    }
}
export default CommonInformation;
