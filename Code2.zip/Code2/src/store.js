import { applyMiddleware, combineReducers, createStore } from 'redux';
import logger from 'redux-logger';
import thunk from 'redux-thunk';

import indexingReducer from './Guarantee/Indexing/IndexingReducers';
import recordingDCReducer from './Guarantee/Recording/RecordingDCReducers';
import recordingReducer from './Guarantee/Recording/RecordingReducers';
import bankReducer from './Guarantee/Recording/Reducers/BankReducer';
import indexingImportBillReducer from './ImportBill/Indexing/IndexingImportBillReducers';
import recordingImportBillReducers from './ImportBill/Recording/RecordingImportBillReducers';

const mainReducer=combineReducers({
    indexingReducer: indexingReducer, 
    recordingDCReducer: recordingDCReducer,
    recordingReducer: recordingReducer,
    bankReducer: bankReducer,
    indexingImportBillReducer: indexingImportBillReducer,
    recordingImportBillReducers: recordingImportBillReducers
});

const store = createStore(mainReducer, applyMiddleware(thunk, logger));
//const store = createStore(indexingImportBillReducer, applyMiddleware(thunk, logger));
export default store;
