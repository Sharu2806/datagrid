
import React from 'react';
import { DateField, DatePicker } from 'react-date-picker';

import { formatDate } from '../../../DateUtil.js';

import ErrorDisplay from '../../../SharedComponents/ErrorDisplay';
import * as Utils from '../../../common.js';

var commonInfoValidate = {
    "priority": { mandatory: true },
    "targetDate": { mandatory: true },
    "processingType": { mandatory: true },
    "custSegmnt": { mandatory: true },
    "lob": { mandatory: true },
    "supplementary": { mandatory: true },
    "processingSite": { mandatory: true },
    "attachToAppReference": { mandatory: true }
};
var priorityCritical = "Critical (>=75, <=99)";
var priorityHigh = "High (>=50, <=74)";
var priorityMedium = "Medium (>=25, <=49)";
var priorityLow = "Low (>=0, <=24)";

class CommonInformation extends React.Component {
    errorFromJson;
    constructor(props) {
        super(props);

        this.state = {
            inChannel: '',
            channelDateTime: '',
            scanBatchRef: '',
            branchCode: '',
            targetDate: '',
            priority: '',
            custSegmnt: '',
            lob: '',
            strtPgNo: '',
            portfolioCode: '',
            supplementary: '',
            processingSite: '',
            processingType: '',
            sendNextQueue: '',
            attachToAppReference: '',
            errors: []
        };

        this.saveError = this.saveError.bind(this);
        this.addError = this.addError.bind(this);
        this.removeError = this.removeError.bind(this);

        this.handleInputChange = this.handleInputChange.bind(this);
        this.saveData = this.saveData.bind(this);
    }

    componentWillMount() {
        this.setState({
            ...this.props.inputData,
            inChannel: "scan"
        });
    }

    componentDidMount() {
        this.props.onRef(this);

        fetch('json/errorFile.json', {
            method: 'GET'
        })
            .then(result => result.json())
            .then(body => this.saveError(body));
    }

    componentWillReceiveProps(nextProps) {

    }

    componentWillUnmount() {
        this.props.onRef(undefined)
    }

    removeError(event) {
        Utils.removeError(event, this);
    }

    saveError(value) {
        this.errorFromJson = value;
    }

    saveData() {
        if (Utils.validateErrors(this)) {
            this.props.saveCommonInformationData(this.state);
        }
    }

    handleInputChange(event) {
        Utils.handleChange(event, this);
        if (event.target.name === "supplementary" && event.target.value === "No") {
            this.setState({ attachToAppReference: "" });
        }
    }

    addError(event) {
        Utils.addError(event, this);
    }

    render() {

        return (
            <form>
                <div className="row ">
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">In Channel</span><br />
                        <select className="form-control selectCss" disabled value={this.state.inChannel} onChange={this.handleInputChange} name="inChannel" id="inChannel">
                            <option value="scan">Scan</option>
                            <option value="Print">Print</option>
                        </select>
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Channel In Date Time</span><br />
                        <DateField className="form-control" dateFormat="YYYY-MM-DD HH:mm:ss" forceValidDate={true} defaultValue={formatDate(this.state.channelDateTime)} >
                            <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} highlightToday={true} weekNumbers={true} weekStartDay={0} />
                        </DateField>
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Scan/Fax Batch Reference</span><br />
                        <input type="text" className="form-control" disabled value={this.state.scanBatchRef} onChange={this.handleInputChange} name="scanBatchRef" id="scanBatchRef" />
                    </div>
                    <div className="clearfix visible-md visible-sm"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Branch Code</span><br />
                        <input type="text" className="form-control" value={this.state.branchCode} onChange={this.handleInputChange} name="branchCode" id="branchCode" />
                    </div>
                    <div className="clearfix visible-lg"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Target Completion Date Time<span style={{ color: 'red' }}>*</span></span><br />
                        <DateField className="form-control" disabled={true} dateFormat="YYYY-MM-DD HH:mm:ss" forceValidDate={true} defaultValue={formatDate(this.state.targetDate)} >
                            <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} highlightToday={true} weekNumbers={true} weekStartDay={0} />
                        </DateField>
                        <ErrorDisplay errors={this.state.errors} fieldName='targetDate' className='errorClass' />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Priority<span style={{ color: 'red' }}>*</span></span><br />
                        <select className="form-control selectCss" onFocus={this.removeError} onBlur={this.addError} required={commonInfoValidate ? commonInfoValidate.targetDate.mandatory : false} value={this.state.priority} onChange={this.handleInputChange} name="priority" id="priority">
                            <option value="">Please Select</option>
                            <option value={priorityCritical}>{priorityCritical}</option>
                            <option value={priorityHigh}>{priorityHigh}</option>
                            <option value={priorityMedium}>{priorityMedium}</option>
                            <option value={priorityLow}>{priorityLow}</option>
                        </select>
                        <ErrorDisplay errors={this.state.errors} fieldName='priority' className='errorClass' />
                    </div>
                    <div className="clearfix visible-md visible-sm"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Customer Segmentation<span style={{ color: 'red' }}>*</span></span>
                        <br />
                        <div className="row">
                            <div className="col-xs-4 col-sm-5 col-md-6 col-lg-6">
                                <input type="radio" name="custSegmnt" id="custSegmnt" value="Standard" onFocus={this.removeError} onChange={this.handleInputChange} checked={this.state.custSegmnt === 'Standard'} />Standard
                            </div>
                            <div className="col-xs-8 col-sm-7 col-md-6 col-lg-6">
                                <input type="radio" name="custSegmnt" id="custSegmnt2" value="Premium" onFocus={this.removeError} onChange={this.handleInputChange} checked={this.state.custSegmnt === 'Premium'} />Premium
                            </div>
                        </div>
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">LOB<span style={{ color: 'red' }}>*</span></span><br />
                        <select className="form-control selectCss" onFocus={this.removeError} onBlur={this.addError} required={commonInfoValidate ? commonInfoValidate.lob.mandatory : false} value={this.state.lob} onChange={this.handleInputChange} name="lob" id="lob">
                            <option value="">Please Select</option>
                            <option value="GB">GB</option>
                            <option value="BB">BB</option>
                            <option value="CMB">CMB</option>
                        </select>
                        <ErrorDisplay errors={this.state.errors} fieldName='lob' className='errorClass' />
                    </div>
                    <div className="clearfix visible-lg"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Portfolio Code</span><br />
                        <input type="text" className="form-control" value={this.state.portfolioCode} onChange={this.handleInputChange} name="portfolioCode" id="portfolioCode" />
                    </div>
                    <div className="clearfix visible-md visible-sm"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Processing Site<span style={{ color: 'red' }}>*</span></span><br />
                        <select className="form-control selectCss" onFocus={this.removeError} onBlur={this.addError} required={commonInfoValidate ? commonInfoValidate.processingSite.mandatory : false} value={this.state.processingSite} onChange={this.handleInputChange} name="processingSite" id="processingSite">
                            <option value="">Please Select</option>
                            <option value="AMH">AMH</option>
                            <option value="GZC">GZC</option>
                            <option value="KLH">KLH</option>
                            <option value="CBH">CBH</option>
                            <option value="SCS">SCS</option>
                            <option value="MMO">MMO</option>
                            <option value="SDC">SDC</option>
                            <option value="STD">STD</option>
                            <option value="CHN">CHN</option>
                        </select>
                        <ErrorDisplay errors={this.state.errors} fieldName='processingSite' className='errorClass' />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Starting Page no for customer view</span><br />
                        <input type="number" className="form-control" value={this.state.strtPgNo} onChange={this.handleInputChange} name="strtPgNo" id="strtPgNo" />
                    </div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Process Type</span><br />
                        <select className="form-control selectCss" required={commonInfoValidate ? commonInfoValidate.processingSite.mandatory : false} value={this.state.processingType} onChange={this.handleInputChange} name="processingType" id="processingType">
                            <option value="Guarantee Issuance">Guarantee Issuance</option>
                        </select>
                    </div>
                    <div className="clearfix visible-md visible-sm"></div>
                    <div className="clearfix visible-lg"></div>
                    <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                        <span className="label-margin-below">Supplementary</span>
                        <br />
                        <div className="row">
                            <div className="col-xs-4 col-sm-4 col-md-5 col-lg-4">
                                <input type="radio" name="supplementary" id="formalAmendment" value="Yes" onChange={this.handleInputChange} checked={this.state.supplementary === "Yes"} />Yes
                                </div>
                            <div className="col-xs-8 col-sm-8 col-md-7 col-lg-8">
                                <input type="radio" name="supplementary" id="formalAmendment2" value="No" onChange={this.handleInputChange} checked={this.state.supplementary === "No"} />No
                                </div>
                        </div>
                    </div>
                    {
                        this.state.supplementary === "Yes" ?
                            <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                                <span className="label-margin-below">Send original item to next queue </span>
                                <br />
                                <div className="row">
                                    <div className="col-xs-4 col-sm-4 col-md-5 col-lg-4">
                                        <input type="radio" name="sendNextQueue" id="formalAmendment" value="Yes" onChange={this.handleInputChange} /> &nbsp;Yes
                                    </div>
                                    <div className="col-xs-8 col-sm-8 col-md-7 col-lg-8">
                                        <input type="radio" name="sendNextQueue" id="formalAmendment2" value="No" onChange={this.handleInputChange} defaultChecked /> &nbsp;No
                                    </div>
                                </div>
                            </div>
                            : null
                    }
                    {
                        this.state.supplementary === "Yes" ?
                            <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                                <span className="label-margin-below">Attach To Application Reference</span><span style={{ color: 'red' }}>*</span><br />
                                <input type="text" className="form-control" value={this.state.attachToAppReference} onFocus={this.removeError} onBlur={this.addError} required={commonInfoValidate ? commonInfoValidate.attachToAppReference.mandatory : false} onChange={this.handleInputChange} name="attachToAppReference" id="attachToAppReference" />
                                <ErrorDisplay errors={this.state.errors} fieldName='attachToAppReference' className='errorClass' />
                            </div>
                            : null
                    }
                </div>
            </form>
        )
    }
}

export default CommonInformation;

