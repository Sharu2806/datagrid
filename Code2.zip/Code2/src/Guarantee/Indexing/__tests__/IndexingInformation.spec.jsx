import IndexingInformation from '../IndexingInformation/IndexingInformation';
import { SubmissionError } from 'redux-form'
import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, render, mount } from 'enzyme';
import { DateField, DatePicker } from 'react-date-picker';
import moment from 'moment';
import 'isomorphic-fetch';

import data from '../../../../public/json/indexingInformationRecord.json';

let indexingInfo = null;
let customerAccountNumber = null;
let customerName = null;
let applicationDateTime = null;
let transactionCurrency = null;
let transactionAmount = null;
let sgNumber = null;
let customerGHOClass = null;
let applicationReference = null;
let captureUnderProduct = null;
let otherBankReference = null;
let expiryDate = null;
            
beforeAll(() => {
    indexingInfo = shallow(<IndexingInformation/>);    
    customerAccountNumber = indexingInfo.find('input[name="customerAccountNumber"]');
    customerName = indexingInfo.find('input[name="customerName"]');
	applicationDateTime = indexingInfo.find('input[name="applicationDateTime"]');
	transactionCurrency = indexingInfo.find('select[name="transactionCurrency"]');
	transactionAmount = indexingInfo.find('input[name="transactionAmount"]');
	sgNumber = indexingInfo.find('input[name="sgNumber"]');	  
    customerGHOClass = indexingInfo.find('input[name="customerGHOClass"]');
    applicationReference = indexingInfo.find('input[name="applicationReference"]');
    captureUnderProduct = indexingInfo.find('select[name="captureUnderProduct"]');
    otherBankReference = indexingInfo.find('input[name="otherBankReference"]');
    expiryDate = indexingInfo.find('input[name="expiryDate"]');
});

describe('IndexingInformation', () => {
    it('renders without crashing', () => {
        expect(indexingInfo.find('form').length).toBe(1);
    });

    it('page header should be - Indexing Information', () => {
        const header = <span className="Muli-Bold" style={{ fontSize: '16px' }}>Indexing Information</span>;
        expect(indexingInfo.contains(header)).toEqual(false);
    });

     
     describe('customerGHOClass', () => {
        it('should render once', () => {
            expect(customerGHOClass.length).toBe(1);
        });
     });

     describe('applicationReference', () => {
        it('should render once', () => {
            expect(applicationReference.length).toBe(1);
        });
     });

     describe('captureUnderProduct', () => {
        it('should render once', () => {
            const selectCapture = <select className="form-control selectCss" name="captureUnderProduct" id="captureUnderProduct">
                            <option value="">Please Select</option>
                            <option value="FNG">FNG</option>
                            <option value="APG">APG</option>
                            <option value="BBG">BBG</option>
                            <option value="PMG">PMG</option>
                        </select>;
        expect(indexingInfo.contains(selectCapture)).toEqual(false);
        });
     });

     describe('otherBankReference', () => {
        it('should render once', () => {
            expect(otherBankReference.length).toBe(0);
        });
     });


    describe('customerAccountNumber', () => {
        it('should render once', () => {
            expect(customerAccountNumber.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(customerAccountNumber.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            customerAccountNumber.simulate('blur',{target:{...customerAccountNumber.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="customerAccountNumber"]').prop('errors').length).toBe(1);
            expect( indexingInfo.find('ErrorDisplay[fieldName="customerAccountNumber"]').prop('errors')[0]['error']).toBe("customerAccountNumber is required");
        });
    });

    describe('customerName', () => {
        it('should render once', () => {
            expect(customerName.length).toBe(1);
        });

        // it('should have validation attributes set', () => {
        //     expect(customerName.prop('required')).toBe(true);
        // });
    /*    it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            customerName.simulate('blur',{target:{...customerName.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="customerName"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('applicationDateTime', () => {
        // it('should render once', () => {
        //     expect(applicationDateTime.length).toBe(1);
        // });
         it('should render once', () => {
        /*const datefield = <DateField className="form-control" dateFormat="YYYY-MM-DD HH:mm:ss" forceValidDate={true} defaultValue={moment()} >
                            <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} highlightToday={true} weekNumbers={true} weekStartDay={0} />
                        </DateField>;*/
        expect(indexingInfo.contains('Application Received Date Time')).toEqual(true);
    });
});
describe('expiryDate', () => {
        // it('should render once', () => {
        //     expect(applicationDateTime.length).toBe(1);
        // });
         it('should render once', () => {
        /*const datefieldEx = <DateField className="form-control" dateFormat="YYYY-MM-DD HH:mm:ss" forceValidDate={true} defaultValue={moment()} >
                            <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} highlightToday={true} weekNumbers={true} weekStartDay={0} />
                        </DateField>;*/
        expect(indexingInfo.contains('Expiry Date')).toEqual(true);
    });
    });
   /*     it('should have validation attributes set', () => {
            expect(stapplicationDateTimeatus.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            applicationDateTime.simulate('blur',{target:{...applicationDateTime.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="applicationDateTime"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('transactionCurrency', () => {
        // it('should render once', () => {
        //     expect(transactionCurrency.length).toBe(1);
        // });
        it('page header should be - Indexing Information', () => {
        const selectTransactionCurrency = <select className="form-control selectCss"  name="transactionCurrency" id="transactionCurrency">
                            <option value="">Please Select</option>
                            <option value="INR">INR</option>
                            <option value="HKD">HKD</option>
                            <option value="USD">USD</option>
                        </select>;
        expect(indexingInfo.contains(selectTransactionCurrency)).toEqual(false);
    });

      /*  it('should have validation attributes set', () => {
            expect(transactionCurrency.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            transactionCurrency.simulate('blur',{target:{...transactionCurrency.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="transactionCurrency"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('transactionAmount', () => {
        it('should render once', () => {
            expect(transactionAmount.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(transactionAmount.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            transactionAmount.simulate('blur',{target:{...transactionAmount.props()}, type: 'blur', preventDefault: () => {} });
            //expect( indexingInfo.find('ErrorDisplay[fieldName="transactionAmount"]').prop('errors').length).toBe(0);
            expect( indexingInfo.find('ErrorDisplay[fieldName="transactionAmount"]').prop('errors').length).toBe(2);
            //expect( indexingInfo.find('ErrorDisplay[fieldName="transactionAmount"]').prop('errors')[4]['error']).toBe("transactionAmount is required");
        });
    });
	describe('sgNumber', () => {
        it('should render once', () => {
            expect(sgNumber.length).toBe(1);
        });

        // it('should have validation attributes set', () => {
        //     expect(GTENumber.prop('required')).toBe(true);
        // });
    /*    it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            dcNumber.simulate('blur',{target:{...dcNumber.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="dcNumber"]').prop('errors').length).toBe(0);
        });*/
    });	

