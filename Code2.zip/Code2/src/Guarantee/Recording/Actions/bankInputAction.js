export function setSource(payload){
    return {
        type : "SET_SOURCE",
        payload
    }
}

export function setDetailsAccToBankName(payload){
    return {
        type : "ACC_BANK_NAME",
        payload
    }
}

export function clearSearch(){
    return {
        type : "CLEAR_SEARCH"
    }
}

export function addCountryCode(payload){
    return {
        type  : "ADD_COUNTRY_CODE",
        payload
    }
}
