import React, { Component } from 'react';
import { connect } from 'react-redux';

import RecordInformation from '../../SharedComponents/RecordInformation';
import DefintionCriteria from './DefinitionCriteria';

import * as ACTIONS from './RecordingDCActions';

class RecordingDC extends Component {

    componentDidMount() {
        this.props.fetchRecordingDCData();
    }

    render() {
        return (
            <div className="row">
                <div className="panel panel-holding-tabs">
                    {
                        this.props.allRecordingData &&
                        <RecordInformation
                            gwisId="TTHKHBAP15123-000946P27"
                        />
                    }
                    <ul id="indexingTabs" className="nav nav-tabs" onClick={this.handleTabClick} style={{ overflow: 'hidden', position: 'relative', top: '1px' }}>
                        <li className="active"><a data-toggle="tab" href="#definitionCriteria">Definition Criteria</a></li>
                    </ul>
                </div>
                <div style={{ marginLeft: '30px', marginRight: '30px' }}>
                    {
                        this.props.allRecordingData &&
                        <DefintionCriteria
                            history={this.props.history}
                            inputData={this.props.allRecordingData.definitionCriteria}
                            generateDCNumber={this.props.generateDCNumber}
                            outputData={this.props.allRecordingData.outputData}
                            rightSideClass={this.props.rightSideClass}
                        />
                    }
                </div>
            </div>
        );
    }
}

const mapsStateToProps = (state) => {
    return {
        allRecordingData: state.recordingDCReducer
    };
};

const mapsDispatchToProps = (dispatch) => {
    return {
        fetchRecordingDCData: () => {
            dispatch(ACTIONS.fetchRecordingDCData());
        },
        generateDCNumber: (obj) => {
            dispatch(ACTIONS.generateDCNumber(obj));
        }
    };
};

export default connect(mapsStateToProps, mapsDispatchToProps)(RecordingDC);
// export default Recording;