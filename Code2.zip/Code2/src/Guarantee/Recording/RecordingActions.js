import * as ACTION_TYPES from '../GuaranteeActionTypes';

export function fetchRecordingDropdownData() {
    //console.log('fetch Recording dropdown data action');

    return dispatch => {
        fetch('http://10.191.131.54:8081/hie/guarantee-fetchLookupInfo')
        // fetch('json/recordingDropDown.json')
	// fetch('/hie/guarantee-fetchLookupInfo')
            .then(result => result.json())
            .then(body =>
                dispatch({
                    type: ACTION_TYPES.GTE_RECORDING_FETCH_RECORDING_DROPDOWN_DATA,
                    payload: body
                })
            );
    }
}
/*export function fetchRecordingData() {
    // console.log('save saveBasicInfoData data action');
    return dispatch => {
        fetch('json/recordingData.json').then(result => result.json()).then(body =>
            dispatch({
                type: 'FETCH_RECORDING_DATA',
                payload: body
            })
        );
    }
}*/
export function saveBasicInfoData(obj) {
    // console.log('save saveBasicInfoData data action');
    return {
        type: ACTION_TYPES.GTE_RECORDING_SAVE_BASIC_INFO_DATA,
        payload: obj
    };
}

export function saveBankInfoData(obj) {
    // console.log('save saveBankInfoData action');
    return {
        type: ACTION_TYPES.GTE_RECORDING_SAVE_BANK_INFO_DATA,
        payload: obj
    };
}

export function saveInternalInfoData(obj) {
    // console.log('save saveInternalInfoData data action :',JSON.stringify(obj));
    return {
        type: ACTION_TYPES.GTE_RECORDING_SAVE_INTERNAL_INFO_DATA,
        payload: obj
    };
}

export function submitRecordingData(obj) {
    return dispatch => {
        var data = JSON.stringify(obj);
        //console.log('Submitting recording Data to Mule', data);
        fetch('http://10.191.131.54:8081/hie/posthie', {
	// fetch('/hie/posthie', {
            method: 'post',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: data
        }).then(result => result.json())
            .then(body => successCall(body))
            .catch(error => errorCall(error))
    }
}

function successCall(body) {
    //console.log("Data :: ",body);
    alert("Data Submitted for Approval");
}
function errorCall(error) {
    alert(error)
}