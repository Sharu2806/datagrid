import React, { Component } from 'react';
import { connect } from "react-redux";

import ErrorDisplay from '../../SharedComponents/ErrorDisplay';

import CustomSuggestionSearch from "./CustomSuggestionSearch";

import * as Utils from '../../common.js';

var jsonResult = require("./swiftDetails.json");

var bankInfoValidate = {
    "reimbursementBankAddress": { mandatory: true },
    "advisingBankAddress": { mandatory: true },
    "establishedBy2": { mandatory: true }
};

class BankInformation extends Component {

    constructor(props) {
        super(props);
        this.state = {
            reimbursementBank: '',
            reimbursementBankAddress: '',
            reimbursementBankAddress2: '',
            reimbursementBankAddress3: '',
            advisingBankAddress: '',
            advisingBankAddress2: '',
            advisingBankAddress3: '',
            establishedBy: '',
            establishedBy2: '',
            advisingThroughBank: '',
            advisingThroughBankAddress: '',
            advisingThroughBankAddress2: '',
            advisingThroughBankAddress3: '',
            dropDownData: [],
            errors: []
        };

        this.saveError = this.saveError.bind(this);
        this.addError = this.addError.bind(this);
        this.removeError = this.removeError.bind(this);

        let errorFromJson = [];

        this.handleChange = this.handleChange.bind(this);
        this.showData = this.showData.bind(this);
        this.handleEstablishChange = this.handleEstablishChange.bind(this);
    }

    componentWillMount() {
    }

    componentDidMount() {
        this.props.onRef(this);
        this.setState({
            ...this.props.inputData
        });

        fetch('json/bankInfoValidateMsg.json', {
            method: 'GET'
        })
            .then(result => result.json())
            .then(body => this.saveError(body));
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            ...nextProps.inputData
        });
    }

    componentWillUnmount() {
        this.props.onRef(undefined)
    }

    addError(event) {
        Utils.addError(event, this);
    }

    handleChange(event) {
        Utils.handleChange(event, this)
    }

    handleEstablishChange(event) {
        let dropDownObj = this.props.recordingDropDownData;
        let gteRecording = dropDownObj.GTE_Recording.EstablishedBy;
        for (let i = 0; i < gteRecording.length; i++) {
            let obj = gteRecording[i];
            if (obj.code === event.target.value) {
                this.setState({
                    establishedBy: event.target.value,
                    establishedBy2: obj.code
                });
                let tempErrorHolder1 = this.state.errors;
                let indexValue = -1;
                for (let i = 0; i < tempErrorHolder1.length; i++) {
                    if (tempErrorHolder1[i].fieldName === "establishedBy2") {
                        indexValue = i;
                        break;
                    }
                }
                if (indexValue > -1) {
                    tempErrorHolder1.splice(indexValue, 1);
                    this.setState({
                        errors: tempErrorHolder1
                    });
                }
            }
        }
    }

    // removes error when the input field gets focussed with obj:{fieldName:abc, error:xyz}
    removeError(event) {
        Utils.removeError(event, this);
    }

    saveData() {
        if (Utils.validateErrors(this)) {
            this.props.saveBankInfoData(this.state)
        }
    }

    saveError(body) {
        this.errorFromJson = body
    }

    showData(value) {
        this.setState({
            advisingBankAddress: value.address1,
            advisingBankAddress2: value.address2,
            advisingBankAddress3: value.address3
        });

        let tempErrorHolder1 = this.state.errors;
        let indexValue = -1;
        for (let i = 0; i < tempErrorHolder1.length; i++) {
            if (tempErrorHolder1[i].fieldName === "advisingBankAddress") {
                indexValue = i;
                break;
            }
        }
        if (indexValue > -1) {
            tempErrorHolder1.splice(indexValue, 1);
            this.setState({
                errors: tempErrorHolder1
            });
        }
    }

    render() {

        var listMultipleData = ["bankName", "bankCode"]
        var listViewData = ["address1", "address2"];
        var toolTipViewData = [{
            label: "Swift Address",
            values: [
                "swiftAddress"
            ]
        }, {
            label: "Clearing Code",
            values: [
                "clearingCode"
            ]
        }, {
            label: "Swift Authentication",
            values: [
                "swiftAuthentication"
            ]
        }, {
            label: "Detailed Address",
            values: [
                "address1",
                "address2",
                "address3",
                "address4"
            ]
        }]

        var radioValues = [{
            label: "Bank Name",
            value: "bankName",
        },
        {
            label: "SWIFT Address",
            value: "swiftAddress",
        },
        {
            label: "CBID Code",
            value: "bankCode",
        }]

        var dropValues = {
            label: "Select Country",
            firstValue: "All",
            restValues: "countryCode",
            otherValues: "country"
        }

        var reimbursementBank = [];
        var establishedBy = [];
        var dropDownObj = this.props.recordingDropDownData;
        var obj = null;
        var optionObj = null;
        if (dropDownObj) {
            var recordingObj = dropDownObj.GTE_Recording;
            if (recordingObj.ReimbursementBank) {
                for (var i = 0; i < recordingObj.ReimbursementBank.length; i++) {
                    obj = recordingObj.ReimbursementBank[i]
                    optionObj = <option value={obj.code} key={i}>{obj.DropDownValue}</option>
                    reimbursementBank.push(optionObj)
                }
            }
            if (recordingObj.EstablishedBy) {
                for (i = 0; i < recordingObj.EstablishedBy.length; i++) {
                    obj = recordingObj.EstablishedBy[i]
                    optionObj = <option value={obj.code} key={i}>{obj.DropDownValue}</option>
                    establishedBy.push(optionObj)
                }
            }
        }

        const { errors } = this.state;

        return (
            <div>
                <div className="row">
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <span className="Muli-Bold" style={{ fontSize: '16px', color: 'black' }}>Bank Information</span>
                        <hr style={{ borderColor: '#cacaca', marginTop: '1px' }} />
                    </div>
                </div>
                <form>
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <span className="label-margin-below">Reimbursement Bank</span>
                            <br />
                            <select className="form-control selectCss" value={this.state.reimbursementBank} onChange={this.handleChange} name="reimbursementBank" id="reimbursementBank">
                                {reimbursementBank}
                            </select>
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <span className="label-margin-below">Reimbursement Bank Address<span style={{ color: 'red' }}>*</span></span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <input type="text" className="form-control" onChange={this.handleChange} required={bankInfoValidate ? bankInfoValidate.reimbursementBankAddress.mandatory : false} onBlur={this.addError} onFocus={this.removeError} value={this.state.reimbursementBankAddress} name="reimbursementBankAddress" id="reimbursementBankAddress" />
                            <ErrorDisplay errors={this.state.errors} fieldName='reimbursementBankAddress' className='errorClass' />
                            <input type="text" className="form-control" value={this.state.reimbursementBankAddress2} onChange={this.handleChange} name="reimbursementBankAddress2" id="reimbursementBankAddress2" />
                            <input type="text" className="form-control" value={this.state.reimbursementBankAddress3} onChange={this.handleChange} name="reimbursementBankAddress3" id="reimbursementBankAddress3" />
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-md-12 col-lg-12">
                            <span className="Muli-Bold" style={{ fontSize: '16px', color: 'black' }}>Advising Bank Code</span>
                            <hr style={{ borderColor: '#cacaca', marginTop: '1px' }} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <CustomSuggestionSearch
                                listData={jsonResult}
                                listMultipleData={listMultipleData}
                                listViewData={listViewData}
                                toolTipViewData={toolTipViewData}
                                radioButtonVisible={true}
                                radioButtonVisibleValues={radioValues}
                                dropDownVisible={true}
                                dropDownVisibleValues={dropValues}
                                dropDownVisibleFor={"bankName"}
                                sortDataBy={"bankName"}
                                searchByChars={3}
                                validateInput={false}
                                id="bankInputWidget"
                                radioGroupLabelVisible={true}
                                showData={this.showData}
                                 toolTipVisible = {true}
                                dataToShowOnSelect={"Auto"}
                            />
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Advising Bank Address<span style={{ color: 'red' }}>*</span></span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <input type="text" className="form-control" value={this.state.advisingBankAddress} onChange={this.handleChange} required={bankInfoValidate ? bankInfoValidate.advisingBankAddress.mandatory : false} onBlur={this.addError} onFocus={this.removeError} name="advisingBankAddress" id="advisingBankAddress" />
                            <ErrorDisplay errors={this.state.errors} fieldName='advisingBankAddress' className='errorClass' />
                            <input type="text" className="form-control" value={this.state.advisingBankAddress2} onChange={this.handleChange} name="advisingBankAddress2" id="advisingBankAddress2" />
                            <input type="text" className="form-control" value={this.state.advisingBankAddress3} onChange={this.handleChange} name="advisingBankAddress3" id="advisingBankAddress3" />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <hr style={{ borderColor: '#cacaca' }} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Established By<span style={{ color: 'red' }}>*</span></span>
                            <br />
                            <div className="row no-gutter">
                                <div className="col-xs-3 col-sm-3 col-md-5 col-lg-4" style={{ paddingRight: '5px' }}>
                                    <select className="form-control selectCss" value={this.state.establishedBy} onChange={this.handleEstablishChange} name="establishedBy" id="establishedBy">
                                        {establishedBy}
                                    </select>
                                </div>
                                <div className="col-xs-9 col-sm-9 col-md-7 col-lg-8">
                                    <input type="text" className="form-control" value={this.state.establishedBy2} onChange={this.handleChange} required={bankInfoValidate ? bankInfoValidate.establishedBy2.mandatory : false} onBlur={this.addError} onFocus={this.removeError} name="establishedBy2" id="establishedBy2" />
                                    <ErrorDisplay errors={this.state.errors} fieldName='establishedBy2' className='errorClass' />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <hr style={{ borderColor: '#cacaca' }} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <span className="label-margin-below">Advise Through Bank</span>
                            <br />
                            <div className="row no-gutter">
                                <div className="col-xs-10 col-sm-10 col-md-10 col-lg-10" style={{ paddingRight: '5px' }}>
                                    <input type="text" className="form-control" value={this.state.advisingThroughBank} onChange={this.handleChange} name="advisingThroughBank" id="advisingThroughBank" />
                                </div>
                                <div className="col-xs-2 col-sm-2 col-md-2 col-lg-2" style={{ marginTop: '10px' }}>
                                    <button className="btn btn-green"><embed className="icon" src="icons/search.svg" alt="" /></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <span className="label-margin-below">Advise Through Bank Address</span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                            <input type="text" className="form-control" value={this.state.advisingThroughBankAddress} onChange={this.handleChange} name="advisingThroughBankAddress" id="advisingThroughBankAddress" />
                            <input type="text" className="form-control" value={this.state.advisingThroughBankAddress2} onChange={this.handleChange} name="advisingThroughBankAddress2" id="advisingThroughBankAddress2" />
                            <input type="text" className="form-control" value={this.state.advisingThroughBankAddress3} onChange={this.handleChange} name="advisingThroughBankAddress3" id="advisingThroughBankAddress3" />
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}

function mapStateToProps(store) {
    return {
        recordingDropDownData: store.recordingReducer.recordingDropDownData
    }
}

export default connect(mapStateToProps)(BankInformation);
