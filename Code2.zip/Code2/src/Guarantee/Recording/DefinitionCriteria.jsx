import React, { Component } from 'react';


import Validator from 'validator';
import isEmpty from 'lodash/isEmpty';
import classnames from 'classnames';

class DefinitionCriteria extends Component {

    constructor(props) {
        super(props);
        this.state = {
            accountNumber: '',
            accountNumber1: this.props.inputData.accountNumber.substring(3, 7),
            accountNumber2: this.props.inputData.accountNumber.substring(8, 11),
            accountNumber3: this.props.inputData.accountNumber.substring(12, 18),
            accountNumber4: this.props.inputData.accountNumber.substring(19, 22),
            name: '',
            transactionNumber: '',
            transactionNumber2: '',
            transactionNumber3: '',
            itReferenceNumber: '',
            formalAmendment: '',
            copyFromAccount1: '',
            copyFromAccount2: '',
            copyFromAccount3: '',
            copyFromAccount4: '',
            copyFromAccount5: '',
            copyFromTransaction: '',
            copyFromTransaction2: '',
            copyFromTransaction3: '',
            bussinessUnitId: '',
            wolfStatus: '',
            hexagonReferenceNumber: '',
            errors: []
        };

        this.continue = this.continue.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }


    validateInput(data) {
        let errors = {};

        //console.log("Calling validate Input () :" + data);
        //console.log("calling the errors " + JSON.stringify(this.state));

        if ((Validator.isEmpty(data.accountNumber1) && !Validator.isEmpty(data.accountNumber2))
            || (!Validator.isEmpty(data.accountNumber1) && Validator.isEmpty(data.accountNumber2)))
            errors.accountNumber = 'Please Enter Complete Account Number';
        else if (!(Validator.isEmpty(data.accountNumber1) && Validator.isEmpty(data.accountNumber1))) {
            if (Validator.isEmpty(data.accountNumber3) || Validator.isEmpty(data.accountNumber4))
                errors.accountNumber = 'Please Enter Complete Account Number';
        }

        if (!(data.accountNumber2).match("^[0-9]*$") || !(data.accountNumber3).match("^[0-9]*$") || !(data.accountNumber4).match("^[0-9]*$")) {
            errors.accountNumber = 'Please Enter Numeric Value';
        }


        return {
            errors,
            isValid: isEmpty(errors)
        }
    }

    isValid() {
        const { errors, isValid } = this.validateInput(this.state);
        if (!isValid) {
            this.setState({ errors });
        }
        return isValid;
    }

    componentWillMount() {
        this.setState({
            ...this.props.inputData
        });
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            ...nextProps.inputData
        });

        if (nextProps.outputData) {
            this.props.history.push('/recording');
        }
    }

    continue() {
        if (this.isValid()) {
            var obj = this.props.inputData
            obj.accountNumber = this.state.accountNumber.substring(0, 2) + " " + this.state.accountNumber1 + " " + this.state.accountNumber2 + " " + this.state.accountNumber3 + " " + this.state.accountNumber4;
            this.props.generateDCNumber(obj);
        }
    }

    handleChange(event) {
        let target = event.target;
        let name = target.name;
        let value = target.value;
        this.setState({
            [name]: value,
            errors: []
        });
    }

    render() {
        const { errors } = this.state;
        return (
            <div>
                <form style={{ marginBottom: '180px' }}>
                    <div className="row">
                        <div className="col-md-12 col-lg-12">
                            <span className="Muli-Bold" style={{ fontSize: '16px', color: 'black' }}>Definition Criteria</span>
                            <hr style={{ borderColor: '#cacaca', marginTop: '1px' }} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Account Number</span>
                            <br />
                            {/*<input type="text" className="form-control" value={this.state.accountNumber} onChange={this.handleChange} name="accountNumber" id="accountNumber" />*/}
                            <div className="row no-gutter">
                                <div className={classnames("form-group", { 'has-error': errors.accountNumber })}>
                                    <input
                                        type="text"
                                        className="form-control"
                                        style={{ width: '42px', marginRight: '3px', display: 'inline-block' }}
                                        name="accountNumber" id="accountNumber"
                                        value={this.state.accountNumber.substring(0, 2)} disabled
                                    />
                                    <input
                                        type="text"
                                        className="form-control"
                                        style={{ width: '70px', marginRight: '3px', display: 'inline-block' }}
                                        name="accountNumber1" id="accountNumber1"
                                        /*value={this.state.accountNumber.substring(2, 7)} */
                                        value={this.state.accountNumber1}
                                        onChange={this.handleChange}
                                        maxLength={4}
                                    />

                                    <input
                                        type="text"
                                        className="form-control"
                                        style={{ width: '52px', marginRight: '3px', display: 'inline-block' }}
                                        name="accountNumber2" id="accountNumber2"
                                        /*value={this.state.accountNumber.substring(8, 11)}*/
                                        value={this.state.accountNumber2}
                                        onChange={this.handleChange}
                                        maxLength={3}
                                    />
                                    <input
                                        type="text"
                                        className="form-control"
                                        style={{ width: '80px', marginRight: '3px', display: 'inline-block' }}
                                        name="accountNumber3" id="accountNumber3"
                                        /*value={this.state.accountNumber.substring(12,18)}*/
                                        value={this.state.accountNumber3}
                                        onChange={this.handleChange}
                                        maxLength={6} />
                                    <input
                                        type="text"
                                        className="form-control"
                                        style={{ width: '52px', marginRight: '3px', display: 'inline-block' }}
                                        name="accountNumber4" id="accountNumber4"
                                        /*value={this.state.accountNumber.substring(19, 22)}*/
                                        value={this.state.accountNumber4}
                                        onChange={this.handleChange}
                                        maxLength={3}
                                    />
                                    {errors.accountNumber && <span className="help-block">{errors.accountNumber}</span>}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Transaction Number</span>
                            <br />
                            <select className="form-control selectCss" name="transactionNumber" value={this.state.transactionNumber} onChange={this.handleChange} style={{ width: '75px', marginRight: '2px', display: 'inline-block' }} id="transactionNumber">
                                <option value="FNG">FNG</option>
                                <option value="GUA">GUA</option>
                                <option value="RAN">RAN</option>
                                <option value="TEE">TEE</option>
                            </select>
                            <input type="text" className="form-control" value={this.state.transactionNumber2} onChange={this.handleChange} style={{ width: '58px', marginRight: '2px', display: 'inline-block' }} name="transactionNumber2" id="transactionNumber2" />
                            <input type="text" className="form-control" value={this.state.transactionNumber3} onChange={this.handleChange} style={{ width: '95px', display: 'inline-block' }} name="transactionNumber3" id="transactionNumber3" />
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-7 col-lg-5">
                            <span className="label-margin-below">ITS Reference Number</span>
                            <br />
                            <div className="row no-gutter">
                                <input type="text" className="form-control" style={{ width: '62px', marginRight: '3px', display: 'inline-block' }} name="itReferenceNumber" id="itReferenceNumber" />
                                <input type="text" className="form-control" style={{ width: '42px', marginRight: '3px', display: 'inline-block' }} name="itReferenceNumber2" id="itReferenceNumber2" />
                                <input type="text" className="form-control" style={{ width: '42px', marginRight: '3px', display: 'inline-block' }} name="itReferenceNumber3" id="itReferenceNumber3" />
                                <input type="text" className="form-control" style={{ width: '42px', marginRight: '3px', display: 'inline-block' }} name="itReferenceNumber4" id="itReferenceNumber4" />
                                <input type="text" className="form-control" style={{ width: '42px', marginRight: '3px', display: 'inline-block' }} name="itReferenceNumber5" id="itReferenceNumber5" />
                                <input type="text" className="form-control" style={{ width: '42px', marginRight: '3px', display: 'inline-block' }} name="itReferenceNumber6" id="itReferenceNumber6" />
                                <input type="text" className="form-control" style={{ width: '70px', display: 'inline-block' }} name="itReferenceNumber7" id="itReferenceNumber7" />
                            </div>
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Hexagon Reference Number</span>
                            <br />
                            <input type="text" className="form-control" name="hexagonReferenceNumber" id="hexagonReferenceNumber" />
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">IE Division Code</span>
                            <br />
                            <select className="form-control selectCss" style={{ maxWidth: "105px" }} name="ieDivisionCode" id="ieDivisionCode">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                            <span style={{ marginLeft: "109px", position: "relative", top: "-31px" }}>Only for 'Search Awaiting Capture'</span>
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Create Template</span>
                            <br />
                            <div className="row">
                                <div className="col-xs-4 col-sm-4 col-md-5 col-lg-4">
                                    <input type="radio" name="createTemplate" id="createTemplate" value="Yes" />Yes
                                </div>
                                <div className="col-xs-8 col-sm-8 col-md-7 col-lg-8">
                                    <input type="radio" name="createTemplate" id="createTemplate2" value="No" checked />No
                                </div>
                            </div>
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Formal Amendment</span>
                            <br />
                            <div className="row">
                                <div className="col-xs-4 col-sm-4 col-md-5 col-lg-4">
                                    <input type="radio" name="formalAmendment" id="formalAmendment" value="Yes" />Yes
                                </div>
                                <div className="col-xs-8 col-sm-8 col-md-7 col-lg-8">
                                    <input type="radio" name="formalAmendment" id="formalAmendment2" value="No" />No
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Copy From Account</span>
                            <br />
                            {/*<input type="text" className="form-control" onChange={this.handleChange} name="accountNumber" id="accountNumber" />*/}
                            <div className="row no-gutter">
                                <input
                                    type="text"
                                    className="form-control"
                                    style={{ width: '42px', marginRight: '3px', display: 'inline-block' }}
                                    name="copyFromAccount1" id="copyFromAccount1"
                                    value={this.state.copyFromAccount1}
                                    onChange={this.handleChange}
                                    maxLength={2} />
                                <input
                                    type="text"
                                    className="form-control"
                                    style={{ width: '70px', marginRight: '3px', display: 'inline-block' }}
                                    name="copyFromAccount2" id="copyFromAccount2"
                                    value={this.state.copyFromAccount2}
                                    onChange={this.handleChange}
                                    maxLength={4} />
                                <input
                                    type="text"
                                    className="form-control"
                                    style={{ width: '52px', marginRight: '3px', display: 'inline-block' }}
                                    name="copyFromAccount3" id="copyFromAccount3"
                                    value={this.state.copyFromAccount3}
                                    onChange={this.handleChange}
                                    maxLength={3} />
                                <input
                                    type="text"
                                    className="form-control"
                                    style={{ width: '80px', marginRight: '3px', display: 'inline-block' }}
                                    name="copyFromAccount4" id="copyFromAccount4"
                                    value={this.state.copyFromAccount4}
                                    onChange={this.handleChange}
                                    maxLength={6} />
                                <input
                                    type="text"
                                    className="form-control"
                                    style={{ width: '52px', marginRight: '3px', display: 'inline-block' }}
                                    name="copyFromAccoun5" id="copyFromAccoun5"
                                    value={this.state.copyFromAccoun5}
                                    onChange={this.handleChange}
                                    maxLength={3} />
                            </div>
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Copy From Transaction</span>
                            <br />
                            {/*<input type="text" className="form-control" name="copyFromTransaction" id="copyFromTransaction" />*/}
                            <select className="form-control selectCss" name="copyFromTransaction" value={this.state.copyFromTransaction} onChange={this.handleChange} style={{ width: '75px', marginRight: '2px', display: 'inline-block' }} id="copyFromTransaction">
                                <option value="FNG">FNG</option>
                                <option value="GUA">GUA</option>
                                <option value="RAN">RAN</option>
                                <option value="TEE">TEE</option>
                            </select>
                            <input type="text" className="form-control" value={this.state.copyFromTransaction2} onChange={this.handleChange} style={{ width: '58px', marginRight: '2px', display: 'inline-block' }} name="copyFromTransaction2" id="copyFromTransaction2" />
                            <input type="text" className="form-control" value={this.state.copyFromTransaction3} onChange={this.handleChange} style={{ width: '95px', display: 'inline-block' }} name="copyFromTransaction3" id="copyFromTransaction3" />
                        </div>
                    </div>
                    <div className="row row-margin">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Business Unit ID</span>
                            <br />
                            <input type="text" className="form-control" name="bussinessUnitId" id="bussinessUnitId" value="0101" />
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below">Wolf Status</span>
                            <br />
                            <select className="form-control selectCss" name="wolfStatus" id="wolfStatus">
                                <option value="Blank">Blank</option>
                                <option value="Y">Y</option>
                                <option value="N">N</option>
                                <option value="P">P</option>
                                <option value="A">A</option>
                            </select>
                        </div>
                    </div>
                </form>
                <div
                    className={this.props.rightSideClass + " pull-right navbar-fixed-bottom bottom-buttons-layout"}
                >
                    {/*<div className="" style={{ backgroundColor: '#dedede', marginLeft: '-30px', marginRight: '-30px' }}>*/}
                    <div className="btn-toolbar" style={{ marginLeft: '25px' }}>
                        <button className="btn btn-green" onClick={this.continue}><embed className="icon" src="icons/go.svg" alt="" /><span className="buttonLabel">Continue</span></button>
                        <button className="btn btn-default" style={{ backgroundColor: "#666", color: "white" }}><embed className="icon" src="icons/search.svg" alt="" /><span className="buttonLabel">Search</span></button>
                        <button className="btn btn-default" style={{ backgroundColor: "#666", color: "white" }}>Search Awaiting Capture</button>
                        <button className="btn btn-default" style={{ backgroundColor: "#666", color: "white" }}><embed className="icon" src="icons/exit.svg" alt="" /><span className="buttonLabel">Exit</span></button>
                    </div>
                </div>
            </div>
        );
    }
}

export default DefinitionCriteria;
