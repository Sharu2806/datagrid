import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, render, mount } from 'enzyme';
import 'isomorphic-fetch';
import {BasicInformation} from '../BasicInformation';

import data from '../../../../public/json/basicInfoRecord.json';

let basicInfo = null;
let applicantName = null;
let applicantAddress = null;
let applicantAddress1 = null;
let applicantAddress2 = null;
let beneficiaryNameSearch = null;
let address = null;
let address1 = null;
let address2 = null;
let country = null;
let customerReference = null;
let expiryDate = null;
let dateofIssue = null;
let dateofApplication = null;
let gteCurrency = null;
let gteAmount = null;

beforeAll(() => {
    basicInfo = shallow(<BasicInformation/>); 
    applicantName = basicInfo.find('input[name="applicantName"]');   
    applicantAddress = basicInfo.find('input[name="applicantAddress"]');  
    applicantAddress1 = basicInfo.find('input[name="applicantAddress1"]');
    applicantAddress2 = basicInfo.find('input[name="applicantAddress2"]');  
    beneficiaryNameSearch = basicInfo.find('input[name="beneficiaryNameSearch"]');
    address = basicInfo.find('input[name="address"]');
    address1 = basicInfo.find('input[name="address1"]');
    address2 = basicInfo.find('input[name="address2"]');
    country = basicInfo.find('input[name="country"]');
    customerReference = basicInfo.find('input[name="customerReference"]');
    expiryDate = basicInfo.find('input[name="expiryDate"]');
    dateofIssue = basicInfo.find('input[name="dateofIssue"]');
    dateofApplication = basicInfo.find('input[name="dateofApplication"]');
    gteCurrency = basicInfo.find('input[name="gteCurrency"]');
    gteAmount = basicInfo.find('input[name="gteAmount"]');
});

describe('BasicInformation', () => {
    it('renders without crashing', () => {
        expect(basicInfo.find('form').length).toBe(1);
    });

    describe('Applicant Name', () => {
        it('should render once', () => {
            expect(applicantName.length).toBe(1);
        });
        it('Applicant Name is present', () => {
            expect(basicInfo.contains('Applicant Name')).toEqual(true);
        });
        it('should have validation attributes set', () => {
            expect(applicantName.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            applicantName.simulate('blur',{target:{...applicantName.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="applicantName"]').prop('errors').length).toBe(1);
            expect( basicInfo.find('ErrorDisplay[fieldName="applicantName"]').prop('errors')[0]['error']).toBe("Applicant Name is required");
        });
    });

    describe('Applicant Address', () => {
        it('should render once', () => {
            expect(applicantAddress.length).toBe(1);
        });
        it('Applicant Address is present', () => {
            expect(basicInfo.contains('Applicant Address')).toEqual(true);
        });
        it('should have validation attributes set', () => {
            expect(applicantAddress.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            applicantAddress.simulate('blur',{target:{...applicantAddress.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="applicantAddress"]').prop('errors').length).toBe(2);
            expect( basicInfo.find('ErrorDisplay[fieldName="applicantAddress"]').prop('errors')[1]['error']).toBe("Applicant Address is required");
        });
    });

    describe('Applicant Address 1', () => {
        it('should render once', () => {
            expect(applicantAddress1.length).toBe(1);
        });
        xit('should have validation attributes set', () => {
            expect(applicantAddress1.prop('required')).toBe(true);
        });
        xit('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            applicantAddress1.simulate('blur',{target:{...applicantAddress1.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="applicantAddress1"]').prop('errors').length).toBe(0);
        });
    });

    describe('Applicant Address 2', () => {
        it('should render once', () => {
            expect(applicantAddress2.length).toBe(1);
        });
        xit('should have validation attributes set', () => {
            expect(applicantAddress2.prop('required')).toBe(true);
        });
        xit('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            applicantAddress2.simulate('blur',{target:{...applicantAddress2.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="applicantAddress2"]').prop('errors').length).toBe(0);
        });
    });

    describe('beneficiaryNameSearch', () => {
        it('should render once', () => {
            expect(beneficiaryNameSearch.length).toBe(1);
        });
        it('Beneficiary Name is present', () => {
            expect(basicInfo.contains('Beneficiary Name')).toEqual(true);
        });
        xit('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            beneficiaryNameSearch.simulate('blur',{target:{...beneficiaryNameSearch.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="beneficiaryNameSearch"]').prop('errors').length).toBe(0);
        });
    });

    describe('Address', () => {
        it('should render once', () => {
            expect(address.length).toBe(1);
        });
        it('Address is present', () => {
            expect(basicInfo.contains('Address')).toEqual(true);
        });
        it('should have validation attributes set', () => {
            expect(address.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            address.simulate('blur',{target:{...address.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="address"]').prop('errors').length).toBe(3);
            expect( basicInfo.find('ErrorDisplay[fieldName="applicantAddress"]').prop('errors')[2]['error']).toBe("Address is required");
        });
    });

    describe('Address 1', () => {
        it('should render once', () => {
            expect(address1.length).toBe(1);
        });
        xit('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            address1.simulate('blur',{target:{...address1.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="address1"]').prop('errors').length).toBe(0);
        });
    });

    describe('Address 2', () => {
        it('should render once', () => {
            expect(address2.length).toBe(1);
        });
        xit('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            address2.simulate('blur',{target:{...address2.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="address2"]').prop('errors').length).toBe(0);
        });
    });

     describe('Country', () => {
        it('should render once', () => {
            expect(country.length).toBe(0);
        });
        it('Country is present', () => {
            expect(basicInfo.contains('Country')).toEqual(true);
        });
     });

     describe('customer Reference', () => {
        it('should render once', () => {
            expect(customerReference.length).toBe(1);
        });
        it('Customer Reference is present', () => {
            expect(basicInfo.contains('Customer Reference')).toEqual(true);
        });
        xit('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            customerReference.simulate('blur',{target:{...customerReference.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="customerReference"]').prop('errors').length).toBe(0);
        });
    });

    describe('Expiry Date', () => {
        it('should render once', () => {
            expect(expiryDate.length).toBe(0);
        });
        it('Expiry Date  is present', () => {
            expect(basicInfo.contains('Expiry Date')).toEqual(true);
        });
        // it('should have validation attributes set', () => {
        //     expect(expiryDate.prop('required')).toBe(true);
        // });
        // it('should show error if no value is entered', () => {
        //     basicInfo.instance().saveError(data);
        //     expiryDate.simulate('blur',{target:{...expiryDate.props()}, type: 'blur', preventDefault: () => {} });
        //     expect( basicInfo.find('ErrorDisplay[fieldName="expiryDate"]').prop('errors').length).toBe(4);
        //     expect( basicInfo.find('ErrorDisplay[fieldName="expiryDate"]').prop('errors')[4]['error']).toBe("Expiry Date is required");
        // });
    });

    describe('Date Of Issue', () => {
        it('should render once', () => {
            expect(dateofIssue.length).toBe(0);
        });
        it('Date Of Issue is present', () => {
            expect(basicInfo.contains('Date Of Issue')).toEqual(true);
        });
        // it('should have validation attributes set', () => {
        //     expect(dateofIssue.prop('required')).toBe(true);
        // });
        // it('should show error if no value is entered', () => {
        //     basicInfo.instance().saveError(data);
        //     dateofIssue.simulate('blur',{target:{...dateofIssue.props()}, type: 'blur', preventDefault: () => {} });
        //     expect( basicInfo.find('ErrorDisplay[fieldName="dateofIssue"]').prop('errors').length).toBe(4);
        //     expect( basicInfo.find('ErrorDisplay[fieldName="dateofIssue"]').prop('errors')[4]['error']).toBe("Expiry Date is required");
        // });
    });

    describe('Date of Application', () => {
        it('should render once', () => {
            expect(dateofApplication.length).toBe(0);
        });
        it('Date of Application is present', () => {
            expect(basicInfo.contains('Date of Application')).toEqual(true);
        });
        // it('should have validation attributes set', () => {
        //     expect(dateofApplication.prop('required')).toBe(true);
        // });
        // it('should show error if no value is entered', () => {
        //     basicInfo.instance().saveError(data);
        //     dateofApplication.simulate('blur',{target:{...dateofApplication.props()}, type: 'blur', preventDefault: () => {} });
        //     expect( basicInfo.find('ErrorDisplay[fieldName="dateofApplication"]').prop('errors').length).toBe(4);
        //     expect( basicInfo.find('ErrorDisplay[fieldName="dateofApplication"]').prop('errors')[4]['error']).toBe("Expiry Date is required");
        // });
    });

    describe('Guarantee Currency', () => {
        it('should render once', () => {
            expect(gteCurrency.length).toBe(0);
        });
        it('Guarantee Currency is present', () => {
            expect(basicInfo.contains('Guarantee Currency')).toEqual(true);
        });
        // it('should have validation attributes set', () => {
        //     expect(gteCurrency.prop('required')).toBe(true);
        // });
        // it('should show error if no value is entered', () => {
        //     basicInfo.instance().saveError(data);
        //     gteCurrency.simulate('blur',{target:{...gteCurrency.props()}, type: 'blur', preventDefault: () => {} });
        //     expect( basicInfo.find('ErrorDisplay[fieldName="gteCurrency"]').prop('errors').length).toBe(5);
        //     expect( basicInfo.find('ErrorDisplay[fieldName="gteCurrency"]').prop('errors')[4]['error']).toBe("Currency is required");
        // });
    });

    describe('Guarantee Amount', () => {
        it('should render once', () => {
            expect(gteAmount.length).toBe(1);
        });
        it('Guarantee Amount is present', () => {
            expect(basicInfo.contains('Guarantee Amount')).toEqual(true);
        });
        it('should have validation attributes set', () => {
            expect(gteAmount.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            gteAmount.simulate('blur',{target:{...gteAmount.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="gteAmount"]').prop('errors').length).toBe(4);
            expect( basicInfo.find('ErrorDisplay[fieldName="gteAmount"]').prop('errors')[3]['error']).toBe("GTE Amount is required");
        });
    });

});

