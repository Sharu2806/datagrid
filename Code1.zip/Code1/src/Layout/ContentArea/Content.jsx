import React from 'react';
import {
    Route,
    Redirect,
    Switch
} from 'react-router-dom';

import Indexing from '../../Guarantee/Indexing/Indexing';
import RecordingDC from '../../Guarantee/Recording/RecordingDC';
import Recording from '../../Guarantee/Recording/Recording';
import IndexingImportBill from '../../ImportBill/Indexing/IndexingImportBill';
import RecordingImportBill from '../../ImportBill/Recording/RecordingImportBill';
import RecordingDcImportBill from '../../ImportBill/Recording/RecordingDcImportBill';

function Content(props) {
    return (
        <Switch>
            <Redirect exact from='/' to='/indexing' />
            <Route path='/indexing' component={() => <Indexing rightSideClass={props.rightSideClass} />} />
            <Route path='/recordingdc' component={(data) => <RecordingDC {...data} rightSideClass={props.rightSideClass} />} />
            <Route path='/recording' component={() => <Recording rightSideClass={props.rightSideClass} />} />
            <Route path='/importbill' component={IndexingImportBill} />
            <Route path='/importbillrecording' component={RecordingImportBill} />
            <Route path='/importbilldcrecording' component={RecordingDcImportBill} />
        </Switch>
    );
}
export default Content;
