import React, { Component } from 'react';

import Footer from './Footer/Footer';
import Header from './Header/Header';
import ContentArea from './ContentArea/ContentArea';

class Layout extends Component {

    constructor() {
        super();
        this.state = {

            // for class to be applied on --- left side menu and content on right, and header
            // these would change on header arrow click to widen/shorten the content area
            leftSideClass: "col-xs-12 col-sm-3 col-md-2 col-lg-2",
            rightSideClass: "col-xs-12 col-sm-9 col-md-10 col-lg-10",

            // this flag will tell whether header button is clicked or not , to display/hide
            // the content of left menu
            collapseFlag: false,
            data: '',
            recordingFlag: false
        };
        this.toggleClass = this.toggleClass.bind(this);
    }

    // this function is for making changes in the classes of left menu and content on right as well as in header
    // this function would be called from header.js when widen button is clicked
    // we are checking 
    toggleClass() {
        if (!this.state.collapseFlag) {
            this.setState({
                leftSideClass: 'col-xs-12 col-sm-1 col-md-1 col-lg-1',
                rightSideClass: 'col-xs-12 col-sm-11 col-md-11 col-lg-11',
                collapseFlag: !this.state.collapseFlag
            });
        }
        else {
            this.setState({
                leftSideClass: 'col-xs-12 col-sm-3 col-md-2 col-lg-2',
                rightSideClass: 'col-xs-12 col-sm-9 col-md-10 col-lg-10',
                collapseFlag: !this.state.collapseFlag
            });
        }
    }

    render() {
        return (
            <div id="layoutDiv" className="container-fluid" style={{ marginTop: '2px' }}>
                <Header {...this.state} parentToggleClass={this.toggleClass} ></Header>
                <ContentArea {...this.state} />
                <Footer></Footer>
            </div>
        );
    }
}

export default Layout;