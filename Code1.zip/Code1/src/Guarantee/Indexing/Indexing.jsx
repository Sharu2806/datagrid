import React, { Component } from 'react';
import { connect } from 'react-redux';

import RecordInformation from '../../SharedComponents/RecordInformation';
import ButtonLineControl from '../../SharedComponents/ButtonLineControl';
import BasicInformation from './BasicInformation/BasicInformation';
import CommonInformation from './CommonInformation/CommonInformation';
import IndexingInformation from './IndexingInformation/IndexingInformation';
import * as Utils from '../../common.js';

import * as ACTIONS from './IndexingActions';

class Indexing extends Component {

    constructor(props) {
        super(props);
        this.state = {
            updown: false
        }

        this.handleSaveClick = this.handleSaveClick.bind(this);
        this.handleTabClick = this.handleTabClick.bind(this);
        this.handleSubmitClick = this.handleSubmitClick.bind(this);
        this.currentActiveTab = 'basicInfo';

        this.buttonList = [
            { btnName: 'Save', btnClass: 'btn btn-green', btnClickEvent: this.handleSaveClick, btnIcon: 'save' },
            { btnName: 'Send', btnClass: 'btn btn-green',btnClickEvent: this.handleSubmitClick, btnIcon: 'send' },
            { btnName: 'Hold', btnClass: 'btn btn-grey', btnIcon: 'hold' },
            { btnName: 'Repair', btnClass: 'btn btn-grey', btnIcon: 'repair' },
            { btnName: 'Open Image', btnClass: 'btn btn-grey', btnIcon: 'open_image' },
            { btnName: 'Cancel', btnClass: 'btn btn-grey', btnIcon: 'cancel' },
            { btnName: 'Assign', btnClass: 'btn btn-grey', btnIcon: 'assign' },
            { btnName: 'Copy', btnClass: 'btn btn-grey', btnIcon: 'copy' },
            { btnName: 'AML Checking', btnClass: 'btn btn-grey', btnIcon: 'AML_Checking' },
            { btnName: 'Get Interaction', btnClass: 'btn btn-grey', btnIcon: 'AML_Checking' }
        ]
    }

    componentWillMount() {
        this.props.fetchIndexingData();
    }

    componentDidMount() {
    }

    componentWillUnmount() {
    }

    handleSaveClick() {
        Utils.handleSaveClick(this, "indexingTabs");
    }

    handleTabClick(event) {
        Utils.handleTabClick(event, this);
    }

    handleSubmitClick() {
        this[this.currentActiveTab].saveData();

        var commonInfoObj = this['commonInfo'];
        var indexingInfoObj = this['indexingInfo'];

        var errorsObj1 = commonInfoObj.state.errors;
        var errorsObj2 = indexingInfoObj.state.errors;

        if (
            errorsObj1.length === 0 &&
            errorsObj2.length === 0) {
            setTimeout(() => {
                let obj = this.props.allIndexingData;
                Utils.deleteErrors(obj);
                // console.log(JSON.stringify(obj));
                this.props.sendData(obj);
            }, 2000);
        } else {
            console.log("Please correct errors");
        }
    }

    changeUpDown() {
        this.setState({
            updown: !this.state.updown
        })
    }

    getWidthById(value) {
        return document.getElementById(value).offsetWidth;
    }

    render() {
        return (
            <div className="row">
                <div className="panel panel-holding-tabs">
                    {/*The following code will be used to display some info regarding the current record*/}
                    {
                        this.props.allIndexingData &&
                        <RecordInformation
                            gwisId={this.props.allIndexingData.basicInformation.gwisId}
                            processingType={this.props.allIndexingData.commonInformation.processingType}
                            targetDate={this.props.allIndexingData.commonInformation.targetDate}
                        />
                    }

                    <ul id="indexingTabs" className="nav nav-tabs" onClick={this.handleTabClick} style={{ overflow: 'hidden', position: 'relative', top: '1px' }}>
                        <li className="active"><a data-toggle="tab" href="#basicInfo">Basic Info.</a></li>
                        <li><a data-toggle="tab" href="#commonInfo">Common Info.</a></li>
                        <li><a data-toggle="tab" href="#indexingInfo">Indexing Info.</a></li>
                    </ul>
                </div>
                <div className="tab-content" style={{ marginLeft: '30px', marginRight: '30px', marginBottom: '180px' }}>
                    <div id="basicInfo" className="tab-pane fade in active">
                        {
                            this.props.allIndexingData &&
                            <BasicInformation
                                inputData={this.props.allIndexingData.basicInformation}
                                saveBasicInformationData={this.props.saveBasicInformationData}
                                onRef={ref => (this.basicInfo = ref)}
                            />
                        }
                    </div>
                    <div id="commonInfo" className="tab-pane fade">
                        {
                            this.props.allIndexingData &&
                            <CommonInformation
                                inputData={this.props.allIndexingData.commonInformation}
                                saveCommonInformationData={this.props.saveCommonInformationData}
                                onRef={ref => (this.commonInfo = ref)}
                            />
                        }
                    </div>
                    <div id="indexingInfo" className="tab-pane fade">
                        {
                            this.props.allIndexingData &&
                            <IndexingInformation
                                inputData={this.props.allIndexingData.indexingInformation}
                                saveIndexingInformationData={this.props.saveIndexingInformationData}
                                onRef={ref => (this.indexingInfo = ref)}
                                gwisId={this.props.allIndexingData.basicInformation.gwisId}
                            />
                        }
                    </div>
                </div>
                <div
                    className={this.props.rightSideClass + " pull-right navbar-fixed-bottom bottom-buttons-layout"}
                    id="indexing-bottom-button-layout"
                >
                    <ButtonLineControl buttonList={this.buttonList} id="indexing-bottom-button-layout"/>
                </div>
            </div>
        );
    }
}

const mapsStateToProps = (state) => {
    // console.log("State " + JSON.stringify(state.indexingReducer));
    return {
        allIndexingData: state.indexingReducer
    };
};

const mapsDispatchToProps = (dispatch) => {
    return {
        fetchIndexingData: () => {
            dispatch(ACTIONS.fetchIndexingData());
        },
        saveBasicInformationData: (obj) => {
            dispatch(ACTIONS.saveBasicInformationData(obj));
        },
        saveCommonInformationData: (obj) => {
            dispatch(ACTIONS.saveCommonInformationData(obj));
        },
        saveIndexingInformationData: (obj) => {
            dispatch(ACTIONS.saveIndexingInformationData(obj));
        },
        sendData: (obj) => {
            dispatch(ACTIONS.sendData(obj));
        }, getCustomerName: (acntNum) => {
            console.log("Data :: ", acntNum);
            dispatch(ACTIONS.getCustomerName(acntNum));
        }
    };
};

export default connect(mapsStateToProps, mapsDispatchToProps)(Indexing);
