import {indexingReducers} from '../IndexingReducers';
import * as ActionTypes from '../../../ImportBill/Indexing/IndexingImportBillActions'


test('should return the initial state', () => {
  expect(indexingReducers(undefined, {})).toEqual([
    {
      text: 'intitialState',
      completed: false
    }
  ])
});

test('# indexingReducer - fetch indexing data', () => {
  const testState = {};
  const action = { type: ActionTypes.FETCH_INDEXING_DATA };
  const res = indexingReducers(testState, action);
  expect(
    res).toEqual({
                ...action.payload
            }
    );
});

test('# indexingReducer - save basic information data', () => {
  const testState = {};
  const action = { type: ActionTypes.SAVE_BASIC_INFORMATION_DATA };
  const res = indexingReducers(testState, action);
  expect(
    res).toEqual({
                    ...action.payload
                }
                );               
});

test('# indexingReducer - save common information data', () => {
  const testState = {};
  const action = { type: ActionTypes.SAVE_COMMON_INFORMATION_DATA };
  const res = indexingReducers(testState, action);
  expect(
    res).toEqual(
      {
                    ...action.payload
        });
});

test('# indexingReducer - save indexing information data', () => {
  const testState = {};
  const action = { type: ActionTypes.SAVE_INDEXING_INFORMATION_DATA };
  const res = indexingReducers(testState, action);
  
  expect(
    res).toEqual({
                    ...action.payload
      });
});

test('# indexingReducer - send data', () => {
  const testState = {};
  const action = { type: ActionTypes.SEND_DATA };
  const res = indexingReducers(testState, action);
  
  expect(
    res).toEqual({
      
    });
});

test('# indexingReducer - get Customer name', () => {
  const testState = {};
  const action = { type: ActionTypes.GET_CUST_NAME };
  const res = indexingReducers(testState, action);
  expect(
    res).toEqual({
          customerName: action.payload,
        }
      );
});
