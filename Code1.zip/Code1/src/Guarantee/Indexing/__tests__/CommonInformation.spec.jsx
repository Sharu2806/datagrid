import CommonInformation from '../CommonInformation/CommonInformation.jsx';
import { SubmissionError } from 'redux-form'
import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, render, mount } from 'enzyme';
import 'isomorphic-fetch';

import data from '../../../../public/json/commonInformationRecord.json';
//import data from '../../../public/json/basicInfoRecord.json';

let commonInfo = null;
let priority = null;
//let branchCode = null;
let targetDate = null;
let processingType = null;
let custSegmnt = null;
let lob = null;
let supplementary = null;
let processingSite = null;
let attachToAppReference = null;

beforeAll(() => {
    commonInfo = shallow(<CommonInformation />);
    //priority = commonInfo.find('input[id="priority"]');
    // branchCode = commonInfo.find('input[name="branchCode"]');
    targetDate = commonInfo.find('input[name="targetDate"]');
    processingType = commonInfo.find('input[name="processingType"]');
    custSegmnt = commonInfo.find('input[name="custSegmnt"]');
    lob = commonInfo.find('input[name="lob"]');
    supplementary = commonInfo.find('input[name="supplementary"]');
    processingSite = commonInfo.find('input[name="processingSite"]');
    attachToAppReference = commonInfo.find('input[name="attachToAppReference"]');
    //Console.log(commonInfo);
});

describe('CommonInformation', () => {
    it('renders without crashing', () => {
        expect(commonInfo.find('form').length).toBe(1);
    });

    xit('page header should be - Common Information', () => {
        const header = <span className="Muli-Bold" style={{ fontSize: '16px' }}>Common Info.</span>;
        expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - In Channel', () => {
        const label = <span className="label-margin-below">In Channel</span>;
        expect(commonInfo.contains(label)).toEqual(true);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - Channel In Date Time', () => {
        const label = <span className="label-margin-below">Channel In Date Time</span>;
        expect(commonInfo.contains(label)).toEqual(true);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - Scan/Fax Batch Reference', () => {
        const label = <span className="label-margin-below">Scan/Fax Batch Reference</span>;
        expect(commonInfo.contains(label)).toEqual(true);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - Branch Code', () => {
        const label = <span className="label-margin-below">Branch Code</span>;
        expect(commonInfo.contains(label)).toEqual(true);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - Target Completion Date Time', () => {
        const label = <span className="label-margin-below">Target Completion Date Time</span>;
        expect(commonInfo.contains(label)).toEqual(false);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - Priority', () => {
        const label = <span className="label-margin-below">Priority</span>;
        expect(commonInfo.contains(label)).toEqual(false);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - Customer Segmentation', () => {
        const label = <span className="label-margin-below">Customer Segmentation</span>;
        expect(commonInfo.contains(label)).toEqual(false);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - LOB', () => {
        const label = <span className="label-margin-below">LOB</span>;
        expect(commonInfo.contains(label)).toEqual(false);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - Portfolio Code', () => {
        const label = <span className="label-margin-below">Portfolio Code</span>;
        expect(commonInfo.contains(label)).toEqual(true);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - Processing Site', () => {
        const label = <span className="label-margin-below">Processing Site</span>;
        expect(commonInfo.contains(label)).toEqual(false);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - Starting Page no for customer view', () => {
        const label = <span className="label-margin-below">Starting Page no for customer view</span>;
        expect(commonInfo.contains(label)).toEqual(true);
        //expect(commonInfo.contains(header)).toEqual(true);
    });
    it('Common Information Tab - Supplementary', () => {
        const label = <span className="label-margin-below">Supplementary</span>;
        expect(commonInfo.contains(label)).toEqual(true);
        //expect(commonInfo.contains(header)).toEqual(true);
    });



    describe('priority', () => {
        xit('should have validation attributes set', () => {
            const propsdfg = <select className="form-control selectCss" name="priority" id="priority"></select>;
            expect(commonInfo.contains(propsdfg)).toEqual(false);
        });
        xit('should have validation attributes set', () => {
            const propsdfg = <select className="form-control selectCss" name="priority" id="priority"></select>;
            expect(propsdfg.prop('required')).toBe(true);
        });
        //const expected = ['Critical (>=75, <=99)',];
        xit('should have validation attributes set', () => {
            //expect(priority.contains('Critical (>=75, <=99)')).toBe(false);
            //expect(['Critical (>=75, <=99)']).toEqual(expect.any(expected));
        });
        xit('should show error if no value is entered', () => {
            const priority = <select className="form-control selectCss" name="priority" id="priority"></select>;
            commonInfo.instance().saveError(data);
            priority.simulate('blur', { target: { ...priority.props() }, type: 'blur', preventDefault: () => { } });
            expect(commonInfo.find('ErrorDisplay[fieldName="priority"]').prop('errors').length).toBe(1);
            expect(commonInfo.find('ErrorDisplay[fieldName="priority"]').prop('errors')[0]['error']).toBe("priority is required");
        });

    });


    describe('targetDate', () => {
        it('should render once', () => {
            expect(targetDate.length).toBe(0);
        });
        xit('should have validation attributes set', () => {
            expect(targetDate.prop('required')).toBe(false);
        });
        xit('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            targetDate.simulate('blur', { target: { ...targetDate.props() }, type: 'blur', preventDefault: () => { } });
            expect(commonInfo.find('ErrorDisplay[fieldName="targetDate"]').prop('errors').length).toBe(0);
        });
    });

    describe('processingType', () => {
        it('should render once', () => {
            expect(processingType.length).toBe(0);
        });

        xit('should have validation attributes set', () => {
            expect(processingType.prop('required')).toBe(true);
        });
        xit('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            processingType.simulate('blur', { target: { ...processingType.props() }, type: 'blur', preventDefault: () => { } });
            expect(commonInfo.find('ErrorDisplay[fieldName="processingType"]').prop('errors').length).toBe(0);
        });
    });
    describe('custSegmnt', () => {
        it('should render once', () => {
            expect(custSegmnt.length).toBe(2);
        });

        xit('should have validation attributes set', () => {
            expect(custSegmnt.prop('required')).toBe(false);
        });
        xit('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            custSegmnt.simulate('blur', { target: { ...custSegmnt.props() }, type: 'blur', preventDefault: () => { } });
            expect(commonInfo.find('ErrorDisplay[fieldName="custSegmnt"]').prop('errors').length).toBe(0);
        });
    });
    describe('lob', () => {
        it('should render once', () => {
            expect(lob.length).toBe(0);
        });

        xit('should have validation attributes set', () => {
            expect(lob.prop('required')).toBe(true);
        });
        xit('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            lob.simulate('blur', { target: { ...lob.props() }, type: 'blur', preventDefault: () => { } });
            expect(commonInfo.find('ErrorDisplay[fieldName="lob"]').prop('errors').length).toBe(0);
        });
    });
    describe('supplementary', () => {
        it('should render once', () => {
            expect(supplementary.length).toBe(2);
        });

        xit('should have validation attributes set', () => {
            expect(supplementary.prop('required')).toBe(true);
        });
        xit('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            supplementary.simulate('blur', { target: { ...supplementary.props() }, type: 'blur', preventDefault: () => { } });
            expect(commonInfo.find('ErrorDisplay[fieldName="supplementary"]').prop('errors').length).toBe(0);
        });
    });
    describe('processingSite', () => {
        it('should render once', () => {
            expect(processingSite.length).toBe(0);
        });

        xit('should have validation attributes set', () => {
            expect(processingSite.prop('required')).toBe(true);
        });
        xit('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            processingSite.simulate('blur', { target: { ...processingSite.props() }, type: 'blur', preventDefault: () => { } });
            expect(commonInfo.find('ErrorDisplay[fieldName="processingSite"]').prop('errors').length).toBe(0);
        });
    });
    describe('attachToAppReference', () => {
        it('should render once', () => {
            expect(attachToAppReference.length).toBe(0);
        });

        xit('should have validation attributes set', () => {
            expect(attachToAppReference.prop('required')).toBe(true);
        });
        xit('should show error if no value is entered', () => {
            commonInfo.instance().saveError(data);
            attachToAppReference.simulate('blur', { target: { ...attachToAppReference.props() }, type: 'blur', preventDefault: () => { } });
            expect(commonInfo.find('ErrorDisplay[fieldName="attachToAppReference"]').prop('errors').length).toBe(0);
        });
    });
});