import BasicInformation from '../BasicInformation/BasicInformation';
import { SubmissionError } from 'redux-form'
import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, render, mount } from 'enzyme';
import 'isomorphic-fetch';

import data from '../../../../public/json/basicInformationRecord.json';

let basicInfo = null;
let gwisId = null;
let status = null;
let createdUser = null;
let createdTime = null;
let lastModifiedUser = null;
let lastModifiedTime = null;
let workStep = null;
let nextWorkStep = null;  
            
beforeAll(() => {
    basicInfo = shallow(<BasicInformation/>);    
    gwisId = basicInfo.find('input[name="gwisId"]');
    status = basicInfo.find('input[name="status"]');
	createdUser = basicInfo.find('input[name="createdUser"]');
	createdTime = basicInfo.find('input[name="createdTime"]');
	lastModifiedUser = basicInfo.find('input[name="lastModifiedUser"]');
	lastModifiedTime = basicInfo.find('input[name="lastModifiedTime"]');
	workStep = basicInfo.find('input[name="workStep"]');
    nextWorkStep = basicInfo.find('input[name="nextWorkStrp"]');            
});

describe('BasicInformation', () => {
    it('renders without crashing', () => {
        expect(basicInfo.find('form').length).toBe(1);
    });

    it('page header should be - Basic Information', () => {
        const header = <span className="Muli-Bold" style={{ fontSize: '16px' }}>Basic Information</span>;
        expect(basicInfo.contains(header)).toEqual(false);
    });

    describe('gwisId', () => {
        it('should render once', () => {
            expect(gwisId.length).toBe(1);
        });
        it('GWIS ID is present', () => {
            expect(basicInfo.contains('GWIS ID')).toEqual(true);
        });
        xit('should have validation attributes set', () => {
            expect(gwisId.prop('required')).toBe(true);
        });
    });

    describe('status', () => {
        it('should render once', () => {
            expect(status.length).toBe(1);
        });
        it('Status is present', () => {
            expect(basicInfo.contains('Status')).toEqual(true);
        });
        xit('should have validation attributes set', () => {
            expect(status.prop('required')).toBe(true);
        });
    });

    describe('createdUser', () => {
        it('should render once', () => {
            expect(createdUser.length).toBe(1);
        });
        it('Created User is present', () => {
            expect(basicInfo.contains('Created User')).toEqual(true);
        });
        xit('should have validation attributes set', () => {
            expect(createdUser.prop('required')).toBe(true);
        });
    });

     describe('createdTime', () => {
        it('should render once', () => {
            expect(createdTime.length).toBe(1);
        });
        it('Created Time is present', () => {
            expect(basicInfo.contains('Created Time')).toEqual(true);
        });
        xit('should have validation attributes set', () => {
            expect(createdTime.prop('required')).toBe(true);
        });
    });


    describe('lastModifiedUser', () => {
        it('should render once', () => {
            expect(lastModifiedUser.length).toBe(1);
        });
         it('Last Modified User is present', () => {
            expect(basicInfo.contains('Last Modified User')).toEqual(true);
        });
        xit('should have validation attributes set', () => {
            expect(lastModifiedUser.prop('required')).toBe(true);
        });
    });

    describe('lastModifiedTime', () => {
        it('should render once', () => {
            expect(lastModifiedTime.length).toBe(1);
        });
         it('Last Modified Time is present', () => {
            expect(basicInfo.contains('Last Modified Time')).toEqual(true);
        });
        xit('should have validation attributes set', () => {
            expect(lastModifiedTime.prop('required')).toBe(true);
        });
    });

    describe('currentWorkStep', () => {
        it('should render once', () => {
            expect(workStep.length).toBe(1);
        });
        it('Current Work Step is present', () => {
            expect(basicInfo.contains('Current Work Step')).toEqual(true);
        });
        xit('should have validation attributes set', () => {
            expect(workStep.prop('required')).toBe(true);
        });
     });  

     describe('nextWorkStep', () => {
         var nextWorkStepValues = ['Document Attached', 'Recording', 'Document Management Pre Work', 'Auto Indexing']
        it('should render once', () => {
            expect(nextWorkStep.contains(nextWorkStepValues)).toBe(false);
        });
        it('Next Work Step is present', () => {
            expect(basicInfo.contains('Next Work Step')).toEqual(true);
        });
        xit('should have validation attributes set', () => {
            expect(nextWorkStep.prop('required')).toBe(true);
        });
     });  
});