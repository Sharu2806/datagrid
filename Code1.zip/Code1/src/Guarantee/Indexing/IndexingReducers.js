import * as ACTION_TYPES from '../GuaranteeActionTypes';

export const initialState =    [
    {
      text: 'intitialState',
      completed: false
    }
  ]

// export const indexingReducers = (state=initialState, action) => {
export default (state=null, action) => {
    switch (action.type) {
        case ACTION_TYPES.GTE_INDEXING_FETCH_INDEXING_DATA:
            // console.log("FETCH_INDEXING_DATA reducer :: ",...action.payload);
            state = {
                ...action.payload
            };
            break;
        case ACTION_TYPES.GTE_INDEXING_SAVE_BASIC_INFORMATION_DATA:
            // console.log("saveData BASIC reducer");
            state = {
                ...state,
                basicInformation: {
                    ...action.payload
                }
            };
            break;
        case ACTION_TYPES.GTE_INDEXING_SAVE_COMMON_INFORMATION_DATA:
            // console.log("SAVE COMMON DATA reducer", action.payload);
            state = {
                ...state,
                commonInformation: {
                    ...action.payload
                }
            };
            break;
        case ACTION_TYPES.GTE_INDEXING_SAVE_INDEXING_INFORMATION_DATA:
            // console.log("SAVE INDEXING DATA reducer", action.payload);
            state = {
                ...state,
                indexingInformation: {
                    ...action.payload
                }
            };
            break;
        case "SEND_DATA":
            // console.log("Sending data in reducer ", action.payload);
            alert("Data Sent Successfully");
            break;
        case ACTION_TYPES.GTE_INDEXING_GET_CUST_NAME:
            // console.log("Get Cust Name in reducer ", action.payload);
            state = {
                ...state,
                indexingInformation: {
                    customerName: action.payload,
                }
            };
            break;
        default:
    }
    return state;
}