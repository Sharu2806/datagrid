import React from 'react';
import LevelTabs from "./CustomLevelTabs";
import {connect} from "react-redux";

import * as Actions from "./Actions/wolfAction"


var jsonData = require("./demodata.json");
var jsonSelect = require("./wolfError.json");
class WOLFHitDetails extends React.Component {

    constructor(props) {
        super(props);

        this.sendData = this.sendData.bind(this);
        this.changeClass = this.changeClass.bind(this);
        this.state = {
            Wolfdata: jsonData,
            duplicateIndex: [],
        }
    }

    componentDidMount() {
        this.props.onRef(this);
       this.sendData();

    }

     saveData(){
        this.saveWithoutDuplicate(this.state.Wolfdata,this.state.duplicateIndex);
        alert("Data Saved Successfully")
    }

    saveAndSendData(){
        var flag=true;
        var flag1=true;
        var message = this.checkForMessage("send")

        for(var i=0;i<this.state.Wolfdata.length;i++){
            if(!this["tabData"+(i+1)].validateForRationale()){
                flag=false;  
                break;
            }
        }
        if(flag){
            for(var i=0;i<this.state.Wolfdata.length;i++){
                if(!this["tabData"+(i+1)].checkforTextArea()){
                    flag1=false
                    break 
                } 
            }
            if(flag1){
                this.saveWithoutDuplicate(this.state.Wolfdata,this.state.duplicateIndex);
                alert("Data Saved Successfully")
            }
            else{
                message.commentMessage != "" ? alert(message.commentMessage) : null
            }
        }
        else{
            message.rationalMessage != "" ? alert(message.rationalMessage) : null  
        }
        if((this.props.user+1)%3 == 0 ){
            this.props.dispatch(Actions.sendToNextQueue(3));
            this.props.dispatch(Actions.changeActiveClass())
        }
        else{
            this.props.dispatch(Actions.sendToNextQueue((this.props.user+1)%3));
            this.props.dispatch(Actions.changeActiveClass())
        }
    }

    checkForMessage(button){
        var rationalMessage = "";
        var commentMessage ="";
        var referMessage="";

        if (this.props.user == 1){
            if(jsonSelect[0][button].recording==="Y")
                rationalMessage = jsonSelect[0][button].message
            if(jsonSelect[1][button].recording==="Y")
                commentMessage = jsonSelect[1][button].message
            if(jsonSelect[2][button].recording==="Y")
                referMessage = jsonSelect[2][button].message
        }
        else if (this.props.user == 2) {
            if(jsonSelect[0][button].approval==="Y")
                rationalMessage = jsonSelect[0][button].message
            if(jsonSelect[1][button].approval==="Y")
                commentMessage = jsonSelect[1][button].message
            if(jsonSelect[2][button].approval==="Y")
                referMessage = jsonSelect[2][button].message
        }
        else if (this.props.user == 3) {
            if(jsonSelect[0][button].WolfException==="Y")
                rationalMessage = jsonSelect[0][button].message
            if(jsonSelect[1][button].WolfException==="Y")
                commentMessage = jsonSelect[1][button].message
            if(jsonSelect[2][button].WolfException==="Y")
                referMessage = jsonSelect[2][button].message
        }
        return {
            rationalMessage : rationalMessage,
            commentMessage : commentMessage,
            referMessage : referMessage
        }
    }

    assignData(){
        var flag=true
        var flag1=true;
        var flagcount=0;
        
        var message = this.checkForMessage("assign")

        for(var i=0;i<this.state.Wolfdata.length;i++){
            if(!this["tabData"+(i+1)].validateForRationale()){
                flag=false;  
                break;
            }
            else{
                flagcount=1;
            }
        }
        if(flag || flagcount==0){
            for(var i=0;i<this.state.Wolfdata.length;i++){
                if(!this["tabData"+(i+1)].checkforTextArea()){
                    flag1=false
                    break 
                } 
            }
            if(flag1){
                this.saveWithoutDuplicate(this.state.Wolfdata,this.state.duplicateIndex);
                alert("Data Assigned Successfully")
            }
            else{
                message.commentMessage != "" ? alert(message.commentMessage) : null
            }
        }
        else{
            message.rationalMessage != "" ? alert(message.rationalMessage) : null  
        }

        if(this.props.user==1){
            this.props.dispatch(Actions.sendToNextQueue(3))
            this.props.dispatch(Actions.changeActiveClassException())
        }
    }

  saveWithoutDuplicate(data,ind){
        var result = [];
        var dummy=[];
        var dupLength=ind.length;
        for(var i=0;i<data.length;i++){
            if(i<dupLength){
                if(ind[i]==0){
                     result.push(this["tabData"+(i+1)].getDetails())
                     dummy.push(data[i])
                }
            }
            else{
            result.push(this["tabData"+(i+1)].getDetails())
            dummy.push(data[i])
            }
        }
        console.log(JSON.stringify(result))
        this.setState({
            Wolfdata:dummy,
            duplicateIndex:[]
        })
    } 


    changeClass(number) {

        var element = document.getElementById("icon" + number)
        var element2 = document.getElementsByClassName("more-less")

        if (element.className.toString().indexOf("up") > -1) {
            element.className = "more-less glyphicon glyphicon-chevron-down"
        }
        else if (element.className.toString().indexOf("down") > -1) {
            element.className = "more-less glyphicon glyphicon-chevron-up"
        }

        for (var i = 0; i < element2.length; i++) {
            if (element2[i].id != element.id)
                element2[i].className = "more-less glyphicon glyphicon-chevron-down"
        }
    }

    sendData() {

        var tabData = [{
            "fieldName": "DRAWER NAME AND ADDRESS",
            "fieldData": "CUBA IRAN",
            "worldCheckId": "00063254",
            "name": "*",
            "country": "SUDAN",
            "origin": "HBUS",
            "designation": "OFAC GREY",
            "type": "OTHER",
            "captureTime": "11 Jun 2017 10:10",
            "additionalInfo": {
                "nameSynonyms": ["SOUDAN"],
                "addtInfo": "74 main cities:ABU HAMAD,ANDIMESHK,ARAK,...."
            }
        }, {
            "fieldName": "DRAWER NAME AND ADDRESS",
            "fieldData": "CUBA IRAN",
            "worldCheckId": "00063254",
            "name": "*",
            "country": "SUDAN",
            "origin": "HBUS",
            "designation": "OFAC GREppY",
            "type": "OTHER",
            "captureTime": "11 Jun 2017 10:10",
            "additionalInfo": {
                "nameSynonyms": ["SOUDAN"],
                "addtInfo": "87 main cities:ABU HAMAD,ANDIMESHK,ARAK,...."
            }
        },
        {
            "fieldName": "DRAWER NAME AND ADDRESS",
            "fieldData": "CUBA IRAN",
            "worldCheckId": "00063254",
            "name": "*",
            "country": "SUDAN",
            "origin": "HBUS",
            "designation": "OFAC GREY",
            "type": "OTHER",
            "captureTime": "11 Jun 2017 10:10",
            "additionalInfo": {
                "nameSynonyms": ["SOUDAN"],
                "addtInfo": "87 main cities:ABU HAMAD,ANDIMESHK,ARAK,...."
            }
        }]
        var newJsonData = [];
        tabData.forEach((item)=>{
            newJsonData.push(item)
        })
        var length=tabData.length;
        var localDuplicateIndex = [];
        for(var i=0;i<length;i++){
            localDuplicateIndex.push(0);
        }
        var classThis = this;
        classThis.state.Wolfdata.forEach((item, index) => {
            newJsonData.push(item)
            tabData.forEach((item1,index1)=>{
            if (this.checkForDuplication(item1, ["country", "origin", "designation", "type"], item))
                localDuplicateIndex[index1]= 1
            })
        })
        console.log(localDuplicateIndex);
        this.setState({
            duplicateIndex: localDuplicateIndex,
            Wolfdata: newJsonData
        })
    }

    checkForDuplication(data, values, checkData) {
        var count = 0;
        values.forEach((item) => {
            if (data[item] == checkData[item]) {
                count += 1;
            }
        })
        if (count == values.length) {
            return true;
        }
        return false;
    }

    render() {

        var flag = false;
        var length=this.state.duplicateIndex.length;

        if (this.state.duplicateIndex != -1)
            flag = true;

        var panels = [];
        var lastData = 0;
        this.state.Wolfdata.forEach((item, index) => {
            var panelid = "pcollapse" + index;
            var panelhref = "#" + panelid;
            panels.push(<div key={panelid+index} className="panel panel-default">
                <div className="panel-heading" role="tab">
                    <a style={{ textDecoration: "none", color: "inherit" }} data-toggle="collapse" data-parent="#accordion" href={panelhref} aria-expanded="true"
                        onClick={() => { this.changeClass(index + 1) }}>
                        <div className={"panel-title" + (index + 1)}>
                            HIT {index + 1} Details
                            <i id={"icon" + (index + 1)} className="more-less glyphicon glyphicon-chevron-down"></i>
                            <span style={{ float: "right", marginRight: "10px" }}>Capture Time - {item.captureTime}</span>
                        </div>
                    </a>
                </div>
                <div id={panelid} className="panel-collapse collapse" role="tabpanel" >
                    {index<length && this.state.duplicateIndex[index]==1 ? 
                    <LevelTabs tabdata={item} addId={index} key={index+item} check={true} onRef1 = { ref => (this["tabData"+(index+1)] = ref)}/>
                    :<LevelTabs tabdata={item} addId={index} key={index+item} check={false} onRef1 = { ref => (this["tabData"+(index+1)] = ref)}/> }
                    
                </div>
            </div>);
        })

        return (
            <div>
                <h4>WOLF Hit Detail Information</h4>
                <hr />
                <div className="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                            {panels}
                </div>
                <button className="btn btn-default" style={{background:"#333333",color:"white"}}>
                    <i className="glyphicon glyphicon-print"></i>
                <span className="buttonLabel" style={{top:"0"}}>Print Violations Details</span></button>
                
                <br/>
                <br/>
                 <h5 style={{fontWeight:"bold"}}>Status</h5>
                <hr style={{borderTopColor:"#333",marginTop:"2px",marginBottom:"2px"}}/>
                <input type="checkbox"/> Transaction has been referred to L3
                <br/>
                <input type="radio" defaultChecked name="wolfGroup"/><label
                                        style={{ marginLeft: "10px", fontFamily: "Muli", fontWeight: "bold" }}>
                                        Approved by L3
                                    </label>
                <input type="radio"style={{ marginLeft: "30px" }} name="wolfGroup"/><label
                                        style={{ marginLeft: "10px", fontFamily: "Muli", fontWeight: "bold" }}>Rejected by L3</label>
                <input type="radio" style={{ marginLeft: "30px" }} name="wolfGroup"/><label
                                        style={{ marginLeft: "10px", fontFamily: "Muli", fontWeight: "bold" }}>Customer withdraw</label>
                <input type="radio" style={{ marginLeft: "30px" }} name="wolfGroup"/><label
                                        style={{ marginLeft: "10px", fontFamily: "Muli", fontWeight: "bold" }}>Referred in error</label>
            </div>

        );
    }

}

function mapStateToProps(store){
    return {
        user : store.wolfReducer.user
    }
}

export default connect(mapStateToProps)(WOLFHitDetails);

 // jsonData.forEach((item)=>{
        //     var captureTimeSplit = item.captureTime.split(' ')
        //     var timeSplitted = captureTimeSplit[captureTimeSplit.length-1]
        //     captureTimeSplit.splice(captureTimeSplit.length-1,1)
        //     var captureTimeSplitted = timeSplitted.split(':')
        //     //console.log("Date : "+captureTimeSplit+" Time : "+captureTimeSplitted)
        // })
