import React from 'react';

var jsonSelect = require("./Rationale.json");
class CustomTabContent extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            comment : "",
            rationale : "",
            selectedIndex : 0,
        }
        this.addComment=this.addComment.bind(this);
        this.changerationale=this.changerationale.bind(this);
        this.checkforTextArea=this. checkforTextArea.bind(this);
    }

    componentDidMount(){
        this.props.onRef2(this);
    }

    getDetails(){
        var obj = this.state
        //if(this.checkforTextArea())
        // delete obj["selectedIndex"]
        return obj;
    }

    validateForRationale(){
        if(this.state.rationale==""){
            return false;
        }
        return true;
    }

    addComment(e){
    
        this.setState({comment : e.target.value})
    }
    changerationale(e) {
        if(this.props.user == 3 && this.props.status == "Y"){
            if(this.props.id.substring(6,7) == "2"){
                this.props.disableTab(3)
            }
            else if(this.props.id.substring(6,7) == "3"){
                this.props.disableTab(2)
            }
        }
        this.setState({
            rationale: e.target.value,
            selectedIndex: e.target.selectedIndex
        })
    }

    checkForComplete() {
        if (this.state.rationale === "" && this.state.comment === "")
            return false
        return true
    }
    
    checkforTextArea(){
        if(this.state.selectedIndex > 14 && this.state.comment==="")
        {
            //alert("Please provide the Comments")
            //document.getElementById("textArea"+this.state.selectedIndex).focus()
            return false
        }
        return true
    }
    render(){
        var rows=[];
        rows.push(<option key={1000} value="Please Select">Please Select</option>);
        jsonSelect.forEach((item,index)=>{
            rows.push(<option key={index} value={item.rationale}>{(index+1)+"."+item.rationale}</option>);
        });

        return(        
        <div style={{marginLeft: "20px", marginRight: "20px", marginBottom: "15px" }}>
            <h4>Rational description {this.props.for}</h4>
            <select style={{width:"100%"}} onChange={this.changerationale} value={this.state.rationale}> {rows}
            </select>
            <br /><br />
            {this.state.selectedIndex !=0 && this.state.selectedIndex != undefined ?
            <div><h4>Comment {this.state.selectedIndex > 14 ? <sup style={{color:"red", marginLeft:"-5px"}}>*</sup>:""}</h4> 
            <textarea id={"textArea"+this.state.selectedIndex} style={{ width: "100%", height: "70px", resize:"none" }} onChange={this.addComment} value={this.state.comment} ></textarea>
            </div>: ""}
        </div>
        )
    }
}

export default CustomTabContent;