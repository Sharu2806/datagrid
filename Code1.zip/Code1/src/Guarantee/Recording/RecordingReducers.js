import * as ACTION_TYPES from '../GuaranteeActionTypes';

export default (state = {}, action) => {
    switch (action.type) {
        case ACTION_TYPES.GTE_RECORDING_FETCH_RECORDING_DROPDOWN_DATA:
            //console.log("recording drop down data reducer",...action.payload);
            state = {
                ...state,
                recordingDropDownData: {
                    ...action.payload
                }
            };
            // console.log('state after recording dropdown data ', JSON.stringify(state))
            break;
        /*case "FETCH_RECORDING_DATA":
            //console.log("recording drop down data reducer",...action.payload);
            state = {
                ...state,
                ...action.payload
            };
            // console.log('state after recording data ', JSON.stringify(state))
            break;*/
        case ACTION_TYPES.GTE_RECORDING_SAVE_BASIC_INFO_DATA:
            // console.log("SAVE_BASIC_INFO_DATA reducer");
            state = {
                ...state,
                basicInfo: {
                    ...action.payload
                }
            };
            break;
        case ACTION_TYPES.GTE_RECORDING_SAVE_BANK_INFO_DATA:
            // console.log("SAVE_BANK_INFO_DATA reducer", action.payload);
            state = {
                ...state,
                bankInfo: {
                    ...action.payload
                }
            };
            break;
        case ACTION_TYPES.GTE_RECORDING_SAVE_INTERNAL_INFO_DATA:
            // console.log("SAVE_INTERNAL_INFO_DATA reducer", action.payload);
            state = {
                ...state,
                internalInfo: {
                    ...action.payload
                }
            };
            break;
        default:
    }
    return state;
}