export default (state = {
    inputData : {
        source : [],
        searchText : "",
        countryCode : "All",
        customOpen : true,
    },
    screenSearch: {
        bankName: "",
        bankCode: "",
        address1: "",
        address2: "",
        address3: "",
        address4: "",
        countryCode: "",
        bankType: "",
        swiftAddress:"",
        clearingCode:"",
    },
    error: null
}, action) => {
    switch (action.type) {
        case "ACC_BANK_NAME" : {
            return {
                ...state,
                inputData : {
                    ...state.inputData,
                    customOpen : false,
                },
                screenSearch : {
                    ...state.screenSearch,
                    bankName : action.payload.bankName,
                    bankCode : action.payload.bankCode,
                    address1 : action.payload.address1,
                    address2 : action.payload.address2,
                    address3 : action.payload.address3,
                    address4: action.payload.address4,
                    countryCode : action.payload.countryCode,
                    bankType : action.payload.bankType,
                    swiftAddress : action.payload.swiftAddress,
                    clearingCode : action.payload.clearingCode
                }
            }
        }
        case "SET_SOURCE" : {
            return {
                ...state,
                inputData : {
                    ...state.inputData,
                    source : action.payload
                }
            }
        }
        case "CLEAR_SEARCH" : {
            return {
                ...state,
                inputData : {
                    ...state.inputData,
                    customOpen : true,
                    searchText : "",
                },
                screenSearch : {
                    ...state,
                    bankName : "",
                    bankCode : "",
                    countryCode : "",
                    address1 : "",
                    address2 : "",
                    address3 : "",
                    address4 : "",
                    bankType : "",
                    swiftAddress : "",
                    clearingCode :"",
                }
            }
        }
        case "ADD_COUNTRY_CODE" :{
            return {
                ...state,
                inputData : {
                    ...state.inputData,
                    countryCode : action.payload
                }
            }
        }
        default : 
            return state;
    }
}