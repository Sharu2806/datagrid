import React from "react";
import injectTapEventPlugin from "react-tap-event-plugin";
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import * as Actions from "./Actions/bankInputAction.js";
import { connect } from "react-redux";
import $ from "jquery";
import SuperSelect from "./CustomSuperSelect";
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

injectTapEventPlugin();
class CustomSuggestionSearch extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            value: '',
            type: this.props.radioButtonVisibleValues[0].value,
            disabledFlag: !(this.props.radioButtonVisibleValues[0].value === this.props.dropDownVisibleFor),
            dropDownData: []
        };
        this.dropDownChange = this.dropDownChange.bind(this);
        this.radioButtonChange = this.radioButtonChange.bind(this);
    }

    componentWillMount() {
        var dropData = this.props.dropDownVisibleValues
        var classThis = this
        var localData = [];
        classThis.props.listData.forEach((item, index) => {
            if (index === 0) {
                if (dropData.otherValues != undefined) {
                    localData.push({
                        otherValue: item[dropData.otherValues],
                        restValue: item[dropData.restValues]
                    });
                }
                else {
                    localData.push({
                        restValue: item[dropData.restValues]
                    })
                }
            }
            else {
                var flag = true;
                for (var temp = 0; temp < localData.length; temp++) {
                    if (item[dropData.restValues] === localData[temp].restValue) {
                        flag = false;
                        break;
                    }
                }
                if (flag) {
                    if (dropData.otherValues != undefined) {
                        localData.push({
                            otherValue: item[dropData.otherValues],
                            restValue: item[dropData.restValues]
                        });
                    }
                    else {
                        localData.push({
                            restValue: item[dropData.restValues]
                        })
                    }
                }
            }
        })
        var dropDownRows = []
        dropDownRows.push(<option key={0} value={dropData.firstValue}>{dropData.label}</option>);
        localData.forEach((item, index) => {
            dropDownRows.push(<option
                key={index + 1}
                value={item.restValue}>
                {
                    item.otherValue != undefined ?
                        item.otherValue
                        : null
                }
                {"(" + item.restValue + ")"}
            </option>);
        })
        classThis.setState({ dropDownData: dropDownRows });

    }

    radioButtonChange(event){
        
        var flag = event.target.value === this.props.dropDownVisibleFor;
        this.setState({ disabledFlag: !flag, type: event.target.value })
        this.props.dispatch(Actions.clearSearch())
    }

    dropDownChange(event) {
        if (event.target.value == "")
            this.setState({ value: event.target.value })
        this.props.dispatch(Actions.addCountryCode(event.target.value));
        this.props.dispatch(Actions.clearSearch());
    }

    render() {

        let classThis = this;

        return <div>
            {this.props.radioButtonVisible ? <div>
                {this.props.radioGroupLabelVisible ?<label className='Muli'>Search By :</label> :""}
                <div>
                    {
                        this.props.radioButtonVisibleValues.map(function (items, index) {
                            if (index === 0) {
                                return <span key={index}><input
                                    type="radio"
                                    value={items.value}
                                    name={"radioGroup"+classThis.props.id}
                                    defaultChecked={true} 
                                    onClick = {classThis.radioButtonChange}/>
                                    <span>
                                        {items.label}
                                    </span>
                                </span>
                            } else {
                                return <span key={index}><input
                                    type="radio"
                                    value={items.value}
                                    name={"radioGroup"+classThis.props.id}
                                    style={{ marginLeft: "30px" }} 
                                    onClick = {classThis.radioButtonChange}/>
                                    <span>
                                        {items.label}
                                    </span>
                                </span>
                            }
                        })
                    }
                </div>
            </div> : ""}
            {
                this.props.dropDownVisible ?
                    <select
                        className="form-control col-md-3"
                        style={{ width: '150px' }}
                        onChange={this.dropDownChange}
                        disabled={this.state.disabledFlag}>
                        {this.state.dropDownData}
                    </select>
                    : ""}
            <MuiThemeProvider muiTheme={getMuiTheme()}>
                <SuperSelect type={this.state.type}
                    {...this.props}
                />
            </MuiThemeProvider>
        </div>;
    }
}

export default connect()(CustomSuggestionSearch);