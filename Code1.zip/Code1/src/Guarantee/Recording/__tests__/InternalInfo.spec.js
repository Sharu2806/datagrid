import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, render, mount } from 'enzyme';
import 'isomorphic-fetch';
import {InternalInfo} from '../InternalInfo';

import data from '../../../../public/json/internalInfoError.json';

let internalInfo = null;
let noOfAttachment = null;
let cashAmount = null;
let cashAmount1 = null;
let debitMDAC = null;
let debitMDAC1 = null;
let debitMDAC2 = null;
let debitMDAC3 = null;
let debitMDAC4 = null;
let cashCtlLmLn = null;
let cashCtlLmLn1 = null;
let cashGrpLmLn = null;
let cashGrpLmLn1 = null;
let mdRate = null;
let debitAmount = null;
let debitAmount1 = null;
let treasuryRate = null;
let mdAccount = null;
let mdAccount1 = null;
let mdAccount2 = null;
let mdAccount3 = null;
let mdAccount4 = null;
let gteLineAmount = null;
let groupAmount = null;

beforeAll(() => {
    internalInfo = shallow(<InternalInfo/>); 
    noOfAttachment = internalInfo.find('input[name="noOfAttachment"]');
    cashAmount = internalInfo.find('input[name="cashAmount"]');
    cashAmount1 = internalInfo.find('input[name="cashAmount1"]');  
    debitMDAC = internalInfo.find('input[name="debitMDAC"]');
    debitMDAC1 = internalInfo.find('input[name="debitMDAC1"]'); 
    debitMDAC2 = internalInfo.find('input[name="debitMDAC2"]'); 
    debitMDAC3 = internalInfo.find('input[name="debitMDAC3"]'); 
    debitMDAC4 = internalInfo.find('input[name="debitMDAC4"]'); 
    cashCtlLmLn = internalInfo.find('input[name="cashCtlLmLn"]'); 
    cashCtlLmLn1 = internalInfo.find('input[name="cashCtlLmLn1"]');
    cashGrpLmLn = internalInfo.find('input[name="cashGrpLmLn"]'); 
    cashGrpLmLn1 = internalInfo.find('input[name="cashGrpLmLn1"]');  
    mdRate = internalInfo.find('input[name="mdRate"]');
    debitAmount = internalInfo.find('input[name="debitAmount"]');
    debitAmount1 = internalInfo.find('input[name="debitAmount1"]');
    treasuryRate = internalInfo.find('input[name="treasuryRate"]');
    mdAccount = internalInfo.find('input[name="mdAccount"]');
    mdAccount1 = internalInfo.find('input[name="mdAccount1"]');
    mdAccount2 = internalInfo.find('input[name="mdAccount2"]');
    mdAccount3 = internalInfo.find('input[name="mdAccount3"]');
    mdAccount4 = internalInfo.find('input[name="mdAccount4"]');
    gteLineAmount = internalInfo.find('input[name="gteLineAmount"]');
    groupAmount = internalInfo.find('input[name="groupAmount"]');
});

describe('InternalInformation', () => {
    it('renders without crashing', () => {
        expect(internalInfo.find('form').length).toBe(1);
    });

    describe('Cash Amount', () => {
        it('should render once', () => {
            expect(cashAmount.length).toBe(1);
        });
        xit('should have validation attributes set', () => {
            expect(cashAmount.prop('required')).toBe(true);
        });
        xit('should show error if no value is entered', () => {
            internalInfo.instance().saveError(data);
            cashAmount.simulate('blur',{target:{...cashAmount.props()}, type: 'blur', preventDefault: () => {} });
            expect( internalInfo.find('ErrorDisplay[fieldName="cashAmount"]').prop('errors').length).toBe(0);
        });
        it('should render once', () => {
            expect(cashAmount1.length).toBe(1);
        });
        xit('should have validation attributes set', () => {
            expect(cashAmount1.prop('required')).toBe(true);
        });
        xit('should show error if no value is entered', () => {
            internalInfo.instance().saveError(data);
            cashAmount1.simulate('blur',{target:{...cashAmount1.props()}, type: 'blur', preventDefault: () => {} });
            expect( internalInfo.find('ErrorDisplay[fieldName="cashAmount1"]').prop('errors').length).toBe(0);
        });
    });

     describe('Debit MD AC', () => {
        it('should render once', () => {
            expect(debitMDAC.length).toBe(1);
        });
        it('should render once', () => {
            expect(debitMDAC1.length).toBe(1);
        });
        it('should render once', () => {
            expect(debitMDAC2.length).toBe(1);
        });
        it('should render once', () => {
            expect(debitMDAC3.length).toBe(1);
        });
        it('should render once', () => {
            expect(debitMDAC4.length).toBe(1);
        });
     });

    describe('No. of Attachment', () => {
        it('should render once', () => {
            expect(noOfAttachment.length).toBe(1);
        });
        it('No.of Attachment is present', () => {
            expect(internalInfo.contains('No.of Attachment')).toEqual(true);
        });
        it('should have validation attributes set', () => {
            expect(noOfAttachment.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            internalInfo.instance().saveError(data);
            noOfAttachment.simulate('blur',{target:{...noOfAttachment.props()}, type: 'blur', preventDefault: () => {} });
            expect( internalInfo.find('ErrorDisplay[fieldName="noOfAttachment"]').prop('errors').length).toBe(1);
            expect( internalInfo.find('ErrorDisplay[fieldName="noOfAttachment"]').prop('errors')[0]['error']).toBe("No.Of Attachment is required");
        });
    });

     describe('Cash Ctl Lm/Ln', () => {
        it('should render once', () => {
            expect(cashCtlLmLn.length).toBe(1);
        });
        it('should render once', () => {
            expect(cashCtlLmLn1.length).toBe(1);
        });
     });

     describe('Cash Grp Lm/Ln', () => {
        it('should render once', () => {
            expect(cashGrpLmLn.length).toBe(1);
        });
        it('should render once', () => {
            expect(cashGrpLmLn1.length).toBe(1);
        });
     });

     describe('MD Rate', () => {
        it('should render once', () => {
            expect(mdRate.length).toBe(1);
        });
     });

     describe('Debit Amount', () => {
        it('should render once', () => {
            expect(debitAmount.length).toBe(1);
        });
        it('should render once', () => {
            expect(debitAmount1.length).toBe(1);
        });
     });

     describe('Treasury Rate', () => {
        it('should render once', () => {
            expect(treasuryRate.length).toBe(1);
        });
     });

     describe('MD Account', () => {
        it('should render once', () => {
            expect(mdAccount.length).toBe(1);
        });
        it('should render once', () => {
            expect(mdAccount1.length).toBe(1);
        });
        it('should render once', () => {
            expect(mdAccount2.length).toBe(1);
        });
        it('should render once', () => {
            expect(mdAccount3.length).toBe(1);
        });
        it('should render once', () => {
            expect(mdAccount4.length).toBe(1);
        });
     });

     describe('GTE Line Amount', () => {
        it('should render once', () => {
            expect(gteLineAmount.length).toBe(1);
        });
     });
     describe('Treasury Rate', () => {
        it('should render once', () => {
            expect(groupAmount.length).toBe(1);
        });
     });

     

});