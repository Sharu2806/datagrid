import DefinitionCriteria from '../DefinitionCriteria';
import { SubmissionError } from 'redux-form'
import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, render, mount } from 'enzyme';
// import { DateField, DatePicker } from 'react-date-picker';
// import moment from 'moment';
import 'isomorphic-fetch';

//import data from '../../../../public/json/indexingInformationRecord.json';

let definitionCriteria = null;
let accountNumber = null;
//let transactionNumber = null;
let transactionNumber2 = null;
let transactionNumber3 = null;
let hexagonReferenceNumber = null;
let copyFromTransaction = null;
let bussinessUnitId = null;
let ieDivisionCode = null;
let wolfStatus = null;
let createTemplate = null;
let createTemplate2 = null;
let formalAmendment = null;
let formalAmendment2 = null;
let itReferenceNumber = null;
            
beforeAll(() => {
    definitionCriteria = shallow(<DefinitionCriteria/>);    
    accountNumber = definitionCriteria.find('input[name="accountNumber"]');
    //transactionNumber = definitionCriteria.find('input[name="transactionNumber"]');
    transactionNumber2 = definitionCriteria.find('input[name="transactionNumber2"]');
    transactionNumber3 = definitionCriteria.find('input[name="transactionNumber3"]');
    hexagonReferenceNumber = definitionCriteria.find('input[name="hexagonReferenceNumber"]');
    copyFromTransaction = definitionCriteria.find('input[name="copyFromTransaction"]');
    bussinessUnitId = definitionCriteria.find('input[name="bussinessUnitId"]');
    ieDivisionCode = definitionCriteria.find('input[name="ieDivisionCode"]');
    wolfStatus = definitionCriteria.find('input[name="wolfStatus"]');
    createTemplate = definitionCriteria.find('input[id="createTemplate"]');
    createTemplate2 = definitionCriteria.find('input[id="createTemplate2"]');
    formalAmendment= definitionCriteria.find('input[id="formalAmendment"]');
    formalAmendment2= definitionCriteria.find('input[id="formalAmendment2"]');
    itReferenceNumber= definitionCriteria.find('input[id="itReferenceNumber"]');
});

describe('DefinitionCriteria', () => {
    it('renders without crashing', () => {
        expect(definitionCriteria.find('form').length).toBe(1);
    });

    it('page header should be - Definition Criteria', () => {
        const header = <span className="Muli-Bold" style={{ fontSize: '16px' }}>Definition Criteria</span>;
        expect(definitionCriteria.contains(header)).toEqual(false);
    });

});


    describe('accountNumber', () => {
        it('should render once', () => {
            expect(accountNumber.length).toBe(2);
        });
    });
    describe('itReferenceNumber', () => {
        it('should render once', () => {
            expect(itReferenceNumber.length).toBe(1);
        });
    });
    describe('hexagonReferenceNumber', () => {
        it('should render once', () => {
            expect(hexagonReferenceNumber.length).toBe(1);
        });
    });
    describe('copyFromTransaction', () => {
        it('should render once', () => {
            expect(copyFromTransaction.length).toBe(1);
        });
    });
    describe('bussinessUnitId', () => {
        it('should render once', () => {
            expect(bussinessUnitId.length).toBe(1);
        });
    });
    describe('ieDivisionCode', () => {
        it('should render once', () => {
            const selectIeDivisionCode = <select className="form-control selectCss" name="ieDivisionCode" id="ieDivisionCode">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>;
        expect(definitionCriteria.contains(selectIeDivisionCode)).toEqual(true);
        });
     });

     describe('Transaction Number', () => {
        it('should render once for Select', () => {
            const transactionNumber = <select className="form-control selectCss" name="transactionNumber" id="transactionNumber">
                                <option value="FNG">FNG</option>
                                <option value="GUA">GUA</option>
                                <option value="RAN">RAN</option>
                                <option value="TEE">TEE</option>
                            </select>;
        expect(definitionCriteria.contains(transactionNumber)).toEqual(false);
        });
     });
     describe('transactionNumber2', () => {
        it('should render once', () => {
            expect(transactionNumber2.length).toBe(1);
        });
    });
    describe('transactionNumber3', () => {
        it('should render once', () => {
            expect(transactionNumber3.length).toBe(1);
        });
    });

     describe('wolfStatus', () => {
        it('should render once', () => {
            const selectWolfStatus = <select className="form-control selectCss" name="wolfStatus" id="wolfStatus">
                                <option value="Y">Y</option>
                                <option value="N">N</option>
                            </select>;
        expect(definitionCriteria.contains(selectWolfStatus)).toEqual(true);
        });
     });
     describe('createTemplate', () => {
        it('should render once', () => {
            expect(createTemplate.length).toBe(1);
        });
    });
    describe('createTemplate2', () => {
        it('should render once', () => {
            expect(createTemplate2.length).toBe(1);
        });
    });
    describe('formalAmendment', () => {
        it('should render once', () => {
            expect(formalAmendment.length).toBe(1);
        });
    });
    describe('formalAmendment2', () => {
        it('should render once', () => {
            expect(formalAmendment2.length).toBe(1);
        });
    });
        // it('should have validation attributes set', () => {
        //     expect(customerAccountNumber.prop('required')).toBe(true);
        // });
  /*      it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            customerAccountNumber.simulate('blur',{target:{...customerAccountNumber.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="customerAccountNumber"]').prop('errors').length).toBe(1);
            expect( indexingInfo.find('ErrorDisplay[fieldName="customerAccountNumber"]').prop('errors')[0]['error']).toBe("customerAccountNumber is required");
        });*/
   

    // describe('customerName', () => {
    //     it('should render once', () => {
    //         expect(customerName.length).toBe(1);
    //     });

    //     // it('should have validation attributes set', () => {
    //     //     expect(customerName.prop('required')).toBe(true);
    //     // });
    // /*    it('should show error if no value is entered', () => {
    //         indexingInfo.instance().saveError(data);
    //         customerName.simulate('blur',{target:{...customerName.props()}, type: 'blur', preventDefault: () => {} });
    //         expect( indexingInfo.find('ErrorDisplay[fieldName="customerName"]').prop('errors').length).toBe(0);
    //     });*/
    // });
	/*describe('applicationDateTime', () => {
        // it('should render once', () => {
        //     expect(applicationDateTime.length).toBe(1);
        // });
         it('should render once', () => {
        const datefield = <DateField className="form-control" dateFormat="YYYY-MM-DD HH:mm:ss" forceValidDate={true} defaultValue={moment()} >
                            <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} highlightToday={true} weekNumbers={true} weekStartDay={0} />
                        </DateField>;
        expect(indexingInfo.contains(datefield)).toEqual(false);
    });
});*/
/*describe('expiryDate', () => {
        // it('should render once', () => {
        //     expect(applicationDateTime.length).toBe(1);
        // });
         it('should render once', () => {
        const datefieldEx = <DateField className="form-control" dateFormat="YYYY-MM-DD HH:mm:ss" forceValidDate={true} defaultValue={moment()} >
                            <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} highlightToday={true} weekNumbers={true} weekStartDay={0} />
                        </DateField>;
        expect(indexingInfo.contains(datefieldEx)).toEqual(false);
    });
    });*/
   /*     it('should have validation attributes set', () => {
            expect(stapplicationDateTimeatus.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            applicationDateTime.simulate('blur',{target:{...applicationDateTime.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="applicationDateTime"]').prop('errors').length).toBe(0);
        });*/
    /*});
	describe('transactionCurrency', () => {
        // it('should render once', () => {
        //     expect(transactionCurrency.length).toBe(1);
        // });
        it('page header should be - Indexing Information', () => {
        const selectTransactionCurrency = <select className="form-control selectCss"  name="transactionCurrency" id="transactionCurrency">
                            <option value="">Please Select</option>
                            <option value="INR">INR</option>
                            <option value="HKD">HKD</option>
                            <option value="USD">USD</option>
                        </select>;
        expect(indexingInfo.contains(selectTransactionCurrency)).toEqual(false);
    });

      /*  it('should have validation attributes set', () => {
            expect(transactionCurrency.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            transactionCurrency.simulate('blur',{target:{...transactionCurrency.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="transactionCurrency"]').prop('errors').length).toBe(0);
        });*/
//     });
// 	describe('transactionAmount', () => {
//         it('should render once', () => {
//             expect(transactionAmount.length).toBe(1);
//         });

//         // it('should have validation attributes set', () => {
//         //     expect(transactionAmount.prop('required')).toBe(true);
//         // });
//    /*     it('should show error if no value is entered', () => {
//             indexingInfo.instance().saveError(data);
//             transactionAmount.simulate('blur',{target:{...transactionAmount.props()}, type: 'blur', preventDefault: () => {} });
//             expect( indexingInfo.find('ErrorDisplay[fieldName="transactionAmount"]').prop('errors').length).toBe(0);
//         });*/
//     });
// 	describe('sgNumber', () => {
//         it('should render once', () => {
//             expect(sgNumber.length).toBe(1);
//         });

//         // it('should have validation attributes set', () => {
//         //     expect(GTENumber.prop('required')).toBe(true);
//         // });
//     /*    it('should show error if no value is entered', () => {
//             indexingInfo.instance().saveError(data);
//             dcNumber.simulate('blur',{target:{...dcNumber.props()}, type: 'blur', preventDefault: () => {} });
//             expect( indexingInfo.find('ErrorDisplay[fieldName="dcNumber"]').prop('errors').length).toBe(0);
//         });*/
//     });	*/

