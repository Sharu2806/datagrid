import React, { Component } from 'react';
import { connect } from 'react-redux';

import RecordInformationAfterDC from '../../SharedComponents/RecordInformationAfterDC';
import ButtonLineControl from '../../SharedComponents/ButtonLineControl';
import BasicInformation from './BasicInformation';
import BankInformation from './BankInformation';
import InternalInfo from './InternalInfo';
import SpecialInstruction from './SpecialInstruction';
import * as ACTIONS from './RecordingActions';
import * as Utils from '../../common.js';

import WolfHitDetails from "./WOLFHitDetails";

class Recording extends Component {

    constructor(props) {
        super(props);

        this.currentActiveTab = 'basicInfo';
        this.navigate = this.navigate.bind(this);
        this.handleTabClick = this.handleTabClick.bind(this);
        this.handleSaveClick = this.handleSaveClick.bind(this);
        this.handleSubmitClick = this.handleSubmitClick.bind(this);
	 this.handleAssignClick=this.handleAssignClick.bind(this);
        this.buttonList = [
            { btnName: 'Save', btnClass: 'btn btn-green', btnClickEvent: this.handleSaveClick, btnIcon: 'save' },
            { btnName: 'Send', btnClass: 'btn btn-green', btnClickEvent: this.handleSubmitClick, btnIcon: 'send' },
            { btnName: 'Send & Assign', btnClass: 'btn btn-grey', btnIcon: 'send-assign' },
            { btnName: 'Hold', btnClass: 'btn btn-grey', btnIcon: 'hold' },
            { btnName: 'Show Image', btnClass: 'btn btn-grey', btnIcon: 'open_image' },
            { btnName: 'Cancel', btnClass: 'btn btn-grey', btnIcon: 'cancel' },
            { btnName: 'Assign', btnClass: 'btn btn-grey', btnIcon: 'assign' },
            { btnName: 'Copy', btnClass: 'btn btn-grey', btnIcon: 'copy' }
        ]
    }

    componentDidMount() {
        window.scrollTo(0, 0);
        this.props.fetchDropdownData();
        //this.props.fetchRecordingData();
        document.getElementById("layoutDiv").style.marginTop = "25px";
    }

    componentWillUnmount() {
        document.getElementById("layoutDiv").style.marginTop = "0px";
    }

    navigate() {
        this.props.history.push('/recordingdc');
    }

    handleTabClick(event) {
        Utils.handleTabClick(event, this);
    }

    handleSaveClick() {
        Utils.handleSaveClick(this, "recordingTabs");
    }

    handleSubmitClick() {
        var cuurentObj = this[this.currentActiveTab];
        cuurentObj.saveData();

        var basicInfoObj = this['basicInfo'];
        var bankInfoObj = this['bankInfo'];
        var internalInfoObj = this['internalInfo'];

        var errorsObj = basicInfoObj.state.errors;
        var errorsObj1 = bankInfoObj.state.errors;
        var errorsObj2 = internalInfoObj.state.errors;

        if (errorsObj.length === 0 &&
            errorsObj1.length === 0 &&
            errorsObj2.length === 0) {

            setTimeout(() => {
                let recordingData = this.props.allRecordingData;

                delete recordingData['recordingDropDownData'];
                if (recordingData['bankInfo']) {
                    delete recordingData['bankInfo']['dropDownData'];
                }

                Utils.deleteErrors(recordingData);

                //console.log(JSON.stringify(recordingData));
                this.props.submitRecordingData(recordingData);
            }, 2000);
        } else {
            console.log("Please correct errors");
           }
handleAssignClick(){
        var tabElement = document.getElementById("recordingTabs").getElementsByClassName("active")[0]
            .childNodes[0].getAttribute("href")
            var callingTab = tabElement.substring(1)
            this[callingTab].assignData()
    }
    render() {
        var data = this.props.workItemData
        var wdmData = this.props.wdmData;
        return (
            <div>
                <SpecialInstruction
                    specialInstructionData={data}
                />
                <div className="row" style={{ marginTop: "-25px" }}>
                    <div className="panel panel-holding-tabs">
                        {
                            data && wdmData &&
                            <RecordInformationAfterDC
                                workItemData={data}
                                wdmData={wdmData}
                            />
                        }
                        <ul id="recordingTabs" className="nav nav-tabs" onClick={this.handleTabClick} style={{ overflow: 'hidden', position: 'relative', top: '1px' }}>
                            <li className="active"><a data-toggle="tab" href="#basicInfo">Basic Info.</a></li>
                            <li><a data-toggle="tab" href="#bankInfo">Bank Info.</a></li>
                            <li><a data-toggle="tab" href="#internalInfo">Internal Info.</a></li>
                            <li><a data-toggle="tab" href="#wolfHitDetails">WOLF Hit Details</a></li>
                            {/*<li><a data-toggle="tab" href="#additionalInfo">Additional Info.</a></li>
                            <li><a data-toggle="tab" href="#workflowManagement">Workflow Management</a></li>*/}
                        </ul>
                    </div>
                    <div className="tab-content" style={{ marginLeft: '30px', marginRight: '30px', marginBottom: '180px' }}>
                        <div id="basicInfo" className="tab-pane fade in active">
                            {this.props.allRecordingData &&
                                <BasicInformation
                                    onRef={ref => (this.basicInfo = ref)}
                                    saveBasicInfoData={this.props.saveBasicInfoData}
                                    inputData={this.props.allRecordingData.basicInfo}
                                />
                            }
                        </div>
                        <div id="bankInfo" className="tab-pane fade">
                            {this.props.allRecordingData &&
                                <BankInformation
                                    onRef={ref => (this.bankInfo = ref)}
                                    saveBankInfoData={this.props.saveBankInfoData}
                                    inputData={this.props.allRecordingData.bankInfo}
                                />
                            }
                        </div>
                        <div id="internalInfo" className="tab-pane fade">
                            {this.props.allRecordingData &&
                                <InternalInfo
                                    onRef={ref => (this.internalInfo = ref)}
                                    saveInternalInfoData={this.props.saveInternalInfoData}
                                    inputData={this.props.allRecordingData.internalInfo}
                                />
                            }
                        </div>
                        <div id="wolfHitDetails" className="tab-pane fade">
                        <WolfHitDetails onRef={ref => (this.wolfHitDetails = ref)}/>
                    </div>
                        <div id="additionalInfo" className="tab-pane fade">
                            <span className="Muli-Bold">Additional Info</span>
                        </div>
                        <div id="workflowManagement" className="tab-pane fade">
                            <span className="Muli-Bold">Workflow Management</span>
                        </div>
                    </div>
                    <div
                        className={this.props.rightSideClass + " pull-right navbar-fixed-bottom bottom-buttons-layout"}
                        id="recording-bottom-button-layout"
                    >
                        <ButtonLineControl buttonList={this.buttonList} id="recording-bottom-button-layout" />

                    </div>
                </div>
            </div>
        );
    }
}
const mapsStateToProps = (state) => {
    //console.log('state here ', JSON.stringify(state));
    if (state.recordingDCReducer)
        return {
            workItemData: state.recordingDCReducer.outputData,
            allRecordingData: state.recordingReducer,
            wdmData: state.recordingDCReducer.wdmData
        }
    else
        return {
            workItemData: null,
            allRecordingData: state.recordingReducer,
            wdmData: null
        }
};

const mapsDispatchToProps = (dispatch) => {
    return {
        fetchDropdownData: () => {
            dispatch(ACTIONS.fetchRecordingDropdownData());
        },
        // fetchRecordingData: () => {
        //     dispatch(ACTIONS.fetchRecordingData());
        // },
        saveBasicInfoData: (obj) => {
            dispatch(ACTIONS.saveBasicInfoData(obj));
        },
        saveBankInfoData: (obj) => {
            dispatch(ACTIONS.saveBankInfoData(obj));
        },
        saveInternalInfoData: (obj) => {
            dispatch(ACTIONS.saveInternalInfoData(obj));
        },
        submitRecordingData: (obj) => {
            dispatch(ACTIONS.submitRecordingData(obj));
        }
    };
};
export default connect(mapsStateToProps, mapsDispatchToProps)(Recording);