import * as ACTION_TYPES from '../GuaranteeActionTypes';

export default (state = null, action) => {
    switch (action.type) {
        case ACTION_TYPES.GTE_RECORDINGDC_FETCH_RECORDINGDC_DATA:
            //console.log("fetch recording dAta");

            state = {
                ...action.payload,
                recordingFlag: true
            };
            break;
        case ACTION_TYPES.GTE_RECORDINGDC_SAVE_DEFINITION_CRITERIA_DATA:
            // console.log("saveData BASIC reducer");
            state = {
                ...state,
                defintionCriteria: {
                    ...action.payload
                }
            };
            break;
        case ACTION_TYPES.GTE_RECORDINGDC_GENERATE_RECORDING_DC_NUMBER:
            //console.log("GENERATE_RECORDING_DC_NUMBER reducer :: ", action.payload);
            state = {
                ...state,
                outputData: action.payload
            };
            break;
        case ACTION_TYPES.GTE_RECORDINGDC_FETCH_WDM_DATA:
            //console.log("FETCH_WDM_DATA reducer :: ", action.payload);
            state = {
                ...state,
                wdmData: action.payload
            };
            break;

        default:

    }
    return state;
}
