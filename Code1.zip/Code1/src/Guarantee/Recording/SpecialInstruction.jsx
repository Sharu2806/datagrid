import React from 'react';

import CustomScrollbars from '../../SharedComponents/CustomScrollbars.jsx';

class SpecialInstruction extends React.Component {

    constructor() {
        super();
        this.state = {
            isSlideIn: true,
            isPopIn: false
        };
        this.adjustNav = this.adjustNav.bind(this);
        this.adjustPopup = this.adjustPopup.bind(this);
    }

    adjustNav() {
        if (this.state.isSlideIn)
            document.getElementById("myNav").style.height = '25px';
        else
            document.getElementById("myNav").style.height = '300px';
        this.setState({
            isSlideIn: !this.state.isSlideIn,
        })
    }

    adjustPopup() {
        this.adjustNav();
        this.openWin();
        this.setState({
            isPopIn: !this.state.isPopIn,
        })
    }

    openWin() {

        var divText = document.getElementById("over").innerText;
        var myWindow = window.open('http://localhost:3000/specialInstruction.html', 'Special Instruction', 'titlebar=no,toolbar=no,location=no,width=600,height=600');
        myWindow.specilaInstruction = divText;
    }

    render() {
        var data = this.props.specialInstructionData;
        var imgStyle = { display: "inline-block", float: "right", marginRight: "30px" };
        return (
            <div id="specialInst">
                <div style={{ marginBottom: "25px" }} >
                    <div id="myNav" style={{ height: "260px" }} className="overlay" >
                        <div style={{ textAlign: "center", color: "white" }}>
                            Special Instructions
                                {this.state.isPopIn ?
                                <img
                                    src='icons/pop-in.svg'
                                    alt="Expand"
                                    height="25"
                                    width="25"
                                    onClick={this.adjustPopup}
                                    style={imgStyle}
                                />
                                :
                                <img
                                    src='icons/pop-out.svg'
                                    alt="Collapse"
                                    height="25"
                                    width="25"
                                    onClick={this.adjustPopup}
                                    style={imgStyle}
                                />
                            }
                            {this.state.isSlideIn ?
                                <img
                                    src='icons/slide-out.svg'
                                    alt="Collapse"
                                    height="25"
                                    width="25"
                                    onClick={this.adjustNav}
                                    style={imgStyle}
                                />
                                :
                                <img
                                    src='icons/slide-in.svg'
                                    alt="Expand"
                                    height="25"
                                    width="25"
                                    onClick={this.adjustNav}
                                    style={imgStyle}
                                />
                            }
                        </div>
                        <div id="over" className="overlay-content" style={{ color: "white" }}>

                            {/*Start of Special Instructions Div Scrollbars*/}
                            <CustomScrollbars style={{ width: 1335, height: 190 }}>
                                <div className="">
                                    <div className="">
                                        <div className='col-md-12'>
                                            <div className='row'>
                                                <div className='col-md-3'></div>
                                                <div className="col-md-6">

                                                    {data && data.specialInstruction}

                                                    {/*Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent libero lacus, lobortis congue purus hendrerit, pharetra dictum metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Phasellus in elit vel nisl condimentum tincidunt eget quis turpis. Aliquam porta placerat nisl vitae interdum. Ut nibh lorem, mollis sit amet diam a, ultrices tincidunt felis. Duis tincidunt, mauris convallis interdum suscipit, dui elit ultrices elit, et rhoncus nunc lacus a odio. Morbi quis egestas nisl. Etiam vestibulum felis vitae felis lobortis, sit amet interdum neque congue. Curabitur est augue, imperdiet ullamcorper diam ac, suscipit auctor orci. Donec id ex eget eros volutpat tempor. Vivamus pretium sagittis quam vel malesuada. In hac habitasse platea dictumst. Maecenas consequat imperdiet lacus, at faucibus mauris posuere ac. Pellentesque a tellus dolor. Ut ante nisi, sagittis quis varius eu, luctus aliquet elit. Nunc vel ullamcorper mauris. Duis scelerisque tempor velit, eget euismod arcu ultrices nec. Nulla facilisi. Pellentesque ullamcorper tellus vitae sapien dapibus venenatis. Phasellus eget nunc ornare, aliquet nulla eu, lacinia metus. Maecenas maximus porta feugiat. Pellentesque finibus nulla orci, non pulvinar libero finibus vitae. Pellentesque bibendum vehicula arcu vitae dignissim. Aliquam tempor nisl id porttitor venenatis.
                                               */}
                                                </div>
                                                <div className='col-md-3'></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </CustomScrollbars>
                            {/*End of Special Instructions Div Scrollbars*/}
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}

export default SpecialInstruction;