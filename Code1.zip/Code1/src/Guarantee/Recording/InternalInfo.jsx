import React, { Component } from 'react';
import { DateField } from 'react-date-picker';
import { connect } from "react-redux";

import DatePicker from 'react-datepicker';
import moment from 'moment';

import * as Utils from '../../common.js';

import ErrorDisplay from '../../SharedComponents/ErrorDisplay';

var internalInfoValidate = {
    "comdtyCd": { mandatory: true },
    "ctrlOnGood": { mandatory: true },
    "dCLinAmt": { mandatory: true },
    "availBal": { mandatory: true },
    "attchNbr": { mandatory: true },
    "iMCPct": { mandatory: true },
    "ctrlLmtData.lmtType": { mandatory: true },
    "ctrlLmtData.lmtLine": { mandatory: true },
    "grpLmtData.lmtType": { mandatory: true },
    "grpLmtData.lmtLine": { mandatory: true }
};

export class InternalInfo extends Component {

    constructor(props) {
        super(props);
        this.state = {
            comdtyCd: '',
            availBal: '',
            availBal1: '',
            attchNbr: '',
            drToACTyp: '',

            ctrlOnGood: '',
            iMCPct: '',
            iMCAmt: '',
            "iMCCtrlLmtData.lmtType": '',
            "iMCCtrlLmtData.lmtLine": '',

            "iMCGrpLmtData.lmtType": '',
            "iMCGrpLmtData.lmtLine": '',

            "mrgnLienExpData.mrgnLienExpOpt": '',
            "mrgnLienExpData.mrgnLienExpPct": '',

            mrgnDepostRat: '',
            mrgnLienAcct: '',
            mrgnLienAmt: '',
            "lMDData.acctPdTp": '',
            "lMDData.lnNbrId": '',

            tRate: '',
            mDMaintnFlg: '',

            dCLinPct: '',
            dCLinAmt: '',

            "ctrlLmtData.lmtType": '',
            "ctrlLmtData.lmtLine": '',

            "grpLmtData.lmtType": '',
            "grpLmtData.lmtLine": '',

            errors: []

        };

        this.addError = this.addError.bind(this);
        this.removeError = this.removeError.bind(this);

        this.handleChange = this.handleChange.bind(this);
        let errorFromJson = [];
    }

    componentWillMount() {
        this.setState({
            ...this.props.inputData
        });
    }

    componentDidMount() {

        this.props.onRef(this);
        this.setState({
            ...this.props.inputData
        });
        fetch('json/internalInfoError.json', {
            method: 'GET'
        })
            .then(result => result.json())
            .then(body => this.saveError(body));
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            ...nextProps.inputData
        });
    }

    componentWillUnmount() {
        this.props.onRef(undefined)
    }

    addError(event) {
        Utils.addError(event, this);
    }

    handleChange(event) {
        Utils.handleChange(event, this)
    }

    // removes error when the input field gets focussed with obj:{fieldName:abc, error:xyz}
    removeError(event) {
        Utils.removeError(event, this);
    }

    saveError(body) {
        this.errorFromJson = body
    }

    saveData() {
        if (Utils.validateErrors(this)) {
            this.props.saveInternalInfoData(this.state);
        }
    }

    render() {

        return (
            <div>
                <form>
                    <div className="row" >
                        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <span className="Muli-Bold" style={{ fontSize: '16px' }}>Internal Information</span>
                            <hr style={{ borderColor: '#919191', marginTop: '1px' }} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Commodity Code</span><br />
                            <select className="form-control selectCss" maxLength="2" onChange={this.handleInputChange} name="comdtyCd" id="comdtyCd">
                                <option value="">Please Select</option>
                            </select>
                        </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Available Balance</span>&nbsp;<span style={{ color: 'red' }}>*</span>  <br />
                            <div className="row no-gutter">
                                <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                    <input type="text" className="form-control" disabled style={{ marginLeft: '-3px' }} value="INR" onChange={this.handleChange} name="availBal1" id="availBal1" />
                                </div>
                                <div className="col-xs-9 col-sm-9 col-md-9 col-lg-9" >
                                    <input type="number" className="form-control" disabled value={this.state.availBal} onChange={this.handleChange} name="availBal" id="availBal" />
                                </div>
                            </div>
                            <ErrorDisplay errors={this.state.errors} fieldName='availBal' className='errorClass' />
                        </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">No.of Attachment</span> &nbsp;<span style={{ color: 'red' }}>*</span>  <br />
                            <input type="number" className="form-control" pattern="^[0-9]{2}$" required={internalInfoValidate ? internalInfoValidate.attchNbr.mandatory : false} value={this.state.attchNbr} onBlur={this.addError} onFocus={this.removeError} onChange={this.handleChange} name="attchNbr" id="attchNbr" />
                            <ErrorDisplay errors={this.state.errors} fieldName='attchNbr' className='errorClass' />
                        </div>
                        <div className="clearfix visible-sm visible-md"> </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Debit to A/C Type </span>   <br />
                            <select className="form-control selectCss" onFocus={this.removeError} onBlur={this.addError} value={this.state.drToACTyp} onChange={this.handleInputChange} name="drToACTyp" id="drToACTyp">
                                <option value="">Please Select</option>
                            </select>
                        </div>
                        <div className="clearfix  visible-lg"></div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Control on Goods</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                            <div className="row">
                                <div className="col-xs-4 col-sm-5 col-md-6 col-lg-6">
                                    <input type="radio" name="ctrlOnGood" id="ctrlOnGood" value="Standard" onFocus={this.removeError} onChange={this.handleInputChange} />Yes
                                </div>
                                <div className="col-xs-8 col-sm-7 col-md-6 col-lg-6">
                                    <input type="radio" name="ctrlOnGood" id="ctrlOnGood" value="Premium" onFocus={this.removeError} onChange={this.handleInputChange} checked />No
                                </div>
                            </div>
                        </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Cash %</span>&nbsp;<span style={{ color: 'red' }}>*</span>  <br />
                            <input type="number" className="form-control" pattern="^[1-9]?[0-9]{1}$|^100$" required={internalInfoValidate ? internalInfoValidate.iMCPct.mandatory : false} onFocus={this.removeError} onBlur={this.addError} value={this.state.iMCPct} onChange={this.handleChange} name="iMCPct" id="iMCPct" />
                            <ErrorDisplay errors={this.state.errors} fieldName='iMCPct' className='errorClass' />
                        </div>
                        <div className="clearfix visible-sm visible-md"></div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Cash Amount</span> &nbsp;  <br />
                            <div className="row no-gutter">
                                <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                    <input type="text" className="form-control" disabled style={{ marginLeft: '-3px' }} value="INR" onChange={this.handleChange} name="iMCAmt1" id="iMCAmt1" />
                                </div>
                                <div className="col-xs-9 col-sm-9 col-md-9 col-lg-9" >
                                    <input type="number" className="form-control" value={this.state.iMCAmt} onChange={this.handleChange} name="iMCAmt" id="iMCAmt" />
                                </div>
                            </div>
                        </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Cash Ctl Lm/Ln</span>   <br />
                            <div className="row">
                                <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <input type="text" className="form-control" value={this.state['iMCCtrlLmtData.lmtType']} onChange={this.handleChange} name="iMCCtrlLmtData.lmtType" id="iMCCtrlLmtData.lmtType" />
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <input type="number" className="form-control" value={this.state['iMCCtrlLmtData.lmtLine']} onChange={this.handleChange} name="iMCCtrlLmtData.lmtLine" id="iMCCtrlLmtData.lmtLine" />
                                </div>
                            </div>
                        </div>
                        <div className="clearfix visible-lg"></div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Cash Grp Lm/Ln</span>   <br />
                            <div className="row">
                                <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <input type="text" className="form-control" value={this.state['iMCGrpLmtData.lmtType']} onChange={this.handleChange} name="iMCGrpLmtData.lmtType" id="iMCGrpLmtData.lmtType" />
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <input type="text" className="form-control" value={this.state['iMCGrpLmtData.lmtLine']} onChange={this.handleChange} name="iMCGrpLmtData.lmtLine" id="iMCGrpLmtData.lmtLine" />
                                </div>
                            </div>

                        </div>
                        <div className="clearfix visible-sm visible-md"> </div>

                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <div className="row">
                                <div className="col-xs-12 col-sm-9 col-md-9 col-lg-9">
                                    <span className="label-margin-below">Margin/Exp</span>
                                    <select className="form-control selectCss" maxLength="2" onChange={this.handleInputChange} name="mrgnLienExpData.mrgnLienExpOpt" id="mrgnLienExpData.mrgnLienExpOpt">
                                        <option value="">Please Select</option>
                                        <option value="">B - Back to Back DC</option>
                                        <option value="">M – Margin Deposits</option>
                                        <option value="">L – Lien Over Funds</option>
                                        <option value="">E – Exports Documen</option>


                                    </select>
                                </div>
                                <div className="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                                    <span className="label-margin-below">%</span>
                                    <input type="text" className="form-control" style={{ width: "61px", marginLeft: "-25px" }} value={this.state['mrgnLienExpData.mrgnLienExpPct']} onChange={this.handleChange} name="mrgnLienExpData.mrgnLienExpPct" id="mrgnLienExpData.mrgnLienExpPct" />
                                </div>
                            </div>
                        </div>

                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">MD Rate</span>   <br />
                            <input type="text" className="form-control" value={this.state.mrgnDepostRat} onChange={this.handleChange} name="mrgnDepostRat" id="mrgnDepostRat" />
                        </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Debit MD AC</span> &nbsp;  <br />
                            <div className="row no-gutter">
                                <div className="col-xs-12 col-sm-2 col-md-2 col-lg-2" style={{ paddingRight: '2px' }}>
                                    <input type="text" className="form-control" value={this.state.debitMDAC} onChange={this.handleChange} name="debitMDAC" id="debitMDAC" onBlur={this.isValid} onFocus={this.removeError1} />
                                </div>
                                <div className="col-xs-12 col-sm-3 col-md-3 col-lg-3" style={{ paddingRight: '2px' }}>
                                    <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.debitMDAC1} onChange={this.handleChange} name="debitMDAC1" id="debitMDAC1" onBlur={this.isValid} />
                                </div>
                                <div className="col-xs-12 col-sm-2 col-md-2 col-lg-2" style={{ paddingRight: '2px' }} >
                                    <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.debitMDAC2} onChange={this.handleChange} name="debitMDAC2" id="debitMDAC2" onBlur={this.isValid} />
                                </div>
                                <div className="col-xs-12 col-sm-3 col-md-3 col-lg-3" style={{ paddingRight: '2px' }}>
                                    <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.debitMDAC3} onChange={this.handleChange} name="debitMDAC3" id="debitMDAC3" onBlur={this.isValid} />
                                </div>
                                <div className="col-xs-12 col-sm-2 col-md-2 col-lg-2" style={{ paddingRight: '2px' }} >
                                    <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.debitMDAC4} onChange={this.handleChange} name="debitMDAC4" id="debitMDAC4" onBlur={this.isValid} />
                                </div>
                            </div>
                        </div>
                        <div className="clearfix visible-sm visible-md"> </div>
                        <div className="clearfix  visible-lg"></div>

                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Debit Amount</span>   <br />
                            <div className="row no-gutter">
                                <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                    <input type="text" className="form-control" disabled style={{ marginLeft: '-3px' }} value="INR" onChange={this.handleChange} name="mrgnLienAmt1" id="mrgnLienAmt1" />
                                </div>
                                <div className="col-xs-9 col-sm-9 col-md-9 col-lg-9" >
                                    <input type="number" className="form-control" value={this.state.mrgnLienAmt} onChange={this.handleChange} name="mrgnLienAmt" id="mrgnLienAmt" />
                                </div>
                            </div>
                        </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">MD Number</span>&nbsp;   <br />
                            <select className="form-control selectCss" onChange={this.handleInputChange} name="lMDData.acctPdTp" id="lMDData.acctPdTp">
                                <option value="">Please Select</option>
                                <option value="lMDData.acctPdTp">TBC</option>
                            </select>
                        </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Treasury Rate</span>&nbsp;   <br />
                            <input type="text" className="form-control" maxLength="12" value={this.state.tRate} onChange={this.handleChange} name="tRate" id="tRate" />
                        </div>
                        <div className="clearfix visible-sm visible-md"> </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Maintain MD</span>
                            <a className="pull-right" data-toggle="modal" data-target="#maintainMD" style={{ color: 'black', textDecoration: 'underline' }}>Maintain MD</a>
                            <div className="modal fade" id="maintainMD" role="dialog" >
                                <div className="modal-dialog modal-lg">
                                    <div className="modal-content">
                                        <div className="modal-header">
                                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                                            <h4 className="modal-title">Internal Information</h4>
                                        </div>
                                        <div className="modal-body" style={{ height: "400px" }}>
                                            <div className="row">
                                                <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-4">
                                                    <span className="label-margin-below">MD Account</span> &nbsp;  <br />
                                                    <div className="row no-gutter">
                                                        <div className="col-xs-12 col-sm-2 col-md-2 col-lg-2" style={{ paddingRight: '2px' }}>
                                                            <input type="text" className="form-control" value={this.state.mdAccount} onChange={this.handleChange} name="mdAccount" id="mdAccount" />
                                                        </div>
                                                        <div className="col-xs-12 col-sm-3 col-md-3 col-lg-3" style={{ paddingRight: '2px' }}>
                                                            <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.mdAccount1} onChange={this.handleChange} name="mdAccount1" id="mdAccount1" />
                                                        </div>
                                                        <div className="col-xs-12 col-sm-2 col-md-2 col-lg-2" style={{ paddingRight: '2px' }} >
                                                            <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.mdAccount2} onChange={this.handleChange} name="mdAccount2" id="mdAccount2" />
                                                        </div>
                                                        <div className="col-xs-12 col-sm-3 col-md-3 col-lg-3" style={{ paddingRight: '2px' }}>
                                                            <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.dmdAccount3} onChange={this.handleChange} name="mdAccount3" id="mdAccount3" />
                                                        </div>
                                                        <div className="col-xs-12 col-sm-2 col-md-2 col-lg-2" style={{ paddingRight: '2px' }} >
                                                            <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.mdAccount4} onChange={this.handleChange} name="mdAccount4" id="mdAccount4" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-4">
                                                    <span className="label-margin-below">MD Rate</span>  <br />
                                                    <input type="text" className="form-control" value={this.state.mdRate} onChange={this.handleChange} name="mdRate" id="mdRate" />

                                                </div>


                                                <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-4">
                                                    <span className="label-margin-below">MD Amount</span> &nbsp;  <br />
                                                    <div className="row no-gutter" >
                                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                                            <input type="text" className="form-control" style={{ marginLeft: "-3px" }} value={this.state.debitAmount} onChange={this.handleChange} name="debitAmount" id="debitAmount" />
                                                        </div>
                                                        <div className="col-xs-9 col-sm-9 col-md-9 col-lg-8" >
                                                            <input type="text" className="form-control" value={this.state.debitAmount1} onChange={this.handleChange} name="debitAmount1" id="debitAmount1" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="clearfix visible-lg"></div>
                                                <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-4">
                                                    <span className="label-margin-below">Period</span>&nbsp;   <br />
                                                    <div className="row">
                                                        <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                                            <input type="text" className="form-control" value={this.state['iMCCtrlLmtData.lmtType']} onChange={this.handleChange} name="iMCCtrlLmtData.lmtType" id="iMCCtrlLmtData.lmtType" />
                                                        </div>
                                                        <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                                            <select className="form-control selectCss" onChange={this.handleInputChange} name="lMDData.acctPdTp" id="lMDData.acctPdTp">
                                                                <option value="">Please Select</option>
                                                                <option value="lMDData.acctPdTp">TBC</option>
                                                            </select>
                                                        </div>
                                                    </div>


                                                </div>

                                                <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-4">
                                                    <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Due Date</span> &nbsp;<span style={{ color: 'red' }}>*</span>  <br />
                                                    <DateField className="form-control" dateFormat="YYYY-MM-DD" forceValidDate={true} defaultValue={moment('2017-07-05')} maxDate={moment()} name="dateofIssue" id="dateofIssue">
                                                        <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} weekNumbers={true} weekStartDay={0} />
                                                    </DateField>
                                                    <ErrorDisplay errors={this.state.errors} fieldName='dateofIssue' className='errorClass' />
                                                </div>

                                                <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-4">

                                                    <span className="label-margin-below">Net New Account</span> &nbsp;  <br />
                                                    <input type="text" className="form-control" value={this.state.mdRate} onChange={this.handleChange} name="mdRate" id="mdRate" />
                                                </div>
                                                <div className="clearfix visible-lg"></div>
                                                <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-4">

                                                    <span className="label-margin-below">DR/CR Account</span>
                                                    <a className="pull-right" data-toggle="modal" data-target="#maintainMD" style={{ color: 'grey', textDecoration: 'underline' }}>convert</a>
                                                    &nbsp;  <br />
                                                    <div className="row no-gutter">
                                                        <div className="col-xs-12 col-sm-2 col-md-2 col-lg-2" style={{ paddingRight: '2px' }}>
                                                            <input type="text" className="form-control" value={this.state.mdAccount} onChange={this.handleChange} name="mdAccount" id="mdAccount" />
                                                        </div>
                                                        <div className="col-xs-12 col-sm-3 col-md-3 col-lg-3" style={{ paddingRight: '2px' }}>
                                                            <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.mdAccount1} onChange={this.handleChange} name="mdAccount1" id="mdAccount1" />
                                                        </div>
                                                        <div className="col-xs-12 col-sm-2 col-md-2 col-lg-2" style={{ paddingRight: '2px' }} >
                                                            <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.mdAccount2} onChange={this.handleChange} name="mdAccount2" id="mdAccount2" />
                                                        </div>
                                                        <div className="col-xs-12 col-sm-3 col-md-3 col-lg-3" style={{ paddingRight: '2px' }}>
                                                            <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.dmdAccount3} onChange={this.handleChange} name="mdAccount3" id="mdAccount3" />
                                                        </div>
                                                        <div className="col-xs-12 col-sm-2 col-md-2 col-lg-2" style={{ paddingRight: '2px' }} >
                                                            <input type="text" className="form-control" onFocus={this.removeError1} value={this.state.mdAccount4} onChange={this.handleChange} name="mdAccount4" id="mdAccount4" />
                                                        </div>
                                                    </div>

                                                </div>

                                                <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-4">
                                                    <span className="label-margin-below">COF/VOF</span>  <br />
                                                    <input type="text" className="form-control" value={this.state.mdRate} onChange={this.handleChange} name="mdRate" id="mdRate" />

                                                </div>
                                                <div className="clearfix visible-sm visible-md visible-lg"></div>

                                                <div className="btn-toolbar" style={{ marginLeft: '15px', marginTop: '20px' }}>
                                                    <button className="btn btn-green"><embed className="icon" src="icons/go.svg" alt="" /><span className="buttonLabel">Continue</span></button>
                                                    <button className="btn btn-grey"><embed className="icon" src="icons/default.svg" alt="" /><span className="buttonLabel">Default</span></button>
                                                    <button className="btn btn-grey"><embed className="icon" src="icons/exit.svg" alt="" /><span className="buttonLabel">Exit</span></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-xs-4 col-sm-5 col-md-6 col-lg-6">
                                    <input type="radio" name="mDMaintnFlg" id="mDMaintnFlg" value="Standard" onChange={this.handleInputChange} />Yes
                                </div>
                                <div className="col-xs-8 col-sm-7 col-md-6 col-lg-6">
                                    <input type="radio" name="mDMaintnFlg" id="mDMaintnFlg" value="Premium" onFocus={this.removeError} onChange={this.handleInputChange} checked />No
                                </div>
                            </div>

                        </div>
                        <div className="clearfix visible-lg"></div>

                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">GTE Line %</span>&nbsp;   <br />
                            <input type="text" className="form-control" maxLength="12" value={this.state.tRate} onChange={this.handleChange} name="dCLinPct" id="dCLinPct" />

                        </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">GTE Line Amount</span>   <br />

                            <div className="row no-gutter">
                                <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                    <input type="text" className="form-control" disabled style={{ marginLeft: '-3px' }} value="INR" onChange={this.handleChange} name="dCLinAmt1" id="dCLinAmt1" />
                                </div>

                                <div className="col-xs-9 col-sm-9 col-md-9 col-lg-9" >
                                    <input type="number" required={internalInfoValidate ? internalInfoValidate.dCLinAmt.mandatory : false}
                                        onFocus={this.removeError} onBlur={this.addError} className="form-control" value={this.state.dCLinAmt} onChange={this.handleChange} name="dCLinAmt" id="dCLinAmt" />
                                </div>
                            </div>
                            <ErrorDisplay errors={this.state.errors} fieldName='dCLinAmt' className='errorClass' />

                        </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Control Limit</span>   <br />
                            <div className="row">
                                <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <input type="text" className="form-control" required={internalInfoValidate ? internalInfoValidate['ctrlLmtData.lmtType'].mandatory : false}
                                        onFocus={this.removeError} onBlur={this.addError} value={this.state['ctrlLmtData.lmtType']} onChange={this.handleChange} name="ctrlLmtData.lmtType" id="ctrlLmtData.lmtType" />
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <input type="text" className="form-control" required={internalInfoValidate ? internalInfoValidate['ctrlLmtData.lmtLine'].mandatory : false}
                                        onFocus={this.removeError} onBlur={this.addError} value={this.state['ctrlLmtData.lmtLine']} onChange={this.handleChange} name="ctrlLmtData.lmtLine" id="ctrlLmtData.lmtLine" />
                                </div>
                            </div>
                            <ErrorDisplay errors={this.state.errors} fieldName='ctrlLmtData.lmtType' className='errorClass' />
                            <ErrorDisplay errors={this.state.errors} fieldName='ctrlLmtData.lmtLine' className='errorClass' />
                        </div>
                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <span className="label-margin-below">Group Limit</span>   <br />
                            <div className="row">
                                <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <input type="text" className="form-control" required={internalInfoValidate ? internalInfoValidate['grpLmtData.lmtType'].mandatory : false}
                                        onFocus={this.removeError} onBlur={this.addError} value={this.state['grpLmtData.lmtType']} onChange={this.handleChange} name="grpLmtData.lmtType" id="grpLmtData.lmtType" />
                                </div>
                                <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <input type="text" className="form-control" required={internalInfoValidate ? internalInfoValidate['grpLmtData.lmtLine'].mandatory : false}
                                        onFocus={this.removeError} onBlur={this.addError} value={this.state['grpLmtData.lmtLine']} onChange={this.handleChange} name="grpLmtData.lmtLine" id="grpLmtData.lmtLine" />
                                </div>
                            </div>
                            <ErrorDisplay errors={this.state.errors} fieldName='grpLmtData.lmtType' className='errorClass' />
                            <ErrorDisplay errors={this.state.errors} fieldName='grpLmtData.lmtLine' className='errorClass' />

                        </div>
                        <div className="clearfix visible-lg"></div>



                        <div className="row-margin col-xs-12 col-sm-4 col-md-4 col-lg-3">
                            <a className="pull-left blackUnderline" data-toggle="modal" data-target="#standByDc">Stand By DC</a>
                            <div className="modal fade" id="standByDc" role="dialog">
                                <div className="modal-dialog modal-lg">
                                    <div className="modal-content">
                                        <div className="modal-body">
                                            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                                <button type="button" className="close" data-dismiss="modal">&times;</button>
                                                <span className="Muli-Bold" style={{ fontSize: '16px' }}>StandBy DC</span>
                                                <hr style={{ borderColor: '#919191', marginTop: '1px' }} />
                                            </div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Evergreen Indicator<span style={{ color: 'red' }}>*</span></span>
                                                <div className="row">
                                                    <div className="col-xs-4 col-sm-5 col-md-6 col-lg-6">
                                                        <input type="radio" />Yes
                                                    </div>
                                                    <div className="col-xs-8 col-sm-7 col-md-6 col-lg-6">
                                                        <input type="radio" />No
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Notification Period<span style={{ color: 'red' }}>*</span></span>
                                                <input type="text" className="form-control" />
                                            </div>
                                            <div className="clearfix visible-md visible-sm"></div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Final Expiry Date<span style={{ color: 'red' }}>*</span></span>
                                                <DateField className="form-control" dateFormat="YYYY-MM-DD" forceValidDate={true} defaultValue={moment('2017-07-05')} maxDate={moment()} name="dateofIssue" id="dateofIssue">
                                                    <DatePicker navigation={true} locale="en" forceValidDate={true} highlightWeekends={true} weekNumbers={true} weekStartDay={0} />
                                                </DateField>
                                            </div>
                                            <div className="clearfix visible-lg"></div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Extension Period<span style={{ color: 'red' }}>*</span></span>
                                                <input type="text" className="form-control" />
                                            </div>
                                            <div className="clearfix visible-md visible-sm"></div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Receivable Frequency</span>
                                                <input type="text" className="form-control" />
                                            </div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Receivable Basis</span>
                                                <select className="form-control selectCss" />
                                            </div>
                                            <div className="clearfix visible-md visible-sm visible-lg"></div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Commission Rate</span>
                                                <div className="row no-gutter">
                                                    <div className="col-xs-11 col-sm-11 col-md-11 col-lg-11">
                                                        <input type="text" className="form-control" />
                                                    </div>
                                                    <div className="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                                                        <span style={{ position: 'relative', top: '20px', marginLeft: '5px' }}>%</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Overseas Commission Rate</span>
                                                <div className="row no-gutter">
                                                    <div className="col-xs-11 col-sm-11 col-md-11 col-lg-11">
                                                        <input type="text" className="form-control" />
                                                    </div>
                                                    <div className="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                                                        <span style={{ position: 'relative', top: '20px', marginLeft: '5px' }}>%</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="clearfix visible-md visible-sm"></div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Flat Charge</span>
                                                <input type="text" className="form-control" />
                                            </div>
                                            <div className="clearfix visible-lg"></div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Overseas Flat Charge</span>
                                                <input type="text" className="form-control" />
                                            </div>
                                            <div className="clearfix visible-md visible-sm"></div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Minimun Commision Amount</span>
                                                <input type="text" className="form-control" />
                                            </div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Commission Collect At<span style={{ color: 'red' }}>*</span></span>
                                                <select className="form-control selectCss" />
                                            </div>
                                            <div className="clearfix visible-md visible-sm visible-lg"></div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Comm Calc Method<span style={{ color: 'red' }}>*</span></span>
                                                <select className="form-control selectCss" />
                                            </div>
                                            <div className="clearfix visible-lg"></div>
                                            <div className="clearfix visible-md visible-sm"></div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Incr/Decr Schedule</span>
                                                <div className="row">
                                                    <div className="col-xs-4 col-sm-5 col-md-6 col-lg-6">
                                                        <input type="radio" />Yes
                                                    </div>
                                                    <div className="col-xs-8 col-sm-7 col-md-6 col-lg-6">
                                                        <input type="radio" />No
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Increase/Decrease Schedule Info.</span>
                                                <br />
                                                <a className="row-margin blackUnderline">Add Information</a>
                                            </div>
                                            <div className="clearfix visible-md visible-sm"></div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Receivable Schedule</span>
                                                <br />
                                                <a className="row-margin blackUnderline">Receivable Schedule Information</a>
                                            </div>
                                            <div className="clearfix visible-lg"></div>                                            
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Charge Dr Account</span>
                                                <div className="row no-gutter">
                                                    <div className="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                                                        <input type="text" className="form-control" />
                                                    </div>
                                                    <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3" style={{ paddingLeft: '2px', paddingRight: '2px' }}>
                                                        <input type="text" className="form-control" />
                                                    </div>
                                                    <div className="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                                                        <input type="text" className="form-control" />
                                                    </div>
                                                    <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3" style={{ paddingLeft: '2px', paddingRight: '2px' }}>
                                                        <input type="text" className="form-control" />
                                                    </div>
                                                    <div className="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                                                        <input type="text" className="form-control" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">Advice Send To<span style={{ color: 'red' }}>*</span></span>
                                                <input type="text" className="form-control" />
                                                <input type="text" className="form-control" />
                                                <input type="text" className="form-control" />
                                                <input type="text" className="form-control" />
                                                <input type="text" className="form-control" />
                                            </div>
                                            <div className="clearfix visible-sm visible-md"/>
                                            <div className="row-margin col-xs-12 col-sm-6 col-md-6 col-lg-4">
                                                <span className="label-margin-below">By Order Of<span style={{ color: 'red' }}>*</span></span>
                                                <input type="text" className="form-control" />
                                                <input type="text" className="form-control" />
                                            </div>
                                            <div className="clearfix visible-md visible-sm visible-lg"></div>
                                            <div className="btn-toolbar" style={{ marginLeft: '15px', marginTop: '25px' }}>
                                                <button type="button" className="btn btn-green"><embed className="icon" src="icons/go.svg" alt="" /><span className="buttonLabel">Continue</span></button>
                                                <button type="button" className="btn btn-grey"><embed className="icon" src="icons/default.svg" alt="" /><span className="buttonLabel">Default</span></button>
                                                <button type="button" className="btn btn-grey"><embed className="icon" src="icons/exit.svg" alt="" /><span className="buttonLabel">Exit</span></button>
                                            </div>
                                        </div>
                                        <div className="modal-footer" style={{ borderTop: '0px' }}>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row">  </div>
                        </div>
                    </div>
                </form>
            </div >
        );
    }
}

function mapStateToProps(store) {
    return {
        recordingDropDownData: store.recordingReducer.recordingDropDownData
    }
}

export default connect(mapStateToProps)(InternalInfo);

