import React from 'react';
import { render } from 'react-dom';
import CustomTabContent from "./TabContent.jsx";
import './TabStyles.css';
import {connect} from "react-redux";
import * as Actions from "./Actions/wolfAction"

class CustomLevelTabs extends React.Component {

    constructor(props) {
        super(props);
        classThis = this;
        this.changeAddClass = this.changeAddClass.bind(this);
        this.sendToNextLevel=this.sendToNextLevel.bind(this);
    }

    componentDidMount() {
        this.props.onRef1(this)
    }

    validateForRationale() {
        if (this.props.user == 1){
            if (this.firstTab.validateForRationale()){
                return true;
            }
            else{
                return false;
            }
        }
        else if (this.props.user == 2) {
            if (this.secondTab.validateForRationale()){
                return true;
            }
            else{
                return false;
            }
        }
        else if (this.props.user == 3) {
            if (this.thirdTab.validateForRationale()){
                return true;
            }
            else{
                return false;
            }
        }
    }

    sendToNextLevel(){
        this.props.dispatch(Actions.sendToNextQueue(2));
    }

    checkforTextArea(){
        if (this.props.user == 1){
            if (this.firstTab.checkforTextArea()){
                return true;
            }
            else{
                return false;
            }
        }
        else if (this.props.user == 2) {
            if (this.secondTab.checkforTextArea()){
                return true;
            }
            else{
                return false;
            }
        }
        else if (this.props.user == 3) {
            if (this.thirdTab.checkforTextArea()){
                return true;
            }
            else{
                return false;
            }
        }
    }

    changeAddClass(event) {
        var element = event.target

        if (element.className.toString().indexOf("plus") > -1)
            element.className = "glyphicon glyphicon-minus"
        else if (element.className.toString().indexOf("minus") > -1)
            element.className = "glyphicon glyphicon-plus"
    }

     disableTab(val){
        classThis.props.dispatch(Actions.exceptionOnTheWay(val))
    }

    getDetails(){
        return {
            "field": this.props.tabdata.fieldName + " " + this.props.tabdata.fieldData,
            "worldCheckId": this.props.tabdata.worldCheckId,
            "name":this.props.tabdata.name,
            "country":this.props.tabdata.country,
            "origin":this.props.tabdata.origin,
            "designation":this.props.tabdata.destination,
            "type":this.props.tabdata.type,
            "additionalInfo":{
                "nameSynonyms":this.props.tabdata.nameSynonyms,
                "addtInfo":this.props.tabdata.addtInfo
            },
                "tabData1" : this.firstTab.getDetails(),
                "tabData2" : this.secondTab.getDetails(),
                "tabData3" : this.thirdTab.getDetails(),
        }
    }
     
    render() {
        
        var addiId = "additional" + this.props.addId;
        var addTarget = "#" + addiId;
        var span = ""
        var rows = [];
        this.props.tabdata.additionalInfo.nameSynonyms.forEach((item, index) => {
            rows.push(<span key={index}>{item}<br /></span>);
        })

        var level1Href = "1";
        var level2Href = "2";
        var level2bHref = "3";

        var tabActive = ["","",""]

        if (this.props.user == 1) {
            level2Href = ""
            level2bHref = ""
            tabActive[0] = " in active"
        }
        else if (this.props.user == 2) {
            level1Href = ""
            level2bHref = ""
            tabActive[1] = " in active"
        }
        else if (this.props.user == 3) {
            level1Href = ""
            tabActive[2] = " in active"
            if(this.props.activeClass2 == "disabled")
                level2Href = ""
        }

        if(rows.length==0 && this.props.tabdata.additionalInfo.addtInfo===""){
            span=<i className="glyphicon glyphicon-plus" ></i>
        }
        else{
            span=<i id={"icon"+(this.props.addId*17)} onClick={this.changeAddClass} data-toggle="collapse" data-target={addTarget} className="glyphicon glyphicon-plus"></i>
        }

        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="col-md-6">
                            <br />

                            <div className="row">
                                <div className="col-md-3"> Field :</div>
                                <div className="col-md-6">{this.props.tabdata.fieldName}</div>
                            </div>
                            <div className="row">
                                <div className="col-md-3"> {this.props.tabdata.fieldData}</div>
                            </div>
                            <div className="row">
                                <div className="col-md-12">
                                    According to World-check ID {this.props.tabdata.worldCheckId}, the Black list entry is
                           </div>
                            </div>
                            <div className="row">
                                <div className="col-md-3"> Name:</div>
                                <div className="col-md-6">{this.props.tabdata.name}</div>
                            </div>
                            <div className="row">
                                <div className="col-md-3"> Country:</div>
                                <div className="col-md-6">{this.props.tabdata.country}</div>
                            </div>
                            <div className="row">
                                <div className="col-md-3"> Origin:</div>
                                <div className="col-md-6">{this.props.tabdata.origin}</div>
                            </div>
                            <div className="row">
                                <div className="col-md-3"> Designation:</div>
                                <div className="col-md-6">{this.props.tabdata.designation}</div>
                            </div>
                            <div className="row">
                                <div className="col-md-3">Type:</div>
                                <div className="col-md-6">{this.props.tabdata.type}</div>
                            </div>
                            <br />
                            <br />

                            {span}<span  style={{marginLeft:"5px",fontWeight:"bold",color:"#FF69B4"}}>Additional Information</span>
                        
                            <div id={addiId} className="collapse">
                                <div className="row">
                                    <div className="col-md-3"> Name synonyms :</div>
                                    <div className="col-md-6">{rows}</div>

                                </div>
                                <div className="row">
                                    <div className="col-md-3">  Addt Info : </div>
                                    <div className="col-md-6">{this.props.tabdata.additionalInfo.addtInfo}</div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6" style={{ marginLeft: "-20px" }}>
                            <ul className="nav nav-tabs new" style={{ marginTop: "20px" }} >
                                <li id={"firstTab" + this.props.addId} className={this.props.activeClass1}>
                                    {level1Href == "" ? <a>Level 1</a> : <a data-toggle="tab" href={"#level1" + this.props.addId}>Level 1</a>}</li>
                                <li id={"secondTab" + this.props.addId} className={this.props.activeClass2}>
                                    {level2Href == "" ? <a>Level 2</a> : <a data-toggle="tab" href={"#level2" + this.props.addId}>Level 2</a>}</li>
                                <li id={"thirdTab" + this.props.addId} className={this.props.activeClass3}>
                                    {level2bHref == "" ? <a>Level 2B</a> : <a data-toggle="tab" href={"#level3" + this.props.addId}>Level 2B</a>}</li>


                                    <li style={{float:"right",marginRight:"90px",marginTop:"15px"}}>
                                    {this.props.check ?
                                     <span><input type="checkbox" value="duplication" checked/>
                                     <label style={{marginLeft:"5px",fontWeight:"normal",color:"red"}}>Duplication</label></span>
                                     : <span><input type="checkbox" value="duplication"/>
                                     <label style={{marginLeft:"5px",fontWeight:"normal"}}>Duplication</label></span>
                                     }
                                    </li>
                                </ul>

                            <div className="tab-content" style={{ border: "1px solid #868686 ", width: "475px", background: "white" }}>
                                <div id={"level1" + this.props.addId} className={"tab-pane fade"+tabActive[0]}>
                                    <CustomTabContent style={{ marginLeft: "-50px" }}
                                        onRef2={ref => (this.firstTab = ref)}
                                        id={"custom1"+this.props.addId}
                                        {...this.props}
                                    />
                                </div>
                                <div id={"level2" + this.props.addId} className={"tab-pane fade"+tabActive[1]}>
                                    <CustomTabContent
                                        onRef2={ref => (this.secondTab = ref)} 
                                        id={"custom2"+this.props.addId}
                                        disableTab = {this.disableTab}
                                        {...this.props}
                                        />
                                </div>
                                <div id={"level3" + this.props.addId} className={"tab-pane fade"+tabActive[2]}>
                                    <CustomTabContent
                                        onRef2={ref => (this.thirdTab = ref)} 
                                        id={"custom3"+this.props.addId}
                                        disableTab = {this.disableTab}
                                        {...this.props}
                                        />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        );
    }

}
function mapStateToProps(store){
    return {
        user : store.wolfReducer.user,
        activeClass1 :store.wolfReducer.activeClass1,
        activeClass2 :store.wolfReducer.activeClass2,
        activeClass3 :store.wolfReducer.activeClass3,
        status : store.wolfReducer.status
    }
}

export default connect(mapStateToProps)(CustomLevelTabs);
