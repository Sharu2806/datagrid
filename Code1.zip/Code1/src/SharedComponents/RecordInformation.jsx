import React from 'react';

function RecordInformation(props) {
    return (
        <div className="well" style={{ backgroundColor: 'white', border: '1px solid #e3e3e3', borderRadius: '5px', minHeight: '138px', color: 'black' }}>
            <div className="row">
                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 Muli-SemiBold">
                    <embed src="icons/work-item.svg" alt="" height="36px" width="36px" />
                    <span style={{ fontSize: '20px', position: 'relative', top: '-10px' }}>WORK ITEM - {props.gwisId}</span>
                </div>
            </div>
            {   props.processingType && 
                <div className="row" style={{ fontSize: '16px' }}>
                    <br />
                    <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">Process Type</span> - {props.processingType}
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-6 col-lg-5">
                        <span className="Muli-SemiBold">Target Date of Completion</span> - &nbsp; 
                        {props.targetDate}
                    </div>
                </div>
            }
        </div>
    );
}

export default RecordInformation;
// '#00b1d5'