import React, { Component } from 'react';

class ImportBillRecordingInformationAfterDC extends Component {
    render() {
        return (
            <div className="well" style={{ backgroundColor: 'white', border: '1px solid #e3e3e3', borderRadius: '5px', minHeight: '138px', color: 'black' }}>
                <div className="row">
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 Muli-SemiBold">
                        <embed src="icons/work-item.svg" alt="" height="36px" width="36px" />
                        <span style={{ fontSize: '24px', position: 'relative', top: '-10px' }}>
                            Bill No. - {this.props.billNo}
                        </span>
                        <span style={{ fontSize: '24px', position: 'relative', top: '-10px',marginLeft:'250px' }}>
                           Target Date - 13 July 2017 12:00:00
                        </span>
                    </div>
                </div>
                <br />
                <div className="row" style={{ fontSize: '14px' }}>
                    <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">DC No</span> - {this.props.dcNo}
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">A/C No</span> - {this.props.acNo}
                    </div>
                    <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">A/C Name</span> - Dennis
                    </div>
                      <div className="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                        <span className="Muli-SemiBold">Deal No</span> - DK13-01749
                    </div>
                </div>
            </div>
        );
    }
}

export default ImportBillRecordingInformationAfterDC;