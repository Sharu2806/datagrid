import React from 'react';

import ErrorDisplay from '../../../SharedComponents/ErrorDisplay';

var indexInfoValidate = {
    "customerAccountNumber": { mandatory: true },
    "customerName": { mandatory: true },
    "applicationDateTime": { mandatory: true },
    "transactionCurrency": { mandatory: true },
    "transactionAmount": { mandatory: true },
    "dcNumber":{mandatory: true}
}

class IndexingInformation extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            nameSearch:'',
            customerAccountNumber: '',
            applicationDateTime: '',
            customerName: '',
            applicationReference: '',
            transactionCurrency: '',
            transactionAmount: 0,
            captureUnderProduct: '',
            dcNumber:'',
            billReferenceNumber:'',
            sgNumber: '',
            otherBankReference: '',
            ghoCustClass:'',
            errors: []
        };

        this.handleInputChange = this.handleInputChange.bind(this);
        this.saveData = this.saveData.bind(this);
        this.fetchData = this.fetchData.bind(this);
        this.addError = this.addError.bind(this);
        this.removeError = this.removeError.bind(this);
        this.getApplicationDate = this.getApplicationDate.bind(this);
    }


    fetchData() {
        let obj = this.props.inputData;
        this.setState({
            ...obj
        }
        );
    }

    saveData() {
        this.props.saveIndexingInformationData(this.state);
    }
    componentDidMount() {
        this.props.onRef(this);

        fetch('json/ImportBillError.json', {
            method: 'GET'
        }).then(result => result.json())
            .then(body => this.saveError(body));
    }

    componentWillUnmount() {
        this.props.onRef(undefined)
    }


    componentWillMount() {
        this.setState({
            ...this.props.inputData
        });
    }

    //storing error json in a local variable
    saveError(value) {
        this.errorFromJson = value;
        this.props.onRef(this);

    }

    handleInputChange(event) {
        this.removeError(event);
        this.setState({ [event.target.name]: event.target.value });
    }
    addError(event) {
        let target;
        if (event.type ==='blur') {
            event.preventDefault();
            target = event.target;
        } else {
            target = event;
        }
        let name = target.name;
        let value = target.value;
        let error;
        if (target.required && !value) {
            error = {
                fieldName: name,
                error: this.errorFromJson[name].required,
            };
            this.pushErrorNew(error);
        } else if (target.pattern && value && !new RegExp(target.pattern).test(value)) {
            error = {
                fieldName: name,
                error: this.errorFromJson[name].inValid,
            };
            this.pushError(error);
        }
    }
    pushError(error) {
        this.setState((prevState) => {
            let tempErrorHolder = prevState.errors;
            tempErrorHolder = tempErrorHolder.filter((item) =>
                item.fieldName !== error.fieldName);
            tempErrorHolder.push(error);
            return { errors: tempErrorHolder }
        });
    }

    pushErrorNew(error) {
        let tempErrorHolder = this.state.errors;
        tempErrorHolder.push(error);

        this.setState({ errors: tempErrorHolder });
    }
    removeError(event) {
        let target;
        event.preventDefault();
        target = event.target;

        let tempErrorHolder = this.state.errors;
        let indexValue = -1;
        for (let i = 0; i < tempErrorHolder.length; i++) {
            if (tempErrorHolder[i].fieldName === target.name) {
                indexValue = i;
                break;
            }
        }
        if (indexValue > -1) {
            tempErrorHolder.splice(indexValue, 1);
            this.setState({
                errors: tempErrorHolder
            });
        }
    }

    getApplicationDate(event)
    {
        this.addError(event);
      
        if(Date.parse(this.state.applicationDateTime) > Date.parse(this.props.commonInfoData))
        {
           let error = {
                fieldName: event.target.name,
                error: this.errorFromJson[event.target.name].inValid,
            };
            this.pushError(error);
        }


    }
    

    render() {
        return (
            <form>
               
                     <div className="row row-margin">
                         <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Name Search</span><br />
                        <input 
                            type="search" 
                            className="form-control"  
                            value={this.state.nameSearch} 
                            onChange={this.handleInputChange} 
                            name="nameSearch" id="nameSearch" />
                        
                        </div>

                         <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">GHO Cust Class</span><br />
                        <input 
                            type="ghoCustClass" 
                            className="form-control"  
                            value={this.state.ghoCustClass} 
                            onChange={this.handleInputChange}
                            name="ghoCustClass" id="ghoCustClass" />
                        
                        </div>


                        </div>

                   <div  className="row row-margin">

                   <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Customer Account Number</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                        <input 
                            type="text" 
                            className="form-control"  
                            value={this.state.customerAccountNumber} 
                            onChange={this.handleInputChange} 
                            required={indexInfoValidate ? indexInfoValidate.customerAccountNumber.mandatory : false} 
                            onBlur={this.addError} 
                            onFocus={this.removeError} 
                            name="customerAccountNumber" id="customerAccountNumber"  
                            pattern="^[0-9]{1,3}-[0-9]{1,6}-[0-9]{1,6}$"/>
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName='customerAccountNumber' 
                            className='errorClass' />
                    </div>                    

                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Customer Name</span><br />
                        <input 
                            type="text" 
                            className="form-control"  
                            value={this.state.customerName} 
                            onChange={this.handleInputChange}
                            required={indexInfoValidate ? indexInfoValidate.customerName.mandatory : false} 
                            onBlur={this.addError} 
                            onFocus={this.removeError}
                            name="customerName" id="customerName" pattern="^[a-zA-Z0-9]*$" />
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName="customerName" 
                            className='errorClass'/>
                    
                    </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Application Reference</span><br />
                        <input 
                            type="text" 
                            className="form-control" 
                            value={this.state.applicationReference} 
                            onChange={this.handleInputChange} 
                            name="applicationReference" id="applicationReference" />
                         <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName="applicationReference" />
                    </div>

                    </div>
                    
                     <div className="row row-margin">

                     <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Application Received Date Time</span><br />
                        <input 
                            type="text" 
                            className="form-control" 
                            value={this.state.applicationDateTime} 
                            onChange={this.handleInputChange} 
                            name="applicationDateTime" id="applicationDateTime" />
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName="applicationDateTime" />
                    </div>

                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Transaction Currency</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                        <select 
                            className="form-control selectCss" 
                            onFocus={this.removeError} 
                            onBlur={this.addError} 
                            required={indexInfoValidate ? 
                            indexInfoValidate.transactionCurrency.mandatory : false} 
                            value={this.state.transactionCurrency} 
                            onChange={this.handleInputChange} 
                            name="transactionCurrency" id="transactionCurrency">
                        <option value="">Please Select</option>
                        <option value="INR">INR</option>
                        <option value="HKD">HKD</option>
                        <option value="USD">USD</option>
                        </select>
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName='transactionCurrency' 
                            className='errorClass' />
                    </div>
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Transaction Amount</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                        <input 
                            type="number" 
                            placeholder="0" 
                            className="form-control"  
                            value={this.state.transactionAmount} 
                            onChange={this.handleInputChange} 
                            required={indexInfoValidate ? indexInfoValidate.transactionAmount.mandatory : false} 
                            onBlur={this.addError} 
                            onFocus={this.removeError} 
                            name="transactionAmount" id="transactionAmount" 
                            pattern="^[0-9]*$" 
                            min="0"/>
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName='transactionAmount' 
                            className='errorClass' />
                    </div>  


                    </div>

                    <div className="row row-margin">
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Capture Under Product</span><br />
                        <select 
                            className="form-control selectCss"  
                            value={this.state.captureUnderProduct} 
                            onChange={this.handleInputChange} 
                            name="captureUnderProduct" id="captureUnderProduct">
                        <option value="">Please Select</option>
                        <option value="FNG">FNG</option>
                        <option value="APG">APG</option>
                        <option value="BBG">BBG</option>
                        <option value="PMG">PMG</option>
                        </select>
                        
                    </div>  

                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">DC Number</span><br />
                        <input 
                            type="text" 
                            className="form-control" 
                            value={this.state.dcNumber} 
                            onChange={this.handleInputChange}
                            required={indexInfoValidate ? indexInfoValidate.dcNumber.mandatory : false} 
                            onBlur={this.addError} 
                            onFocus={this.removeError} 
                            pattern="^[a-zA-Z0-9]*$"
                            name="dcNumber" id="dcNumber" />
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName='dcNumber' 
                            className='errorClass' />
                    </div> 

                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Bill Reference Number</span><br />
                        <input 
                            type="text" 
                            className="form-control" 
                            value={this.state.billReferenceNumber} 
                            onChange={this.handleInputChange}
                            onBlur={this.addError} onFocus={this.removeError} 
                            pattern="^[a-zA-Z0-9]*$"
                            name="billReferenceNumber" id="billReferenceNumber" />
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName='billReferenceNumber' 
                            className='errorClass' />
                    </div> 
                    </div>
                        <div className="row row-margin">
                    <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">SG Number</span><br />
                        <input 
                            type="text" 
                            className="form-control" 
                            value={this.state.sgNumber} 
                            onChange={this.handleInputChange}
                            onBlur={this.addError} onFocus={this.removeError} 
                            pattern="^[a-zA-Z0-9]*$"
                            name="sgNumber" id="sgNumber" />
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName='sgNumber' 
                            className='errorClass' />
                    </div> 

                     <div className="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                        <span className="label-margin-below">Other Bank Reference</span><br />
                        <input 
                            type="text" 
                            className="form-control"
                            value={this.state.otherBankReference} 
                            onChange={this.handleInputChange}  
                            pattern="^[a-zA-Z0-9]*$" 
                            onBlur={this.addError} 
                            onFocus={this.removeError} 
                            name="otherBankReference" id="otherBankReference" />
                        <ErrorDisplay 
                            errors={this.state.errors} 
                            fieldName='otherBankReference' 
                            className='errorClass' />
                    </div>
                    </div>
            </form>
        );
    }
}
export default (IndexingInformation);