import React, { Component } from 'react';
import { connect } from 'react-redux';

import RecordInformation from '../../SharedComponents/RecordInformation';
import BasicInformation from './BasicInformation/BasicInformation';
import CommonInformation from './CommonInformation/CommonInformation';
import IndexingInformation from './IndexingInformation/IndexingInformation';

import {
    fetchIndexingData,
    saveBasicInformationData,
    saveCommonInformationData,
    saveIndexingInformationData,
    sendData,
    getCustomerName
} from './IndexingImportBillActions';


class IndexingImportBill extends Component {

    constructor(props) {
        super(props);
         this.state = {
            updown:false
        }
        this.handleSaveClick = this.handleSaveClick.bind(this);
        this.handleTabClick = this.handleTabClick.bind(this);
        this.handleSubmitClick = this.handleSubmitClick.bind(this);

    }


    componentWillMount() {
        this.props.fetchIndexingData();
    }


    handleSaveClick() {
        let tabName = document.getElementById("indexingTabs").getElementsByClassName("active")[0].childNodes[0].getAttribute("href");
        let tabName2 = tabName.substring(1);
        this[tabName2].saveData();
    }

    handleTabClick(event) {
        let tabName = event.target.getAttribute("href");
        let tabName2 = tabName.substring(1);
        this[tabName2].fetchData();
    }

    handleSubmitClick() {
        this.props.sendData(this.props.allIndexingData)
    }

     changeUpDown(){
        this.setState({
            updown:!this.state.updown
        })
    }

    render() {
        return (
            <div className="row">
                <div className="panel panel-holding-tabs">
                    {/*The following code will be used to display some info regarding the current record*/}
                    {
                        this.props.allIndexingData &&
                        <RecordInformation
                            gwisId={this.props.allIndexingData.basicInformation.gwisId}
                            processingType={this.props.allIndexingData.commonInformation.processingType}
                            targetDate={this.props.allIndexingData.commonInformation.targetDate}
                        />
                    }

                    <ul id="indexingTabs" className="nav nav-tabs" onClick={this.handleTabClick} style={{ overflow: 'hidden', position: 'relative', top: '1px' }}>
                        <li className="active"><a data-toggle="tab" href="#basicInfo">Basic Info.</a></li>
                        <li><a data-toggle="tab" href="#commonInfo">Common Info.</a></li>
                        <li><a data-toggle="tab" href="#indexingInfo">Indexing Info.</a></li>
                    </ul>
                </div>
                <div className="tab-content" style={{ marginLeft: '30px', marginRight: '30px', minHeight:'400px' }}>
                    <div id="basicInfo" className="tab-pane fade in active">
                        {
                            this.props.allIndexingData &&
                            <BasicInformation
                                inputData={this.props.allIndexingData.basicInformation}
                                saveBasicInformationData={this.props.saveBasicInformationData}
                                onRef={ref => (this.basicInfo = ref)}
                            />
                        }
                    </div>
                    <div id="commonInfo" className="tab-pane fade">
                        {
                            this.props.allIndexingData &&
                            <CommonInformation
                                inputData={this.props.allIndexingData.commonInformation}
                                saveCommonInformationData={this.props.saveCommonInformationData}
                                onRef={ref => (this.commonInfo = ref)}
                            />
                        }
                    </div>
                    <div id="indexingInfo" className="tab-pane fade">
                        {
                            this.props.allIndexingData &&
                            <IndexingInformation
                                inputData={this.props.allIndexingData.indexingInformation}
                                commonInfoData={this.props.allIndexingData.commonInformation.channelDateTime}
                                saveIndexingInformationData={this.props.saveIndexingInformationData}
                                onRef={ref => (this.indexingInfo = ref)}
                            />
                        }
                    </div>
                </div>
                <div className="" style={{ backgroundColor: '#dedede', marginTop: '30px', paddingTop: '30px', paddingBottom: '30px'}}>
                    <div className="btn-toolbar" style={{marginLeft:'40px'}}>
                        <button className="btn btn-green" onClick={this.handleSaveClick}><embed className="icon" src="icons/save.svg" alt="" /><span className="buttonLabel">Save</span></button>
                        <button className="btn btn-green" onClick={this.handleSubmitClick}><embed className="icon" src="icons/send.svg" alt="" /><span className="buttonLabel">Send</span></button>
                        <button className="btn btn-grey"><embed className="icon" src="icons/hold.svg" alt="" /><span className="buttonLabel">Hold</span></button>
                        <button className="btn btn-default" style={{ backgroundColor: "#b6b6b6", color: "white" }}><embed className="icon" src="icons/repair.svg" alt="" /><span className="buttonLabel">Repair</span></button>
                        <button className="btn btn-grey"><embed className="icon" src="icons/open_image.svg" alt="" /><span className="buttonLabel">Open Image</span></button>
                        <button className="btn btn-grey"><embed className="icon" src="icons/cancel.svg" alt="" /><span className="buttonLabel">Cancel</span></button>
                        <button className="btn btn-grey"><embed className="icon" src="icons/assign.svg" alt="" /><span className="buttonLabel">Assign</span></button>
                        <button className="btn btn-grey"><embed className="icon" src="icons/copy.svg" alt="" /><span className="buttonLabel"> Copy</span></button>
                        <div  style={{ backgroundColor: "#333333"}}>
                        <div className="dropup">
                            <button className="btn btn-default dropdown-toggle" data-toggle="dropdown" style={{ backgroundColor: "#333333" ,color:"white"}} onClick={this.changeUpDown.bind(this)}>More
                           
                            {this.state.updown===true ? <span>&nbsp;&nbsp;&nbsp;&nbsp; <span className="glyphicon glyphicon-menu-down"></span></span> :  <span>&nbsp;&nbsp;&nbsp;&nbsp; <span className="glyphicon glyphicon-menu-up"></span></span>}
                                                         
                            </button>
                            <ul className="dropdown-menu pull-right" style={{ marginRight: "95px"}}>
                              <li><a><embed className="icon" src="icons/AML_Checking.svg" alt="" /><span className="buttonLabel">AML Checking</span></a></li>
                                <li className="divider" style={{backgroundColor: "white"}}></li>
                                <li><a><span className="buttonLabel">Open Image Type</span></a></li>
                                <li className="divider" style={{backgroundColor: "white"}}></li>
                                <li><a><span className="buttonLabel">Get Interaction</span></a></li>
                            </ul>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

const mapsStateToProps = (state) => {
    return {
        allIndexingData: state.indexingImportBillReducer
    };
};

const mapsDispatchToProps = (dispatch) => {
    return {
        fetchIndexingData: () => {
            dispatch(fetchIndexingData());
        },
        saveBasicInformationData: (obj) => {
            dispatch(saveBasicInformationData(obj));
        },
        saveCommonInformationData: (obj) => {
            dispatch(saveCommonInformationData(obj));
        },
        saveIndexingInformationData: (obj) => {
            dispatch(saveIndexingInformationData(obj));
        },
        sendData: (obj) => {
            dispatch(sendData(obj));
        }, getCustomerName: (acntNum) => {
            console.log("Data :: ", acntNum);
            dispatch(getCustomerName(acntNum));
        }
    };
};
export default connect(mapsStateToProps, mapsDispatchToProps)(IndexingImportBill);