import IndexingInformation from '../IndexingInformation/IndexingInformation';
import { SubmissionError } from 'redux-form'
import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, render, mount } from 'enzyme';
import 'isomorphic-fetch';

import data from '../../../../public/json/indexingInformationRecord.json';

let indexingInfo = null;
let customerAccountNumber = null;
let customerName = null;
let applicationDateTime = null;
let transactionCurrency = null;
let transactionAmount = null;
let dcNumber = null;
            
beforeAll(() => {
    indexingInfo = shallow(<IndexingInformation/>);    
    customerAccountNumber = indexingInfo.find('input[name="customerAccountNumber"]');
    customerName = indexingInfo.find('input[name="customerName"]');
	applicationDateTime = indexingInfo.find('input[name="applicationDateTime"]');
	transactionCurrency = indexingInfo.find('input[name="transactionCurrency"]');
	transactionAmount = indexingInfo.find('input[name="transactionAmount"]');
	dcNumber = indexingInfo.find('input[name="dcNumber"]');	  
});

describe('IndexingInformation', () => {
    it('renders without crashing', () => {
        expect(indexingInfo.find('form').length).toBe(1);
    });

    it('page header should be - Basic Information', () => {
        const header = <span className="Muli-Bold" style={{ fontSize: '16px' }}>Basic Information</span>;
        expect(indexingInfo.contains(header)).toEqual(false);
    });

    describe('customerAccountNumber', () => {
        it('should render once', () => {
            expect(customerAccountNumber.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(customerAccountNumber.prop('required')).toBe(true);
        });
  /*      it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            customerAccountNumber.simulate('blur',{target:{...customerAccountNumber.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="customerAccountNumber"]').prop('errors').length).toBe(1);
            expect( indexingInfo.find('ErrorDisplay[fieldName="customerAccountNumber"]').prop('errors')[0]['error']).toBe("customerAccountNumber is required");
        });*/
    });

    describe('customerName', () => {
        it('should render once', () => {
            expect(customerName.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(customerName.prop('required')).toBe(true);
        });
    /*    it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            customerName.simulate('blur',{target:{...customerName.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="customerName"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('applicationDateTime', () => {
        it('should render once', () => {
            expect(applicationDateTime.length).toBe(1);
        });

   /*     it('should have validation attributes set', () => {
            expect(stapplicationDateTimeatus.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            applicationDateTime.simulate('blur',{target:{...applicationDateTime.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="applicationDateTime"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('transactionCurrency', () => {
   /*     it('should render once', () => {
            expect(transactionCurrency.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(transactionCurrency.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            transactionCurrency.simulate('blur',{target:{...transactionCurrency.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="transactionCurrency"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('transactionAmount', () => {
        it('should render once', () => {
            expect(transactionAmount.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(transactionAmount.prop('required')).toBe(true);
        });
   /*     it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            transactionAmount.simulate('blur',{target:{...transactionAmount.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="transactionAmount"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('dcNumber', () => {
        it('should render once', () => {
            expect(dcNumber.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(dcNumber.prop('required')).toBe(true);
        });
    /*    it('should show error if no value is entered', () => {
            indexingInfo.instance().saveError(data);
            dcNumber.simulate('blur',{target:{...dcNumber.props()}, type: 'blur', preventDefault: () => {} });
            expect( indexingInfo.find('ErrorDisplay[fieldName="dcNumber"]').prop('errors').length).toBe(0);
        });*/
    });	
});
