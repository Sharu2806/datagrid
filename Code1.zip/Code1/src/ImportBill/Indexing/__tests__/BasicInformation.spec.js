import BasicInformation from '../BasicInformation/BasicInformation';
import { SubmissionError } from 'redux-form'
import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, render, mount } from 'enzyme';
import 'isomorphic-fetch';

import data from '../../../../public/json/basicInformationRecord.json';

let basicInfo = null;
let gwisId = null;
let status = null;
let createdUser = null;
let lastModifiedUser = null;
let lastModifiedTime = null;
let createdTime = null;
let workStep = null;
let nextWorkStep = null;  
/*Test Suite file for Import Bill Indexing */            
beforeAll(() => {
    basicInfo = shallow(<BasicInformation/>);    
    gwisId = basicInfo.find('input[name="gwisId"]');
    status = basicInfo.find('input[name="status"]');
	createdUser = basicInfo.find('input[name="createdUser"]');
	lastModifiedUser = basicInfo.find('input[name="lastModifiedUser"]');
	lastModifiedTime = basicInfo.find('input[name="lastModifiedTime"]');
	createdTime = basicInfo.find('input[name="createdTime"]');
	workStep = basicInfo.find('input[name="workStep"]');
	nextWorkStep = basicInfo.find('input[name="nextWorkStep"]');            
});

describe('BasicInformation', () => {
    it('renders without crashing', () => {
        expect(basicInfo.find('form').length).toBe(1);
    });

    it('page header should be - Basic Information', () => {
        const header = <span className="Muli-Bold" style={{ fontSize: '16px' }}>Basic Information</span>;
        expect(basicInfo.contains(header)).toEqual(false);
    });

    describe('gwisId', () => {
        it('should render once', () => {
            expect(gwisId.length).toBe(1);
        });

    });

    describe('status', () => {
        it('should render once', () => {
            expect(status.length).toBe(1);
        });

     /*   it('should have validation attributes set', () => {
            expect(status.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            status.simulate('blur',{target:{...status.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="status"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('createdUser', () => {
        it('should render once', () => {
            expect(createdUser.length).toBe(1);
        });

     /*   it('should have validation attributes set', () => {
            expect(stcreatedUseratus.prop('required')).toBe(true);
        });
       it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            createdUser.simulate('blur',{target:{...createdUser.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="createdUser"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('lastModifiedUser', () => {
        it('should render once', () => {
            expect(lastModifiedUser.length).toBe(1);
        });

      /*  it('should have validation attributes set', () => {
            expect(lastModifiedUser.prop('required')).toBe(true);
        });
       it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            lastModifiedUser.simulate('blur',{target:{...lastModifiedUser.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="lastModifiedUser"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('lastModifiedTime', () => {
        it('should render once', () => {
            expect(lastModifiedTime.length).toBe(1);
        });

/* it('should have validation attributes set', () => {
            expect(lastModifiedTime.prop('required')).toBe(true);
        }); 
       it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            lastModifiedTime.simulate('blur',{target:{...lastModifiedTime.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="lastModifiedTime"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('createdTime', () => {
        it('should render once', () => {
            expect(createdTime.length).toBe(1);
        });

      /*  it('should have validation attributes set', () => {
            expect(createdTime.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            createdTime.simulate('blur',{target:{...createdTime.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="createdTime"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('workStep', () => {
        it('should render once', () => {
            expect(workStep.length).toBe(1);
        });

      /*  it('should have validation attributes set', () => {
            expect(workStep.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            workStep.simulate('blur',{target:{...workStep.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="workStep"]').prop('errors').length).toBe(0);
        });*/
    });
	describe('nextWorkStep', () => {
       /* it('should render once', () => {
            expect(nextWorkStep.length).toBe(1);
        });

        it('should have validation attributes set', () => {
            expect(nextWorkStep.prop('required')).toBe(true);
        });
        it('should show error if no value is entered', () => {
            basicInfo.instance().saveError(data);
            nextWorkStep.simulate('blur',{target:{...nextWorkStep.props()}, type: 'blur', preventDefault: () => {} });
            expect( basicInfo.find('ErrorDisplay[fieldName="nextWorkStep"]').prop('errors').length).toBe(0);
        });*/
    });
    
});












// See README for discussion of chai, enzyme, and sinon
//import chai, { expect } from 'chai'
/*
import chaiEnzyme from 'chai-enzyme'
import sinon from 'sinon'

describe('<BasicInformation />',() =>{
it('it renders basic information component',()=>{
    const component = shallow (<BasicInformation name="BasicInformation"/>);

    //expect(component).toHaveLength(1);
});
it('it renders props currectly',()=>{
    const component = shallow (<BasicInformation name="BasicInformation"/>);
	//console.log(component.instance().props);
	expect(component.instance().props.name).toBe('BasicInformation');
    //expect(component.instance().props.gwisId).toBe('1121212121');
});
});

it('it updates the basic info on save button click', () => {
	const component = mount (<BasicInformation />);
	const button = component.find('save');
	button.simulate('click');
	//button.props() = onClick();
	//expect(component.state().)
} 

);



chai.use(chaiEnzyme())

// In this file we're doing unit testing of our component, which means it
// really has nothing to do with Redux-Form at this point. We can pass in our
// own props (e.g. `submitting`) and make sure our form renders as we expect.

describe("BasicInformation", () => {
	let subject = null
	let submitting, touched, error, reset, onSave, onSaveResponse, handleSubmit
	beforeEach(() => {
		submitting = false
		touched = false
		error = null
		reset = sinon.spy()
		onSaveResponse = Promise.resolve()
		handleSubmit = fn => fn
	})
	const buildSubject = () => {
		onSave = sinon.stub().returns(onSaveResponse)
		const props = {
			onSave,
			submitting: submitting,
			// The real redux form has many properties for each field,
			// including onChange and onBlur handlers. We only need to provide
			// the ones that will change the rendered output.
			fields: {
				gwisId: {
					value: '',
					touched: touched,
					error: error
				},
                status: {
					value: '',
					touched: touched,
					error: error
				},
                createdUser: {
					value: '',
					touched: touched,
					error: error
				},
                createdTime: {
					value: '',
					touched: touched,
					error: error
				},
                lastModifiedUser: {
					value: '',
					touched: touched,
					error: error
				},
                lastModifiedTime: {
					value: '',
					touched: touched,
					error: error
				}
			},
			handleSubmit,
			reset
		}
		return shallow(<BasicInformation {...props}/>)
	}

	// Here we show we can test asychronous actions triggered by our form.
	it("calls reset after onSave", () => {
		subject = buildSubject()
		subject.find('form').simulate('submit')
		expect(onSave.callCount).to.equal(1)
		// This onSaveResponse isn't the 'real' response. But using .then()
		// with it works here because it enforces that we run our expect check
		// AFTER all the form submit logic has run.
		return onSaveResponse.then(() => {
			expect(reset.callCount).to.equal(1)
		})
	})

	// This is a very simple test, making sure that if we pass in a certain
	// prop value, our form renders appropriately.
	context("when submitting", () => {
		it("shows a wait message while submitting", () => {
			submitting = true
			subject = buildSubject()
			const icon = subject.find('button[type="submit"]')
			expect(icon).to.have.text('Submitting (takes 1 s)')
		})

		context('when server returns an error', () => {
			beforeEach(() => {
				onSaveResponse = Promise.reject('some rejection')
			})

			it("throws a SubmissionError on error in the form submit handler", () => {
				let promiseReturnedFromFormHandler
				handleSubmit = fn => {
					return function() {
						// In this test, we know arguments will be empty because we
						// control it in our test when we simulate the submit, and
						// don't pass it any arguments. But it's just good practice to
						// pass them along.
						promiseReturnedFromFormHandler = fn(arguments)
					}
				}
				subject = buildSubject()
				subject.find('form').simulate('submit')
				expect(onSave.callCount).to.equal(1)
				return promiseReturnedFromFormHandler.then(() => {
					throw new Error("Submission error should have been checked but wasn't")
				}).catch(error => {
					expect(error).to.be.instanceof(SubmissionError)
				})
			})

			it("alternative approach to previous test - throws a SubmissionError on error in the form submit handler", () => {
				// In this alternative approach, we're calling the component's
				// submit handler directly. This is probably fine for simple
				// components, but I worry if the component is more complex.
				// The reason I'm showing this way is to show the use of
				// enzyme's .instance() method.
				subject = buildSubject()
				const promiseReturnedFromFormHandler = subject.instance().mySubmit({ gwisId: 'somename',status:'active',createdUser:'abc',createdTime:'10:30',lastModifiedUser:'xyz', lastModifiedTime:'10:30' })
				return promiseReturnedFromFormHandler.then(() => {
					throw new Error('Should not hit this then block - test was set up incorrectly')
				}).catch(error => {
					expect(error).to.be.instanceof(SubmissionError)
				})
			})
		})
	})

})

// renderTextInput is a stateless functional component, aka just a method that
// returns a React element, so it's trivial to test. We export it from the
// ContactFormComponent file. It could be named whatever we want, but it
// should be named based on what type of input component it creates, since you
// would create a similar function for each type of component you need to
// render. If you look in renderTextInput, it outputs an <input/>, but you
// would need a different method if you wanted to output a <select/>,
// <textarea>, or something more complex like a composite component with many
// parts, e.g. if you're using react-bootstrap.
describe('renderTextInput', () => {
	let subject
	context("when in an error state", () => {
		it("renders an error message for the input", () => {
			const input = { name: 'firstName', value: '' }
			const label = 'First name'
			const meta = { touched: true, error: 'Required' }
			const element = renderTextInput({ input, label, meta })
			subject = shallow(element)
			const firstNameHelpBlock = subject.find('.help-block').first()
			expect(firstNameHelpBlock).to.exist
			expect(firstNameHelpBlock.text()).to.equal('Required')
		})
	})
})

*/