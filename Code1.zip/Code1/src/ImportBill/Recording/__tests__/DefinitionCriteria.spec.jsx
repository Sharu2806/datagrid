import { SubmissionError } from 'redux-form'
import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, render, mount } from 'enzyme';
import 'isomorphic-fetch';

import DefinitionCriteria from '../DefinitionCriteria';

let accountNumber_cn = null;
let accountNumber_ia = null;
let accountNumber = null;
let productType = null;
let issuanceBranch = null;
let transactionNumber = null;
let transactionNumberUn = null;
let dcNumber1 = null;
let dcNumber2 = null;
let dcNumber3 = null;
let createTemplate = null;
let summaryAmendment = null;

let businessUnitId = null;
let wolfStatus = null;

let definitionCriteria = null;

let copyFromAccount = null;
let copyFromAccountNumber_gm = null;
let copyFromAccountNumber_bn = null;
let copyFromAccountNumber_cn = null;
let copyFromAccountNumber_ia = null;
let productTypeTrn = null;
let copyIssuanceBranch = null;
let copyFromTrn = null;
let copytransactionNumberUn = null;  

beforeAll(() => {
    definitionCriteria = shallow(<DefinitionCriteria/>); 
    accountNumber_cn = definitionCriteria.find('input[name="accountNumber_cn"]');
    accountNumber_ia = definitionCriteria.find('input[name="accountNumber_ia"]');
    accountNumber = definitionCriteria.find('input[name="accountNumber"]');	
    productType = definitionCriteria.find('select[name="productType"]');
	issuanceBranch = definitionCriteria.find('input[name="issuanceBranch"]');
	transactionNumber = definitionCriteria.find('input[name="transactionNumber"]');
	transactionNumberUn = definitionCriteria.find('input[name="transactionNumberUn"]');
	dcNumber1 = definitionCriteria.find('select[name="dcNumber1"]');
	dcNumber2 = definitionCriteria.find('input[name="dcNumber2"]');
	dcNumber3 = definitionCriteria.find('input[name="dcNumber3"]');
	
    copyFromAccount = definitionCriteria.find('input[name="copyFromAccount"]');
    copyFromAccountNumber_gm = definitionCriteria.find('input[name="copyFromAccountNumber_gm"]');
    copyFromAccountNumber_bn = definitionCriteria.find('input[name="copyFromAccountNumber_bn"]');
    copyFromAccountNumber_cn = definitionCriteria.find('input[name="copyFromAccountNumber_cn"]');
    copyFromAccountNumber_ia = definitionCriteria.find('input[name="copyFromAccountNumber_ia"]');
    productTypeTrn = definitionCriteria.find('select[name="productTypeTrn"]');
    copyIssuanceBranch = definitionCriteria.find('input[name="copyIssuanceBranch"]');
    copyFromTrn = definitionCriteria.find('input[name="copyFromTrn"]');
    copytransactionNumberUn = definitionCriteria.find('input[name="copytransactionNumberUn"]');
	businessUnitId = definitionCriteria.find('input[name="businessUnitId"]');  
	wolfStatus = definitionCriteria.find('input[name="wolfStatus"]');  
              	
});

describe('DefinitionCriteria', () => {
    it('renders without crashing', () => {
        expect(definitionCriteria.find('form').length).toBe(1);
    });
	
    it('page header should be - Definition Criteria', () => {
        const header = <span className="Muli-Bold" style={{ fontSize: '16px' }}>Definition Criteria</span>;
        expect(definitionCriteria.contains(header)).toEqual(true);
    });

describe('accountNumber_cn', () => {
        it('should render once', () => {
            expect(accountNumber_cn.length).toBe(1);
        });
	});
describe('accountNumber_ia', () => {
      it('should render once', () => {
            expect(accountNumber_ia.length).toBe(1);
        });
	});
describe('accountNumber', () => {
        it('should render once', () => {
            expect(accountNumber.length).toBe(1);
        });
	});

    describe('productType', () => {
        it('should render once', () => {
            const selectproductType = <select className="form-control selectCss" name="productType" id="productType">
                                <option value="FNG">FNG</option>
                                <option value="GUA">GUA</option>
                                <option value="IBC">IBC</option>
                                <option value="TEE">TEE</option>
                            </select>;
        expect(definitionCriteria.contains(selectproductType)).toEqual(false);
        });
     });

     describe('issuanceBranch', () => {
        it('should render once', () => {
            expect(issuanceBranch.length).toBe(1);
        });
    });
    describe('transactionNumber', () => {
        it('should render once', () => {
            expect(transactionNumber.length).toBe(1);
        });
    });
    describe('transactionNumberUn', () => {
        it('should render once', () => {
            expect(transactionNumberUn.length).toBe(1);
        });
    });

     describe('dcNumber1', () => {
        it('should render once', () => {
            const selectdcNumber1 = <select className="form-control selectCss" name="dcNumber1" id="dcNumber1">
                                <option value="FNG">FNG</option>
                                <option value="GUA">GUA</option>
                                <option value="IBC">IBC</option>
                                <option value="TEE">TEE</option>
                            </select>;
        expect(definitionCriteria.contains(selectdcNumber1)).toEqual(false);
        });
     });

    describe('dcNumber2', () => {
        it('should render once', () => {
            expect(dcNumber2.length).toBe(1);
        });
    });

    describe('dcNumber3', () => {
        it('should render once', () => {
            expect(dcNumber3.length).toBe(1);
        });
    });

     describe('wolfStatus', () => {
        it('should render once', () => {
            const selectwolfStatus = <select className="form-control selectCss" name="wolfStatus" id="wolfStatus">
                                <option value="Y">Y</option>
                                <option value="N">N</option>
                            </select>;
        expect(definitionCriteria.contains(selectwolfStatus)).toEqual(false);
   
     });
    }); 
    

    describe('copyFromAccount', () => {
        it('should render once', () => {
            expect(copyFromAccount.length).toBe(1);
        });
    });

    describe('copyFromAccountNumber_gm', () => {
        it('should render once', () => {
            expect(copyFromAccountNumber_gm.length).toBe(1);
        });
    });

    describe('copyFromAccountNumber_bn', () => {
        it('should render once', () => {
            expect(copyFromAccountNumber_bn.length).toBe(1);
        });
    });        

    describe('copyFromAccountNumber_cn', () => {
        it('should render once', () => {
            expect(copyFromAccountNumber_cn.length).toBe(1);
        });
    });  

    describe('copyFromAccountNumber_ia', () => {
        it('should render once', () => {
            expect(copyFromAccountNumber_ia.length).toBe(1);
        });
    });  

describe('productTypeTrn', () => {
        it('should render once', () => {
            const selectproductTypeTrn = <select className="form-control selectCss" name="productTypeTrn" id="productTypeTrn">
                                <option value="FNG">FNG</option>
                                <option value="GUA">GUA</option>
                                <option value="IBC">IBC</option>
                                <option value="TEE">TEE</option>
                            </select>;
        expect(definitionCriteria.contains(selectproductTypeTrn)).toEqual(false);
        });
     });

    describe('copyIssuanceBranch', () => {
        it('should render once', () => {
            expect(copyIssuanceBranch.length).toBe(1);
        });
    });  

    describe('copyFromTrn', () => {
        it('should render once', () => {
            expect(copyFromTrn.length).toBe(1);
        });
    });  
    
    describe('copytransactionNumberUn', () => {
        it('should render once', () => {
            expect(copytransactionNumberUn.length).toBe(1);
        });
    });    
        
});
