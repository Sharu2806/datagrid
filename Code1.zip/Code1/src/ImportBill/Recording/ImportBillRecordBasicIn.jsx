import React, { Component } from 'react';
import { DateField } from 'react-date-picker';
import { connect } from "react-redux";
import DatePicker from 'react-datepicker';
import moment from 'moment';
import { validateErrors, removeError, addError, handleChange } from '../../common.js';
import ErrorDisplay from '../../SharedComponents/ErrorDisplay';
import Validator from  'validator';
import isEmpty from 'lodash/isEmpty';
import classnames from 'classnames';
import CustomSuggestionSearch from '../../Guarantee/Recording/CustomSuggestionSearch'
var jsonResult = require("../../Guarantee/Recording/swiftDetails.json");


var basicInfoValidate = {
    "billCurrency": { mandatory: true },
    "billAmount": { mandatory: true },
    "negotiationBankRef": { mandatory: true },
     "reimbursingMode": { mandatory: true },
};




export default class ImportBillRecordBasicIn extends Component {
         constructor(props) {
        super(props);
        this.state = {
            billCurrency : 'USD',
            billAmount: '',
            negotiationBankRef : '',
            reimbursingAc1 : '',
            reimbursingAc_bn :'',
            reimbursingAc_cn :'',
            reimbursingAc_gm : '',
            reimbursingAc_ia : '',
            display : false,
            underLi : 'Yes',
            acknowledgeThru:'',
            errors: []
        };

        this.addError = this.addError.bind(this);
        this.removeError = this.removeError.bind(this);

        this.handleChange = this.handleChange.bind(this);
        let errorFromJson = [];
    }
     componentDidMount() {

        fetch('json/ImportBillError.json', {
            method: 'GET'
        })
            .then(result => result.json())
            .then(body => this.saveError(body));
    }
    saveError(body) {
        this.errorFromJson = body
    }


   addError(event) {
        addError(event, this);
    }

    handleChange(event) {
        handleChange(event, this)
    }

    removeError(event) {
        removeError(event, this);
    }
     lessLengthError(val){
       // alert(val)
    }

    moreLengthError(val){
       // alert(val)
    }

render() {
         var listMultipleData = ["bankName"]
        var listViewData = ["address1"];
        var toolTipViewData = [{
            label: "Swift Address",
            values: [
                "swiftAddress"
            ]
        }, {
            label: "Clearing Code",
            values: [
                "clearingCode"
            ]
        }, {
            label: "Swift Authentication",
            values: [
                "swiftAuthentication"
            ]
        }, {
            label: "Detailed Address",
            values: [
                "address1",
                "address2",
                "address3",
                "address4"
            ]
        }]

        var radioValues = [{
            label: "Bank Name",
            value: "bankName",
        },
        {
            label: "SWIFT Address",
            value: "swiftAddress",
        },
        {
            label: "CBID Code",
            value: "bankCode",
        }]

        var dropValues = {
            label: "Select Country",
            firstValue: "All",
            restValues: "countryCode",
            otherValues: "country"
        }
          var acknowledgeThruValue = [];
        var establishedBy = [];
        //var chargerForAccountOf = [];
        var dropDownObj = this.props.acknowledgeThruDropDownData; //this.props.dropdownData
        var obj = null;
        var optionObj = null;
        if (dropDownObj) {
            var recordingObj = dropDownObj;
            if (recordingObj) {
                for (var i = 0; i < recordingObj.length; i++) {
                    obj = recordingObj[i]
                    optionObj = <option value={obj.code} key={i}>{obj.DropDownValue}</option>
                    acknowledgeThruValue.push(optionObj)
                }
            }
        }
        return (
            
            <div>
            <form style={{ paddingTop: "20px" }}>
                    {/*Basic Information*/}
                    <div className="row" >
                        <div className="col-md-12 col-lg-12">
                            <span className="Muli-Bold" style={{ fontSize: '16px' }}>Basic Information</span>
                            <hr style={{ borderColor: '#919191', marginTop: '1px' }} />
                        </div>
                    </div>
                     <div className="row" >
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                             <span 
                                className="label-margin-below" 
                                style={{ fontSize: "14px", color: "#000000" }}>
                                Bill Amount</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                             <input
                                type="text" 
                                className="form-control" 
                                style={{ width: '65px', marginRight: '3px', display: 'inline-block' }} 
                                name="billCurrency" id="billCurrency" 
                                value={this.state.billCurrency}
                                required={basicInfoValidate ? basicInfoValidate.billCurrency.mandatory : false} 
                                onBlur={this.addError} 
                                onFocus={this.removeError} 
                                value={this.state.billCurrency} 
                                onChange={this.handleChange} 
                                name="billCurrency" id="billCurrency"/>   
                                                         
                            <input 
                                type="text" 
                                className="form-control" 
                                style={{ width: '235px', marginRight: '3px', display: 'inline-block' }}
                                required={basicInfoValidate ? basicInfoValidate.billAmount.mandatory : false} 
                                onBlur={this.addError} 
                                onFocus={this.removeError} 
                                value={this.state.billAmount} 
                                onChange={this.handleChange} 
                                name="billAmount" id="billAmount" />
                            <span className="help-block">
                            <ErrorDisplay 
                                errors={this.state.errors} 
                                fieldName='billCurrency' 
                                className='errorClass' />
                            <ErrorDisplay 
                                errors={this.state.errors} 
                                fieldName='billAmount' 
                                className='errorClass' />  
                           </span> 
                           </div> 
                    </div>
                         <br/>
                    <div className="row">
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <span 
                                className="label-margin-below" 
                                style={{ fontSize: "14px", color: "#000000" }}>
                                Negotiating Bank</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                            <CustomSuggestionSearch
                                listData={jsonResult}
                                listMultipleData={listMultipleData}
                                listViewData={listViewData}
                                toolTipViewData={toolTipViewData}
                                radioButtonVisible={true}
                                radioButtonVisibleValues={radioValues}
                                dropDownVisible={true}
                                validateInput={true}
                                throwLengthError={this.moreLengthError}
                                maxLengthOfInput={8}
                                id="recordingBasicInfo1"
                                dropDownVisibleValues={dropValues}
                                dropDownVisibleFor={"bankName"}
                                sortDataBy={"bankName"}
                                searchByChars={3}
                                radioGroupLabelVisible={false}
                                showData={this.showData}
                                toolTipVisible = {true}
                                dataToShowOnSelect={"bankCode"}
                            />
                 </div>
              </div> 
              <br/>
                <div className="row" >
                        <div className="col-xs-12 col-sm-4 col-md-4 col-lg-3">
                           <span 
                                className="label-margin-below" 
                                style={{ fontSize: "14px", color: "#000000" }}>
                               Negotiation Bank Reference</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                             <input 
                                type="text" 
                                className="form-control" 
                                style={{ width: '300px', marginRight: '3px', display: 'inline-block' }}
                                required={basicInfoValidate ? basicInfoValidate.negotiationBankRef.mandatory : false} 
                                onBlur={this.addError} 
                                onFocus={this.removeError} 
                                value={this.state.negotiationBankRef} 
                                onChange={this.handleChange} 
                                name="negotiationBankRef" id="negotiationBankRef" />
                           <span className="help-block">
                           <ErrorDisplay 
                                errors={this.state.errors} 
                                fieldName='negotiationBankRef' 
                                className='errorClass' />
                                </span>
                        </div>
                        </div>

                        <div className="row" >
                        <div className="col-xs-12 col-sm-4 col-md-4 col-lg-3">
                                <span 
                                className="label-margin-below" 
                                style={{ fontSize: "14px", color: "#000000" }}>
                               Reimb. Mode</span>&nbsp;<span style={{ color: 'red' }}>*</span><br />
                            <select 
                                className="form-control selectCss" 
                                name="reimbursingMode" 
                                id="reimbursingMode" 
                                style={{ width: '300px'}}
                                onChange={this.handleChange} >
                                <option value="">Please select</option>
                                <option value="DD">DD </option>
                            </select>
                        </div>
                    </div>
                    <br/>
                       <br/>
                    <div className="row">
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <span 
                                className="label-margin-below" 
                                style={{ fontSize: "14px", color: "#000000" }}>
                               Reimbursing Bank</span><br />
                            <CustomSuggestionSearch
                                listData={jsonResult}
                                listMultipleData={listMultipleData}
                                listViewData={listViewData}
                                toolTipViewData={toolTipViewData}
                                radioButtonVisible={true}
                                radioButtonVisibleValues={radioValues}
                                dropDownVisible={true}
                                validateInput={true}
                                throwLengthError={this.moreLengthError}
                                maxLengthOfInput={8}
                                id="recordingBasicInfo1"
                                dropDownVisibleValues={dropValues}
                                dropDownVisibleFor={"bankName"}
                                sortDataBy={"bankName"}
                                searchByChars={3}
                                radioGroupLabelVisible={false}
                                showData={this.showData}
                                toolTipVisible = {true}
                                dataToShowOnSelect={"bankCode"}
                            />
                 </div>
              </div> 
              <br/>
                 <div className="row">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span 
                                className="label-margin-below" 
                                style={{ fontSize: "14px", color: "#000000" }}>Reimbursing A/C</span>
                            <br />
                              <div className="row no-gutter">
                                  {/*<div className={classnames("form-group",{'has-error':errors.reimbursingAc})}>
                                  */}
                                <input
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '45px', marginRight: '3px', display: 'inline-block' }} 
                                    name="reimbursingAc1" id="reimbursingAc1" 
                                    value={this.state.reimbursingAc1}
                                    onChange={this.handleChange}
                                    maxLength={2}
                                    pattern="^[a-zA-Z]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError}
                                    />
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '65px', marginRight: '3px', display: 'inline-block' }} 
                                    name="reimbursingAc_gm" id="reimbursingAc_gm" 
                                    value={this.state.reimbursingAc_gm}
                                    onChange={this.handleChange}
                                    maxLength={4}
                                    pattern="^[a-zA-Z]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError}
                                    />
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '52px', marginRight: '3px', display: 'inline-block' }} 
                                    name="reimbursingAc_bn" id="reimbursingAc_bn" 
                                    value={this.state.reimbursingAc_bn} 
                                    onChange={this.handleChange}
                                    maxLength={3}
                                    pattern="^[0-9]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError}/>
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '80px', marginRight: '3px', display: 'inline-block' }} 
                                    name="reimbursingAc_cn" id="reimbursingAc_cn" 
                                    value={this.state.reimbursingAc_cn}
                                    onChange={this.handleChange}
                                    maxLength={6}
                                    pattern="^[0-9]*$"
                                    onBlur={this.addError}
                                    onFocus={this.removeError} />
                                
                                <input 
                                    type="text" 
                                    className="form-control" 
                                    style={{ width: '52px', marginRight: '3px', display: 'inline-block' }} 
                                    name="reimbursingAc_ia" id="reimbursingAc_ia" 
                                    value={this.state.reimbursingAc_ia}
                                    onChange={this.handleChange}
                                    maxLength={3}
                                    pattern="^[0-9]*$"
                                    onBlur={this.addError} 
                                    onFocus={this.removeError} />
                                    
                                <span className="help-block">
                                <ErrorDisplay 
                                    errors={this.state.errors} 
                                    fieldName='reimbursingAc_gm' 
                                    className='errorClass' />                                    
                                <ErrorDisplay 
                                    errors={this.state.errors} 
                                    fieldName='reimbursingAc_bn' 
                                    className='errorClass' />
                                <ErrorDisplay 
                                    errors={this.state.errors} 
                                    fieldName='reimbursingAc_cn' 
                                    className='errorClass' />
                                <ErrorDisplay 
                                    errors={this.state.errors} 
                                    fieldName='reimbursingAc_ia' 
                                    className='errorClass' /></span>
                               {/* <div className ='errorClass' >{errors.reimbursingAc && errors.reimbursingAc}</div>
                                    </div>*/}
                            </div>
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-7 col-lg-4">
                            <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Under LI?</span> <br />
                            <div className="row">
                                <div className="col-xs-4 col-sm-4 col-md-5 col-lg-6">
                                    <input type="radio" name="underLi" id="underLi" value="Yes" onChange={this.handleInputChange} />Yes&nbsp; &nbsp; &nbsp;
                              
                                    <input type="radio" name="underLi" id="underLi" value="No" onChange={this.handleInputChange} />No
                                </div>
                            </div>
                        </div>
                        </div>


                        <div className="row">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Commodity Code &nbsp;<span style={{ color: 'red' }}>*</span></span>
                            <br />
                             <select 
                                className="form-control selectCss" 
                                name="commodityCode" 
                                id="commodityCode" 
                                style={{ width: '300px', marginRight: '3px', display: 'inline-block' }}
                                onChange={this.handleChange} >
                                <option value=""></option>
                                <option value="Y">Y</option>
                                <option value="N">N</option>
                                <option value="P">P</option>
                                <option value="A">A</option>
                            </select>
                            </div>
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                             <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>SG Number</span>
                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                             <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}><a href="#">View All</a></span>
                            <br />
                             <input 
                                type="text" 
                                className="form-control" 
                                name="sgNumber" 
                                id="sgNumber" 
                                pattern="^[0-9]*$"
                                style={{ width: '300px'}}
                                />
                                 <input 
                                type="text" 
                                className="form-control" 
                                name="sgNumber" 
                                id="sgNumber" 
                                pattern="^[0-9]*$"
                                style={{ width: '300px'}}
                                />
                                </div>
                                </div>
                                <br/>
                        <div className="row">
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                            <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Acceptance Required?</span>
                            <br />
                             <div className="row">
                                <div className="col-xs-4 col-sm-4 col-md-5 col-lg-6" >
                                    <input 
                                        type="radio" 
                                        name="acceptanceRequired" 
                                        id="acceptanceRequired" 
                                        value="Yes" 
                                        defaultChecked="true"
                                         />Yes &nbsp;                          
                                    <input 
                                        type="radio" 
                                        name="acceptanceRequired" 
                                        id="acceptanceRequired" 
                                        value="No" 
                                        />No
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                             <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Acknowledge thru</span>
                            <br />
                            <select 
                                className="form-control selectCss" 
                                name="acknowledgeThru" 
                                id="acknowledgeThru" 
                                style={{ width: '300px'}}
                                onChange={this.handleChange} 
                                value={this.state.acknowledgeThru} >
                                <option value="">Please select </option>
                                 {acknowledgeThruValue}
                            </select>
                        </div>
                    </div>
                    <br/>
        <div className="row">
        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Draft Date</span>&nbsp;<span style={{ color: 'red' }}>*</span>   <br />
                <br />
                <div className="form-group">
                <div className='input-group date' id='datetimepicker1' style={{width: '296px'}}>
                <input type='text' className="form-control" name="draftDate" id="draftDate" style={{margin: '0px'}}/>
                <span className="input-group-addon">
                <span className="glyphicon glyphicon-calendar"></span>
                </span>
            </div>
        </div>
        </div>
         <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
        <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Schedule Date
        </span>&nbsp;<span style={{ color: 'red' }}>*</span>   <br />
        <br />
         <div className="form-group">
                <div className='input-group date' id='datetimepicker2' style={{width: '296px'}}>
                <input type='text' className="form-control" name="scheduleDate" id="scheduleDate" style={{margin: '0px'}}/>
                <span className="input-group-addon">
                <span className="glyphicon glyphicon-calendar"></span>
                </span>
            </div>
        </div>
        </div>
        </div>

        <div className="row">
        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Action by Date</span><br />
                <br />
                <div className="form-group">
                <div className='input-group date' id='datetimepicker3' style={{width: '296px'}}>
                <input type='text' className="form-control" name="actionDate" id="actionDate" style={{margin: '0px'}}/>
                <span className="input-group-addon">
                <span className="glyphicon glyphicon-calendar"></span>
                </span>
            </div>
        </div>
        </div>

        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Usance</span>
                 <br />
                 <input 
                                type="text" 
                                className="form-control" 
                                name="usance" 
                                id="usance" 
                               // pattern="^[0-9]*$"
                                style={{ width: '300px'}}
                                />
                </div>


        </div>
        <div className="row">
        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Usance by Date</span><br />
                <br />
                <div className="form-group">
                <div className='input-group date' id='datetimepicker3' defaultValue="2017-02-17"style={{width: '296px'}}>
                <input type='text' className="form-control" name="usanceDate" id="usanceDate" style={{margin: '0px'}}/>
                <span className="input-group-addon">
                <span className="glyphicon glyphicon-calendar"></span>
                </span>
            </div>
        </div>
        </div>

        <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
             <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Transport Mode</span>&nbsp;<span style={{ color: 'red' }}>*</span>   
                            <br />
                            <select 
                                className="form-control selectCss" 
                                name="transportMode" 
                                id="transportMode" 
                                style={{ width: '300px'}}
                                onChange={this.handleChange} 
                                value={this.state.acknowledgeThru} >
                                <option value="">Please select </option>
                                 {acknowledgeThruValue}
                            </select>
         </div>                           
        </div>



                                  




                <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-5 col-lg-4">
                <span className="label-margin-below" style={{ fontSize: "14px", color: "#000000" }}>Shipping Co.
                        <span style={{ color: 'red' }}>*</span> </span>  
                            <br />
                             <select 
                                className="form-control selectCss" 
                                name="transportMode" 
                                id="transportMode" 
                                style={{ width: '300px'}}
                                onChange={this.handleChange} 
                                value={this.state.acknowledgeThru} >
                                <option value="">Please select </option>
                                 {acknowledgeThruValue}
                            </select>
                                 <input 
                                type="text" 
                                className="form-control" 
                                name="sgNumber" 
                                id="sgNumber" 
                                pattern="^[0-9]*$"
                                style={{ width: '300px', marginRight: '3px', display: 'inline-block' }}
                                />
                                 <input 
                                type="text" 
                                className="form-control" 
                                name="sgNumber" 
                                id="sgNumber" 
                                pattern="^[0-9]*$"
                                style={{ width: '300px', marginRight: '3px', display: 'inline-block' }}
                                />
                                 <input 
                                type="text" 
                                className="form-control" 
                                name="sgNumber" 
                                id="sgNumber" 
                                pattern="^[0-9]*$"
                                style={{ width: '300px', marginRight: '3px', display: 'inline-block' }}
                                />
                </div>
                </div>
                </form>
                </div>
        );
}
}

