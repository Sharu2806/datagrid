

export default (state = null, action) => {
    switch (action.type) {
        case "FETCH_RECORDING_DATA":
            console.log("fetch recording dAta");
            state = {
                ...action.payload,
                recordingImportBillFlag:true
            };
            break;
         case "FETCH_RECORDING_DATA_DC":
            console.log("DC FETCH DATA ");
            state = {
                ...state,
                recordingImportBillFlag:true
            };
            break;

        case "SAVE_DEFINITION_CRITERIA_DATA":
             console.log("save Data defination criteria for import bill");
             console.log(action.payload.accountNumber);
            state = {
                ...state,
                definitionCriteria: {
                    ...action.payload}
            };
            break;
        case "GENERATE_DC_NUMBER":
            console.log("GENERATE_DC_NUMBER reducer :: ",action.payload);
            state = {
                ...state,                
                outputData: action.payload
            };
            break;
        default:

    }
    return state;
}