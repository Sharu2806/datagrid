var HazelcastClient = require('hazelcast-client').Client;
var Config = require('hazelcast-client').Config;
//var TestAPI = require('../NodeServer/TestRestAPI.js'); 
//var request = require('request');
var http = require('http'); //1
var config = new Config.ClientConfig();
//config.networkConfig.addresses = [{ host: '169.254.187.82', port: '5701' }];
config.networkConfig.addresses = [{ host: '127.0.0.1', port: '5701' }];

var autoPredict = [];   //1
var map = {};
var i = 0;
var j = 0;

function HazelCache(request, response, hostName, myPort, methodType) {
  var config = new Config.ClientConfig();
  // config.networkConfig.addresses = [{ host: '169.254.187.82', port: '5701' }];
  var returnRes = "";
  HazelcastClient
    .newHazelcastClient(config)
    .then(function (hazelcastClient) {
      map = hazelcastClient.getMap("search");

      // call this method to load cache
      fetchResultsAndLoadCache(map, request.url, hostName, myPort, methodType);

      // method to retrieve results from cache
      return setTimeout(() => {
        readFromCache(map, function (err, body) {
          console.log("Data from cache ::" + body);
          returnRes = body;
          return body;
        });
      }, 5000);
      //deleteFromCache(map);
    });
  setTimeout(() => { response.end(returnRes) }, 7000);
}
var printValue = function (text, value) {
  console.log(text + JSON.stringify(value));
};

/*
* function to call API and save results in Cache.
* When server starts, API will be invoked and for subsequent calls
* results will be retrieved from cache
*/
var fetchResultsAndLoadCache = function (map, urlPath, hostName, myPort, methodType) {

  var extServerOptions = {
    host: hostName,
    port: myPort,
    path: urlPath,
    method: methodType
  };
  var responseBody = '';
  var statusCode;
  var index = urlPath.lastIndexOf('/') + 1;
  key = urlPath.substring(index, index + 1);
  // console.log("index:::" + index + ":key:" + key);
  // map.get("I").then(function (value) {
  map.get(key).then(function (value) {

    if (value == null) {
      var dataValue;
      http.request(extServerOptions, function (res) {
        res.setEncoding('utf8');

        res.on('data', function (chunk) {
          responseBody += chunk;
        });
        res.on('end', function () {
          console.log("chunked data : " + responseBody);
          map.put(key, responseBody).then(function (previousValue) {
            printValue("Previous value : ", previousValue);
          });
        });


      }).end();  // uncomment this code
      //readPerson(map);
    }
  });
}

/*
* function to read results from Cache
*/
var readFromCache = function (map, callback) {

  // console.log("in readfromcache method key value::" + key);
  map.get(key).then(function (value) {
    console.log("value from cache :" + value);
    return callback(null, value);
  })

};

/*
* function to delete results from Cache
*/
var deleteFromCache = function (map) {
  // console.log("j is delete::" + i);
  for (j = 1; j <= i; j++) {
    map.remove(j).then(function (value) {
      printValue("Previous value in delete: ", value);
    })
  }
};
module.exports = HazelCache; // to export HazelCache function
