const express = require('express');
const path = require('path');
var HazelCache = require('./HazelApp.js');
const bodyParser = require('body-parser');
var http = require('http');
//var router = express.Router();

const app = express();

// Serve static assets
app.use(express.static(path.resolve(__dirname, '..', 'build')));
//app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Always return the main index.html, so react-router render the route in the client
app.get('/', (req, res) => {

    res.sendFile(path.resolve(__dirname, '..', 'build', 'index.html'));
});

app.get('/recording', (req, res) => {

    res.sendFile(path.resolve(__dirname, '..', 'build', 'index.html'));
});

app.get('/recordingdc', (req, res) => {

    res.sendFile(path.resolve(__dirname, '..', 'build', 'index.html'));
});

app.get('/getAllBankDetail', (req, res) => {

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,OPTIONS,DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    return new HazelCache(req, res);
});

//fetch GTE indexing data service
app.get('/WDM/fetch/1', (req, res) => {
    console.log("Sending to cache");
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,OPTIONS,DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    return new HazelCache(req, res, "10.191.131.145", "8090", "GET");
});

//Fetch dropdown data service
app.get('/hie/guarantee-fetchLookupInfo', (req, res) => {

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,OPTIONS,DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    return new HazelCache(req, res, "10.191.131.54", "8081", "get");
});

//Submit GTE indexing data service
app.post('/WDM/save', (req, res) => {

    var postData = JSON.stringify(req.body);
    var post_options = {
        host: '10.191.131.54',
        port: '8090',
        path: req.url,
        method: req.method,
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(postData)
        }
    };
    res.contentType('application/json');
    // Set up the request
    var postObj = http.request(post_options, function (responseData) {
        responseData.setEncoding('utf8');

        responseData.on('data', function (chunk) {
            // console.log('Response: ' + chunk);
            //return chunk;
            res.send(chunk);
        });
    });

    // post the data
    postObj.write(postData);
    postObj.end();
    postObj.on('error', function (e) {
        console.error(e);
    });

});


//Submit GTE recording data service
app.post('/hie/posthie', (req, res) => {

    var postData = JSON.stringify(req.body);
    console.log('postData: ' + postData);
    var post_options = {
        host: '10.191.131.54',
        port: '8081',
        path: req.url,
        method: req.method,
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(postData)
        }
    };
    res.contentType('application/json');
    // Set up the request
    var postObj = http.request(post_options, function (responseData) {
        responseData.setEncoding('utf8');

        responseData.on('data', function (chunk) {
            // console.log('Response: ' + chunk);
            return chunk;
            // res.send(chunk);
        });
    });

    // post the data
    postObj.write(postData);
    postObj.end();
    postObj.on('error', function (e) {
        console.error(e);
    });

});

module.exports = app;
