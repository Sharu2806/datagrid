import React,{Component} from 'react';
import SearchDataGrid from './SearchDataGrid.js'
import './index.css'
import * as addons from 'react-data-grid-addons'

class App extends Component{

  constructor(props){
    super(props);
    this.state ={
      _columns :[
        { key: 'id', name: 'ID' },
        { key: 'title', name: 'Title' },
        { key: 'count', name: 'Count',filterable: true,
        filterRenderer: addons.Filters.SingleSelectFilter } ,
        {
        key: 'avartar',
        name: 'Avartar',
        width: 50,
        resizable: true,
        filterable: true,
        filterRenderer: addons.Filters.SingleSelectFilter
      }
    ],
      rows  : 0,
      filters :{}
    }

    this.handleFilterChange     = this.handleFilterChange.bind(this);
    this.getValidFilterValues     = this.getValidFilterValues.bind(this);
    this.rowGetter            = this.rowGetter.bind(this);


  }

  componentWillMount(){
    this.createRows();
  }

  rowGetter(index) {
   return addons.Data.Selectors.getRows(this.state.rows)[index];
  }

  // rowsCount() {
  //   return Data.Selectors.getRows(this.state).length;
  // }

  createRows() {
      let rows = [];
      for (let i = 1; i < 50; i++) {
        if(i == 5 || i == 12 || i == 49){
          var avartar = <img className="grid-img" src="../icons/1.png" alt="Hold" />
        }else if(i == 10 || i == 15 || i == 22 || i == 30){
          var avartar = <img className="grid-img" src="../icons/2.png" alt="Hold" />
        }else if(i == 11 || i == 18 || i == 42 || i == 40){
          var avartar = <img className="grid-img" src="../icons/3.png" alt="Hold" />
        }else{
            var avartar = "";
        }
        rows.push({
          id: i,
          title: 'Title ' + i,
          count: i * 1000,
          avartar : avartar

        });
      }
      this.setState({rows : rows});
    }

    handleFilterChange(filter) {
         let newFilters = Object.assign({}, this.state.filters);
         if (filter.filterTerm) {
           newFilters[filter.column.key] = filter;
         } else {
           delete newFilters[filter.column.key];
         }
         this.setState({ filters: newFilters });
    }

    handleOnClearFilters() {
        this.setState({ filters: {} });
    }

    getValidFilterValues(columnId) {
      let values = this.state.rows.map(r => r[columnId]);
      return values.filter((item, i, a) => { return i === a.indexOf(item); });
    }
    render(){
        const rowGetter = rowNumber => this.state.rows[rowNumber];
        console.log(addons.Filters.SingleSelectFilter);
      return(
        <div className="container row">
            <div className="col-lg-8 col-md-8">
              <SearchDataGrid
                    onGridSort = {this.handleGridSort}
                    columns = {this.state._columns}
                    rowGetter = {this.rowGetter}
                    rowlength = {this.state.rows.length}
                    minheight = {500}
                    rowheight ={50}
                    toolbar={<addons.Toolbar enableFilter={true}/>}
                    onAddFilter={this.handleFilterChange}
                    onClearFilters={this.handleOnClearFilters}
                    getValidFilterValues={this.getValidFilterValues}
                    enableCellSelect={true}
                    />
              </div>
        </div>
        );
    }
}

export default App;
